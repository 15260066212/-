import { HarvesterBrowserValidator } from './harvester-browser.js';
export declare class SohuValidator extends HarvesterBrowserValidator {
    readonly platform: "sohu";
    protected get harvesterPlatform(): string;
}
//# sourceMappingURL=sohu.d.ts.map