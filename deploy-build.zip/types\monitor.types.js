/**
 * Monitor and dashboard-related type definitions.
 */
export {};
//# sourceMappingURL=monitor.types.js.map