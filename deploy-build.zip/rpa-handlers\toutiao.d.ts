import { SimpleRpaHandler } from './base.js';
/**
 * Toutiao (头条号) RPA handler - publishes articles via browser automation.
 * Requires cookie-based authentication (sessionid, ttwid, etc.)
 *
 * Publishing flow:
 * 1. Navigate to https://mp.toutiao.com/profile_v4/graphic/publish
 * 2. Fill in title
 * 3. Fill in content (ProseMirror editor)
 * 4. Set cover image (optional)
 * 5. Click publish button
 * 6. Handle confirmation dialog
 * 7. Extract the published article URL
 */
export declare class ToutiaoRpaHandler extends SimpleRpaHandler {
    protected readonly cookieDomain = ".toutiao.com";
    protected readonly loginUrlKeywords: string[];
    protected readonly platformDisplayName = "Toutiao";
    protected readonly titleSelectors: string[];
    protected readonly contentEditorSelectors: string[];
    protected readonly enableTags = false;
    protected readonly publishButtonSelectors: string[];
    protected readonly hasConfirmDialog = true;
    protected readonly confirmButtonSelectors: string[];
    protected readonly postIdPatterns: RegExp[];
    constructor();
    /**
     * Hook: Enter the editor. For Toutiao, we may need to:
     * - Close onboarding popups
     * - Wait for the ProseMirror editor to initialize
     */
    protected enterEditor(page: import('playwright').Page): Promise<boolean>;
}
//# sourceMappingURL=toutiao.d.ts.map