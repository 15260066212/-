import type { PublishTask } from '@zemingengine/shared';
/**
 * In-memory publish queue for tracking active publishing tasks.
 * Works alongside the DB-backed publish_tasks table for persistence.
 */
export declare class PublishQueue {
    private tasks;
    private processing;
    enqueue(task: PublishTask): void;
    dequeue(): PublishTask | undefined;
    getPending(): PublishTask[];
    getTask(taskId: string): PublishTask | undefined;
    updateTask(taskId: string, updates: Partial<PublishTask>): void;
    remove(taskId: string): void;
    /** Mark a task as being actively processed. */
    markProcessing(taskId: string): void;
    /** Mark a task as done processing (success or failure). */
    markDone(taskId: string): void;
    get size(): number;
}
//# sourceMappingURL=queue.d.ts.map