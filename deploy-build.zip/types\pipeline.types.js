/**
 * Pipeline and publish-related type definitions.
 */
export {};
//# sourceMappingURL=pipeline.types.js.map