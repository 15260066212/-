import type { DB } from './db.js';
import { DatabaseAccess } from './db.js';
import type { Article, ReviewResult, PublishTask, PublishLog, PlatformCredentials, PipelineRun } from '@zemingengine/shared';
/** Create an in-memory database with full schema (all migrations applied). */
export declare function createTestDatabase(): {
    db: DB;
    dbAccess: DatabaseAccess;
};
/** Create a mock Article with deterministic ID and all required fields. */
export declare function createMockArticle(overrides?: Partial<Article>): Article;
/** Create a mock ReviewResult with all 8 dimensions. */
export declare function createMockReview(articleId: string, round?: number): ReviewResult;
/** Create a mock PublishTask. */
export declare function createMockPublishTask(overrides?: Partial<PublishTask>): PublishTask;
/** Create a mock PublishLog. */
export declare function createMockPublishLog(overrides?: Partial<PublishLog>): PublishLog;
/** Create a mock PlatformCredentials. */
export declare function createMockCredentials(overrides?: Partial<PlatformCredentials>): PlatformCredentials;
/** Create a mock PipelineRun. */
export declare function createMockPipelineRun(overrides?: Partial<PipelineRun>): PipelineRun;
/** Reset the counter (useful for test isolation). */
export declare function resetMockCounters(): void;
/** Build a RequestInit with a JSON body for Hono's app.request(). */
export declare function jsonReq(method: string, body: unknown): RequestInit;
//# sourceMappingURL=test-helpers.d.ts.map