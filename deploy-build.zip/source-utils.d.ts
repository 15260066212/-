/**
 * Shared source utility — ecosystem classification & URL tracking key constants.
 *
 * Single source of truth for domain-to-ecosystem mapping and tracking parameter
 * detection, used by visibility-analysis, citation-analysis, and result-parser.
 */
/**
 * Classify a domain into its ecosystem.
 * Returns { ecosystem, label } — ecosystem is a machine key, label is human-readable Chinese.
 */
export declare function classifyEcosystem(domain: string): {
    ecosystem: string;
    label: string;
};
/**
 * Tracking query parameter keys to strip during URL normalization.
 * Union of all known tracking params across citation-analysis and result-parser.
 */
export declare const TRACKING_QUERY_KEYS: Set<string>;
//# sourceMappingURL=source-utils.d.ts.map