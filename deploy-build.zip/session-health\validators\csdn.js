import { HarvesterBrowserValidator } from './harvester-browser.js';
export class CsdnValidator extends HarvesterBrowserValidator {
    platform = 'csdn';
}
//# sourceMappingURL=csdn.js.map