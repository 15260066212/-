import type { StageHandler } from '../types.js';
export declare const profileStage: StageHandler;
//# sourceMappingURL=stage1-profile.d.ts.map