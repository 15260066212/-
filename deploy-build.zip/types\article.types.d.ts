/**
 * Article and review-related type definitions.
 */
import type { PlatformId, ArticleContentType, ArticleStatus } from './platform.types.js';
export interface Article {
    id: string;
    sessionId: string;
    platform: PlatformId;
    contentType: ArticleContentType;
    title: string;
    contentMarkdown: string;
    contentHtml?: string;
    contentPlain?: string;
    tags: string[];
    summary?: string;
    coverImageDesc?: string;
    wordCount: number;
    status: ArticleStatus;
    generationRound: number;
    reviewRound: number;
    publishUrl?: string;
    generationMeta?: {
        model: string;
        tokensUsed: number;
        durationMs: number;
        promptVersion: string;
    };
    metadata?: Record<string, unknown>;
    createdAt: string;
    updatedAt: string;
}
export type ReviewDimension = 'compliance' | 'quality' | 'seo' | 'brand' | 'originality' | 'platform_adaptation' | 'readability' | 'safety';
export type IssueSeverity = 'high' | 'medium' | 'low';
export interface ReviewIssue {
    dimension: ReviewDimension;
    severity: IssueSeverity;
    description: string;
    location?: string;
    suggestion?: string;
}
export interface DimensionResult {
    score: number;
    issues: ReviewIssue[];
}
/** Weight configuration for each review dimension (must sum to 1.0). */
export interface ReviewWeights {
    compliance: number;
    quality: number;
    seo: number;
    brand: number;
    originality: number;
    platform_adaptation: number;
    readability: number;
    safety: number;
}
export declare const DEFAULT_REVIEW_WEIGHTS: ReviewWeights;
export interface ReviewResult {
    articleId: string;
    round: number;
    passed: boolean;
    overallScore: number;
    dimensions: {
        compliance: DimensionResult;
        quality: DimensionResult;
        seo: DimensionResult;
        brand: DimensionResult;
        originality: DimensionResult;
        platform_adaptation: DimensionResult;
        readability: DimensionResult;
        safety: DimensionResult;
    };
    issues: ReviewIssue[];
    suggestions: string[];
    reviewedAt: string;
    contentHash?: string;
}
export interface ReviewFeedback {
    issues: ReviewIssue[];
    suggestions: string[];
    overallScore: number;
}
//# sourceMappingURL=article.types.d.ts.map