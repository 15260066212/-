import { PlatformAdapter } from './base.js';
import type { VerificationResult } from './base.js';
import type { PublishParams, PublishResult } from '../types.js';
import type { PlatformCredentials } from '@zemingengine/shared';
export declare class WechatAdapter extends PlatformAdapter {
    private tokenCache;
    constructor();
    getMethod(): 'api' | 'rpa';
    publish(params: PublishParams): Promise<PublishResult>;
    private getAccessToken;
    private createDraft;
    private submitPublish;
    private checkPublishStatus;
    /**
     * Verify that a published article is readable via the WeChat API.
     * Calls freepublish/getarticle to check if the article content is accessible.
     *
     * If verification fails (e.g. API error), the status is set to 'failed' or
     * 'unverified' but this does NOT affect the publish success status — the
     * article was already successfully published, we only record the verification
     * result.
     *
     * @param accessToken - WeChat API access token
     * @param mediaId - The media_id of the published article (from draft/add)
     * @returns Verification result with status and message
     */
    verifyPublication(accessToken: string, mediaId: string): Promise<VerificationResult>;
    /**
     * Verify a published article using stored credentials.
     * This is the standalone verification entry point used by the verify API endpoint.
     *
     * It first tries freepublish/getarticle with the postId as media_id.
     * If that fails (postId may be a publish_id rather than media_id), it falls
     * back to freepublish/get to check the publish status.
     *
     * @param credentials - WeChat credentials containing appId and appSecret
     * @param postId - The platform post ID (publish_id or media_id)
     * @returns Verification result with status and message
     */
    verifyWithCredentials(credentials: PlatformCredentials, postId?: string): Promise<VerificationResult>;
}
//# sourceMappingURL=wechat.d.ts.map