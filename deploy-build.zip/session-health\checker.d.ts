import type { PlatformCredentials, PlatformId } from '@zemingengine/shared';
import type { DatabaseAccess } from '../db.js';
import { BaseValidator } from './validators/base.js';
import type { ReloginManager } from './relogin-manager.js';
import { type HealthCheckStatus } from './types.js';
export declare class SessionHealthChecker {
    private db;
    private validators;
    private alerter;
    private reloginManager?;
    private running;
    constructor(db: DatabaseAccess, reloginManager?: ReloginManager);
    /** Set or update the relogin manager (for late injection). */
    setReloginManager(mgr: ReloginManager): void;
    registerValidator(validator: BaseValidator): void;
    hasValidator(platform: PlatformId): boolean;
    /**
     * Run a batch of health checks on credentials that are due.
     * Called periodically by the scheduler.
     */
    runCheckBatch(batchSize?: number): Promise<number>;
    /** Run the validator and capture the outcome, catching any thrown errors. */
    private executeValidation;
    /** Record a valid result and create a recovery alert if the credential was previously expired. */
    private handleValidResult;
    /** Fire-and-forget auto-relogin for supported platforms. */
    private maybeTriggerRelogin;
    /** Record an error result, auto-upgrade to expired if threshold reached, and create appropriate alerts. */
    private handleErrorResult;
    /**
     * Check a single credential's health status.
     * Auto-upgrades to 'expired' after MAX_CONSECUTIVE_FAILURES.
     * Creates alerts on status transitions.
     */
    checkCredential(credentials: PlatformCredentials): Promise<HealthCheckStatus>;
}
//# sourceMappingURL=checker.d.ts.map