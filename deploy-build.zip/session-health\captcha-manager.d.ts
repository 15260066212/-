/**
 * CaptchaManager — Centralized captcha detection, tracking, alerting,
 * and manual intervention queue for RPA publishing operations.
 *
 * Flow:
 * 1. During publish, harvester detects captcha elements on the page
 * 2. CaptchaManager.recordCaptcha() logs the event to DB + creates alert
 * 3. Task is moved to 'captcha_blocked' status, waiting for manual intervention
 * 4. When captcha is resolved (manually or automatically), resolveCaptcha() is called
 * 5. Task can then be retried
 *
 * Also provides:
 * - Platform captcha frequency tracking (detect high-risk accounts)
 * - Retry policy with exponential backoff
 * - Real-time alert notifications
 */
import type { DatabaseAccess } from '../db.js';
/** Captcha types supported by the system. */
export type CaptchaType = 'slider' | 'geetest' | 'image' | 'text' | 'behavioral' | 'sms' | 'qrcode' | 'unknown';
export type CaptchaSource = 'publish' | 'login' | 'relogin' | 'session_check' | 'manual_check';
export type CaptchaStatus = 'pending' | 'resolved' | 'expired' | 'ignored';
export interface CaptchaDetectionResult {
    detected: boolean;
    type: CaptchaType;
    selector: string;
    source: CaptchaSource;
}
export declare class CaptchaManager {
    private db;
    constructor(db: DatabaseAccess);
    /** Get all captcha selectors for a platform (platform-specific + generic). */
    getCaptchaSelectors(platform: string): {
        selector: string;
        type: CaptchaType;
    }[];
    /**
     * Record a captcha event when one is detected during RPA operations.
     * Creates a DB record, generates a health alert, and returns the event ID.
     */
    recordCaptcha(platform: string, captchaType: CaptchaType, source: CaptchaSource, taskId?: string, userId?: string, pageUrl?: string, screenshot?: string): number;
    /** Resolve a captcha event (after manual or automatic resolution). */
    resolveCaptcha(eventId: number, resolvedBy?: string): boolean;
    /** Get pending captcha events awaiting manual intervention. */
    getPendingEvents(limit?: number): {
        id: number;
        platform: string;
        taskId: string | null;
        userId: string;
        captchaType: string;
        captchaSource: string;
        pageUrl: string | null;
        screenshot: string | null;
        createdAt: number;
    }[];
    /** Get captcha statistics for the monitor dashboard. */
    getStats(): {
        total: number;
        pending: number;
        resolved: number;
        expired: number;
        byPlatform: Array<{
            platform: string;
            total: number;
            pending: number;
            resolved: number;
        }>;
        byType: Array<{
            captchaType: string;
            total: number;
        }>;
    };
    /** Get recent captcha events with optional filtering. */
    getEvents(limit?: number, platform?: string, status?: string): {
        id: number;
        platform: string;
        taskId: string | null;
        captchaType: string;
        captchaSource: string;
        status: string;
        resolvedBy: string | null;
        resolvedAt: number | null;
        createdAt: number;
    }[];
    /**
     * Check if a platform has exceeded its daily captcha limit.
     * If so, the platform should be paused to avoid account bans.
     */
    shouldPausePlatform(platform: string): boolean;
    /** Check if a retry is allowed (not in cooldown). */
    canRetry(_platform: string, lastCaptchaTime: number): boolean;
    /** Get captcha monitor status for API. */
    getStatus(): {
        pendingEvents: {
            id: number;
            platform: string;
            taskId: string | null;
            userId: string;
            captchaType: string;
            captchaSource: string;
            pageUrl: string | null;
            screenshot: string | null;
            createdAt: number;
        }[];
        retryCooldownMs: number;
        maxCaptchaPerDay: number;
        monitoredPlatforms: string[];
        total: number;
        pending: number;
        resolved: number;
        expired: number;
        byPlatform: Array<{
            platform: string;
            total: number;
            pending: number;
            resolved: number;
        }>;
        byType: Array<{
            captchaType: string;
            total: number;
        }>;
    };
}
//# sourceMappingURL=captcha-manager.d.ts.map