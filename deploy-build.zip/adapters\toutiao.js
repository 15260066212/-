import { PlatformAdapter } from './base.js';
export class ToutiaoAdapter extends PlatformAdapter {
    constructor() {
        super('toutiao');
    }
    getMethod() {
        return 'rpa';
    }
    async publish(_params) {
        return {
            success: true,
            postId: 'mock_rpa_post_id',
            postUrl: 'https://example.com',
        };
    }
}
//# sourceMappingURL=toutiao.js.map