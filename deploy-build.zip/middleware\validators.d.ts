/**
 * Validators for common API inputs.
 * Uses hono's built-in validator (no extra dependency needed).
 */
export declare const messageValidator: import("hono").MiddlewareHandler<any, string, {
    in: {
        json: {
            message: string;
        };
    };
    out: {
        json: {
            message: string;
        };
    };
}, import("hono").TypedResponse<{
    success: false;
    error: string;
}, 400, "json">>;
export declare const scrapeValidator: import("hono").MiddlewareHandler<any, string, {
    in: {
        json: {
            url: string;
        };
    };
    out: {
        json: {
            url: string;
        };
    };
}, import("hono").TypedResponse<{
    success: false;
    error: string;
}, 400, "json">>;
export declare const credentialValidator: import("hono").MiddlewareHandler<any, string, {
    in: {
        json: {
            platform: string;
            data: Record<string, unknown>;
            type: string;
            status: string;
        };
    };
    out: {
        json: {
            platform: string;
            data: Record<string, unknown>;
            type: string;
            status: string;
        };
    };
}, import("hono").TypedResponse<{
    success: false;
    error: string;
}, 400, "json">>;
export declare const pipelineStartValidator: import("hono").MiddlewareHandler<any, string, {
    in: {
        json: {
            sessionId: string;
            platforms: any;
            contentType: string;
        };
    };
    out: {
        json: {
            sessionId: string;
            platforms: any;
            contentType: string;
        };
    };
}, import("hono").TypedResponse<{
    success: false;
    error: string;
}, 400, "json">>;
export declare const paginationValidator: import("hono").MiddlewareHandler<any, string, {
    in: {
        query: {
            page: number;
            pageSize: number;
        };
    };
    out: {
        query: {
            page: number;
            pageSize: number;
        };
    };
}, never>;
//# sourceMappingURL=validators.d.ts.map