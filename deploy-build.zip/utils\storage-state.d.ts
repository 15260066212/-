/**
 * StorageState utilities for full browser state persistence.
 *
 * Playwright's storageState captures cookies + localStorage + IndexedDB
 * in a single JSON file. Restoring full state instead of just cookies
 * reduces "new device" detection and significantly extends session lifespan.
 *
 * Compatibility:
 * - If only legacy cookie string is available, convert it to a minimal
 *   storageState JSON with just cookies.
 * - If full storageState is available, use it directly.
 */
import type { Cookie } from 'playwright';
export interface StorageState {
    cookies: Cookie[];
    origins: Array<{
        origin: string;
        localStorage: Array<{
            name: string;
            value: string;
        }>;
    }>;
}
/**
 * Parse a legacy Netscape-style cookie string into a StorageState object.
 * Used for backward compatibility when only cookie strings are available.
 */
export declare function cookieStringToStorageState(cookieStr: string): StorageState;
/**
 * Convert a StorageState back to a legacy cookie string.
 * Used for backward compatibility with systems that expect plain cookie strings.
 */
export declare function storageStateToCookieString(state: StorageState): string;
/**
 * Ensure the credential has a storageState field.
 * If only legacy cookie string is present, convert it.
 * Returns the full StorageState object.
 */
export declare function resolveStorageState(credentialData: Record<string, unknown>): StorageState | null;
/**
 * Merge refreshed cookies from the harvester into an existing storage state.
 * Preserves localStorage and other state while updating cookies.
 */
export declare function mergeRefreshedCookies(existingState: StorageState | null, refreshedCookies: Cookie[]): StorageState;
/**
 * Check if a credential has full storage state (not just cookies).
 */
export declare function hasFullStorageState(credentialData: Record<string, unknown>): boolean;
/**
 * Filter cookies by domain list (substring match on domain field).
 */
export declare function filterCookiesByDomain(cookies: Array<{
    domain?: string;
}>, domains: string[]): Array<{
    domain?: string;
}>;
/**
 * Check whether a URL matches any login redirect pattern.
 * @param url - URL to check
 * @param redirectPatterns - Array of patterns to match (case-insensitive substring)
 */
export declare function isLoginRedirectUrl(url: string, redirectPatterns: string[]): boolean;
//# sourceMappingURL=storage-state.d.ts.map