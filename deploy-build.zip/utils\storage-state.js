/**
 * StorageState utilities for full browser state persistence.
 *
 * Playwright's storageState captures cookies + localStorage + IndexedDB
 * in a single JSON file. Restoring full state instead of just cookies
 * reduces "new device" detection and significantly extends session lifespan.
 *
 * Compatibility:
 * - If only legacy cookie string is available, convert it to a minimal
 *   storageState JSON with just cookies.
 * - If full storageState is available, use it directly.
 */
/**
 * Parse a legacy Netscape-style cookie string into a StorageState object.
 * Used for backward compatibility when only cookie strings are available.
 */
export function cookieStringToStorageState(cookieStr) {
    const cookies = [];
    const pairs = cookieStr.split(';');
    for (const pair of pairs) {
        const trimmed = pair.trim();
        if (!trimmed)
            continue;
        const eqIdx = trimmed.indexOf('=');
        if (eqIdx === -1)
            continue;
        const name = trimmed.slice(0, eqIdx).trim();
        const value = trimmed.slice(eqIdx + 1).trim();
        if (!name)
            continue;
        cookies.push({
            name,
            value,
            domain: '',
            path: '/',
            expires: -1,
            httpOnly: false,
            secure: false,
            sameSite: 'Lax',
        });
    }
    return { cookies, origins: [] };
}
/**
 * Convert a StorageState back to a legacy cookie string.
 * Used for backward compatibility with systems that expect plain cookie strings.
 */
export function storageStateToCookieString(state) {
    return state.cookies.map((c) => `${c.name}=${c.value}`).join('; ');
}
/**
 * Ensure the credential has a storageState field.
 * If only legacy cookie string is present, convert it.
 * Returns the full StorageState object.
 */
export function resolveStorageState(credentialData) {
    // Priority 1: Full storageState JSON string
    if (typeof credentialData.storageState === 'string' && credentialData.storageState) {
        try {
            return JSON.parse(credentialData.storageState);
        }
        catch {
            // Invalid JSON, fall through to cookie string
        }
    }
    // Priority 2: storageState as object
    if (credentialData.storageState &&
        typeof credentialData.storageState === 'object' &&
        Array.isArray(credentialData.storageState.cookies)) {
        return credentialData.storageState;
    }
    // Priority 3: Legacy cookie string
    const cookieStr = (credentialData.cookie || credentialData.cookies || '');
    if (cookieStr) {
        return cookieStringToStorageState(cookieStr);
    }
    return null;
}
/**
 * Merge refreshed cookies from the harvester into an existing storage state.
 * Preserves localStorage and other state while updating cookies.
 */
export function mergeRefreshedCookies(existingState, refreshedCookies) {
    return {
        cookies: refreshedCookies,
        origins: existingState?.origins ?? [],
    };
}
/**
 * Check if a credential has full storage state (not just cookies).
 */
export function hasFullStorageState(credentialData) {
    if (typeof credentialData.storageState !== 'string')
        return false;
    try {
        const state = JSON.parse(credentialData.storageState);
        return Array.isArray(state.origins) && state.origins.length > 0;
    }
    catch {
        return false;
    }
}
/**
 * Filter cookies by domain list (substring match on domain field).
 */
export function filterCookiesByDomain(cookies, domains) {
    if (!Array.isArray(cookies) || !Array.isArray(domains)) {
        return [];
    }
    return cookies.filter((c) => domains.some((d) => (c.domain || '').includes(d)));
}
/**
 * Check whether a URL matches any login redirect pattern.
 * @param url - URL to check
 * @param redirectPatterns - Array of patterns to match (case-insensitive substring)
 */
export function isLoginRedirectUrl(url, redirectPatterns) {
    if (!url || typeof url !== 'string') {
        return false;
    }
    if (!Array.isArray(redirectPatterns) || redirectPatterns.length === 0) {
        return false;
    }
    const lowerUrl = url.toLowerCase();
    return redirectPatterns.some((p) => lowerUrl.includes(p.toLowerCase()));
}
//# sourceMappingURL=storage-state.js.map