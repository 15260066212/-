import { PlatformAdapter } from './base.js';
import type { PublishParams, PublishResult } from '../types.js';
export declare class NeteaseAdapter extends PlatformAdapter {
    constructor();
    getMethod(): 'api' | 'rpa';
    publish(_params: PublishParams): Promise<PublishResult>;
}
//# sourceMappingURL=netease.d.ts.map