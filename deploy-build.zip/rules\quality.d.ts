import type { Article, ReviewIssue } from '@zemingengine/shared';
export declare function checkQuality(article: Article): ReviewIssue[];
//# sourceMappingURL=quality.d.ts.map