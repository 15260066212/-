import type { DB } from '../db.js';
import type { MonitorArticleStats, MonitorPublishTaskStats, MonitorPipelineRunStats, MonitorCredentialStats, ArticleTimelinePoint, PlatformCount, StatusCount, PublishPlatformStat, PublishTimelinePoint, ReviewChartdata, PublishFailureAnalysis } from '@zemingengine/shared';
export declare class MonitorRepository {
    private db;
    constructor(db: DB);
    /**
     * Count articles grouped by status. Returns the total across all statuses
     * plus a per-status breakdown.
     */
    getArticleStats(): MonitorArticleStats;
    /**
     * Count articles created per day for the last `days` days (inclusive of
     * today). Returns an ordered list (oldest first).
     */
    getArticleTimeline(days: number): ArticleTimelinePoint[];
    /** Count articles grouped by platform. */
    getArticlesByPlatformStats(): PlatformCount[];
    /** Count articles grouped by status (ordered by count desc). */
    getArticlesByStatusStats(): StatusCount[];
    /**
     * Count publish tasks grouped by platform, including total, published, and
     * failed counts per platform.
     */
    getPublishStatsByPlatform(): PublishPlatformStat[];
    /**
     * Count published and failed publish tasks per day for the last `days` days.
     * Grouped by the task's creation date.
     */
    getPublishTimeline(days: number): PublishTimelinePoint[];
    /**
     * Compute review statistics: average overall score, pass rate, and a
     * score distribution across five buckets (0-60, 60-70, 70-80, 80-90,
     * 90-100). Returns zeros when no reviews exist.
     */
    getReviewStats(): ReviewChartdata;
    /** Total number of sessions. */
    getSessionCount(): number;
    /** Count pipeline runs grouped by status. */
    getPipelineRunStats(): MonitorPipelineRunStats;
    /** Count credentials grouped by status. */
    getCredentialStats(): MonitorCredentialStats;
    /** Count publish tasks grouped by status (used for overview aggregation). */
    getPublishTaskStats(): MonitorPublishTaskStats;
    /**
     * Comprehensive failure analysis: groups failures by type, platform,
     * provides daily success rate trends, and surfaces the most common errors.
     */
    getPublishFailureAnalysis(days?: number): PublishFailureAnalysis;
}
//# sourceMappingURL=monitor-repository.d.ts.map