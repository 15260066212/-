import type { DatabaseAccess } from '../db.js';
export interface AlertInfo {
    platform: string;
    alertType: 'session_expired' | 'consecutive_failures' | 'session_recovered' | 'relogin_success' | 'relogin_captcha' | 'relogin_failed';
    message: string;
    userId?: string;
}
export declare class HealthAlerter {
    private db;
    constructor(db: DatabaseAccess);
    /**
     * Create an alert in the database.
     * The alert will be sent by the `sendPendingAlerts()` method.
     */
    createAlert(info: AlertInfo): number;
    /**
     * Send all unsent alerts via webhook.
     * Supports WeCom bot and generic webhook URLs.
     */
    sendPendingAlerts(): Promise<number>;
    /**
     * Send a message via webhook.
     * Supports WeCom bot format and generic JSON webhook.
     */
    private sendWebhook;
    /**
     * Check if alerting is configured.
     */
    isConfigured(): boolean;
}
//# sourceMappingURL=alerter.d.ts.map