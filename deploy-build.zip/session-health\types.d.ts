import type { PlatformCredentials, PlatformId } from '@zemingengine/shared';
export interface ValidationResult {
    valid: boolean;
    error?: string;
    evidence?: {
        pageTitle?: string;
        finalUrl?: string;
        screenshot?: string;
    };
    durationMs: number;
}
export interface Validator {
    readonly platform: PlatformId;
    validate(credentials: PlatformCredentials): Promise<ValidationResult>;
}
export type HealthCheckStatus = 'valid' | 'checking' | 'expired' | 'invalid' | 'error';
export interface HealthCheckLog {
    id?: number;
    platform: string;
    userId: string;
    status: HealthCheckStatus;
    durationMs: number;
    errorMessage?: string;
    checkedAt: number;
}
export declare const DEFAULT_CHECK_INTERVAL_MS: number;
export declare const CHECK_BATCH_SIZE = 3;
export declare const MAX_CONSECUTIVE_FAILURES = 3;
//# sourceMappingURL=types.d.ts.map