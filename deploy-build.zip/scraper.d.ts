import type { ScrapeResult } from '@zemingengine/shared';
export interface ScrapeOptions {
    /** Timeout in milliseconds. Default: 10000 */
    timeout?: number;
    /** User agent string */
    userAgent?: string;
}
/**
 * Scrape a URL using Cheerio (static HTML parsing).
 * This is the primary scraping method, suitable for ~90% of sites.
 */
export declare function scrapeUrl(url: string, options?: ScrapeOptions): Promise<ScrapeResult>;
//# sourceMappingURL=scraper.d.ts.map