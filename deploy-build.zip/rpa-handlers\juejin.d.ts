import { type Article, type PlatformCredentials } from '@zemingengine/shared';
import type { Page } from 'playwright';
import type { PublishResult } from '../types.js';
import { RpaHandler } from './base.js';
/**
 * Juejin RPA handler - publishes articles via browser automation.
 * Requires cookie-based authentication.
 *
 * Publishing flow:
 * 1. Navigate to https://juejin.cn/editor/drafts/new
 * 2. Fill in title
 * 3. Fill in Markdown content
 * 4. Add tags
 * 5. Click publish
 * 6. Extract published article URL
 */
export declare class JuejinRpaHandler extends RpaHandler {
    constructor();
    publish(page: Page, article: Article, credentials: PlatformCredentials): Promise<PublishResult>;
}
//# sourceMappingURL=juejin.d.ts.map