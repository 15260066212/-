import type { Page } from 'playwright';
import type { Article } from '@zemingengine/shared';
import type { PublishResult } from '../../../types.js';
import { BaseCsdnStrategy } from './base.js';
/**
 * Strategy 3: Draft + Management Page Publish
 *
 * Save the article as a draft in the old editor, then navigate to the draft
 * management page and click "发布" on the matching draft. Used as the last
 * resort when direct publish buttons don't work.
 */
export declare class DraftManagementStrategy extends BaseCsdnStrategy {
    readonly name = "Draft + Management Page";
    execute(page: Page, article: Article): Promise<PublishResult>;
}
//# sourceMappingURL=draft-management.strategy.d.ts.map