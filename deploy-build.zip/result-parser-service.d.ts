export declare class ResultParserService {
    parseAIResponse(aiResponse: unknown): {
        originalText: string;
        parsingStatus: "completed";
    };
    /**
     * Normalize a URL for cross-platform deduplication.
     * Strips tracking params, normalizes protocol/host, removes trailing slash.
     */
    normalizeUrlForDedup(url: string): string;
    /**
     * Normalize a domain for cross-platform deduplication.
     */
    normalizeDomainForDedup(domain: string): string;
    /**
     * Deduplicate sources across multiple platform results.
     * Returns merged source list with cross-platform citation count and consensus ranking.
     */
    deduplicateCrossPlatformSources(platformSources: Record<string, Array<{
        url?: string;
        domain?: string;
        title?: string;
        ecosystem?: string;
    }>>): {
        unifiedSources: {
            url: string;
            domain: string;
            title?: string;
            platforms: string[];
            ecosystem: string;
        }[];
        consensusSources: {
            url: string;
            domain: string;
            title?: string;
            platforms: string[];
            ecosystem: string;
        }[];
        platformCoverage: Record<string, number>;
    };
    extractResponseText(aiResponse: unknown): string;
    normalizeTextContent(content: unknown): string;
}
export declare const resultParserService: ResultParserService;
//# sourceMappingURL=result-parser-service.d.ts.map