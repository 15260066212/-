import type { Article, PlatformCredentials, PlatformId } from '@zemingengine/shared';
import type { Browser, BrowserContext } from 'playwright';
import type { PublishResult } from './types.js';
import { RpaHandler } from './rpa-handlers/base.js';
/**
 * Minimal account info needed by SessionPool to acquire a browser context.
 * This is a subset of AccountCredentials from account-vault.
 */
export interface SessionAccount {
    platform: string;
    accountId: string;
    fingerprintId?: string;
}
/**
 * Interface for SessionPool integration.
 * The actual SessionPool class (packages/session-pool) implements this interface.
 * RPAEngine uses it to persist and reuse browser sessions with fingerprint isolation.
 */
export interface ISessionPool {
    acquireContext(account: SessionAccount): Promise<BrowserContext>;
    releaseContext(accountId: string, platform: string): void | Promise<void>;
    saveSession(accountId: string, platform: string, context: BrowserContext, userDataDir: string, fingerprintId?: string): Promise<void>;
    close(): Promise<void>;
}
/**
 * Playwright-based RPA engine for browser automation publishing.
 *
 * Features:
 * - Lazy browser launch (only when first publish is requested)
 * - Optional stealth plugin to patch automation fingerprints (extends cookie lifespan)
 * - Full storageState persistence (cookies + localStorage + IndexedDB)
 * - Optional SessionPool integration for session persistence + fingerprint isolation
 * - Configurable headless mode via RPA_HEADLESS env var
 * - Cookie-based authentication injection
 * - Per-platform handler dispatch
 * - Automatic screenshot capture on errors
 * - Graceful fallback when Playwright is not available
 *
 * As a Facade, RPAEngine coordinates specialized sub-modules:
 * - RemotePublisher: delegates publishing to a remote harvester service
 * - PublicationVerifier: verifies that published articles are live
 * - LLMWikiFallback: provides LLMWiki-based self-healing fallback
 */
export declare class RPAEngine {
    private browser;
    private handlers;
    private launchPromise;
    private sessionPool?;
    private fingerprintManager;
    private fingerprintEnabled;
    private fingerprintManagerPromise;
    onFingerprintGenerated?: (platform: PlatformId, accountId: string, fingerprintJson: string) => void | Promise<void>;
    private remotePublisher;
    private publicationVerifier;
    private llmWikiFallback;
    constructor(sessionPool?: ISessionPool);
    /**
     * Lazily load the BrowserFingerprintManager.
     * Only called when actually needed (local RPA mode + fingerprint enabled).
     */
    private getFingerprintManager;
    /** Number of registered handlers (exposes handler map size for inspection). */
    get handlerCount(): number;
    /** Register a custom RPA handler for a platform. */
    registerHandler(handler: RpaHandler): void;
    /** Check if a handler is registered for a platform. */
    hasHandler(platform: PlatformId): boolean;
    /** Get all platform IDs that have a registered handler. */
    getHandlerPlatforms(): PlatformId[];
    /**
     * Whether remote RPA execution is enabled via the RPA_REMOTE_URL env var.
     *
     * When set (e.g. http://harvester:3003), publish calls are delegated to the
     * harvester service over HTTP instead of launching a local Playwright
     * browser. This is used in Docker deployments where the geo-app container
     * does not have Playwright browsers installed, but the harvester container
     * does.
     */
    private isRemoteMode;
    /**
     * Launch the browser lazily. Returns a cached instance if already launched.
     * Uses RPA_HEADLESS env var (default: true).
     *
     * Stealth plugin (RPA_STEALTH=true, default) patches 20+ automation
     * fingerprints to reduce bot detection, which significantly extends cookie
     * lifespan by avoiding "suspicious browser" flagging.
     *
     * NOTE: In remote mode (RPA_REMOTE_URL set), local browser launch is
     * disabled and publishing is delegated to the harvester service.
     * Calling launch() in remote mode will throw.
     */
    launch(): Promise<Browser>;
    private doLaunch;
    /** Close the browser if it's running. */
    close(): Promise<void>;
    /**
     * Enable or disable LLMWiki fallback at runtime.
     */
    setLLMWikiFallback(enabled: boolean): void;
    /**
     * Publish an article to a platform using the registered RPA handler.
     *
     * Flow:
     * 1. If remote mode, delegate to RemotePublisher
     * 2. Otherwise acquire a browser context (SessionPool or fresh)
     * 3. Find the handler for the target platform
     * 4. Restore full browser state (storageState > cookies, for better session lifespan)
     * 5. Execute the handler's publish flow
     * 6. Save updated storageState (so next restore has fresher state)
     * 7. Verify publication (best-effort)
     * 8. Optionally trigger LLMWiki fallback on failure
     */
    publish(article: Article, credentials: PlatformCredentials, accountId: string): Promise<PublishResult>;
}
//# sourceMappingURL=rpa-engine.d.ts.map