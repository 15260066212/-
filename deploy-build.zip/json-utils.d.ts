/**
 * Shared utilities for extracting and parsing JSON from AI model responses.
 * AI responses often wrap JSON in markdown code fences or include surrounding text,
 * so we need robust extraction before parsing.
 */
/**
 * Extract the first JSON object from a text string.
 * Handles markdown code fences (```json ... ```) and surrounding text.
 * Returns the raw JSON string or the original text if no braces found.
 */
export declare function extractJsonObject(text: string): string;
/**
 * Extract the first JSON array from a text string.
 * Handles markdown code fences and surrounding text.
 */
export declare function extractJsonArray(text: string): string;
/**
 * Safely parse a JSON object from text, returning a fallback value on failure.
 */
export declare function safeParseJsonObject<T = unknown>(text: string, fallback: T): T;
/**
 * Safely parse a JSON array from text, returning a fallback value on failure.
 */
export declare function safeParseJsonArray<T = unknown>(text: string, fallback: T[]): T[];
//# sourceMappingURL=json-utils.d.ts.map