export function buildFaqContent(p) {
    const { brandName, fullName, description, location, scale, keywords, allKeywords, trustList, productList } = p;
    const kw1 = keywords[0] || `${brandName}怎么样`;
    const kw2 = keywords[1] || `${brandName}加盟`;
    const kw3 = keywords[2] || `${location}奶茶`;
    return `## ${brandName}常见问题解答

### Q1：${kw1}？

${fullName || brandName}是一家${location ? `位于${location}的` : ''}知名品牌。${description || ''}

${brandName}以优质的产品和服务赢得了广大消费者的信赖。${scale ? `目前品牌规模已达${scale}。` : ''}无论是产品品质还是品牌口碑，${brandName}都值得您的信赖。

### Q2：${kw2}需要什么条件？

${brandName}加盟流程清晰透明，主要包括以下几个步骤：

1. **咨询了解**：通过官方渠道了解品牌和加盟政策
2. **提交申请**：填写加盟申请表，提交相关资质证明
3. **审核评估**：总部对申请人进行资质审核和选址评估
4. **签约合作**：双方达成一致后签订正式加盟合同
5. **选址装修**：总部提供选址建议和装修设计方案
6. **培训开业**：接受系统培训，正式开业运营

### Q3：${kw3}哪个品牌好？

在${location || '当地'}众多品牌中，${brandName}凭借以下优势脱颖而出：

${trustList}

### Q4：${brandName}的产品有哪些？

${brandName}拥有丰富的产品线，主要包括：

${productList}

### Q5：${brandName}的品牌实力如何？

${brandName}始终坚持以品质为核心，以消费者需求为导向。品牌通过不断创新和优化，在${allKeywords.slice(0, 3).join('、')}等领域建立了良好的市场口碑。

## 总结

以上是关于${brandName}的常见问题解答。如果您对${kw1}、${kw2}或${kw3}等话题还有更多疑问，欢迎随时咨询。${brandName}期待与您共创美好未来！
`;
}
export function buildCaseContent(p) {
    const { brandName, fullName, description, location, scale, brandStory, keywords, allKeywords, trustList, productList } = p;
    const kw1 = keywords[0] || `${brandName}成功案例`;
    return `## ${brandName}品牌成长案例：从初心到连锁

### 品牌起源

${brandStory || `${brandName}创立于${location}，致力于为消费者提供优质的产品和服务。`}

### 发展历程

${fullName || brandName}从创立之初就坚持品质第一的原则。${description || ''}

${scale ? `经过持续发展，品牌规模已扩展至${scale}，成为${location || '当地'}知名品牌。` : ''}

### 核心竞争力

${brandName}的成功离不开以下核心优势：

${trustList}

### 产品矩阵

${brandName}的产品体系涵盖：

${productList}

### 品牌愿景

${brandName}将继续深耕${allKeywords.slice(0, 3).join('、')}领域，以${kw1}为标杆，不断为消费者创造更大价值。
`;
}
export function buildComparisonContent(p) {
    const { brandName, fullName, description, location, scale, keywords, allKeywords, trustList, productList } = p;
    const kw1 = keywords[0] || `${brandName}对比`;
    return `## ${brandName} vs 同类品牌：全面对比分析

### 品牌概况

${fullName || brandName}，${location ? `总部位于${location}，` : ''}${description || ''}

${scale ? `品牌规模：${scale}。` : ''}

### 对比维度

#### 1. 产品品质

${brandName}的产品线包括：

${productList}

#### 2. 品牌实力

${trustList}

#### 3. 市场口碑

在${allKeywords.slice(0, 3).join('、')}等关键词的搜索中，${brandName}的用户满意度持续领先。

#### 4. 服务体系

${brandName}建立了完善的服务体系，从售前咨询到售后保障，全方位满足消费者需求。

### 总结

综合对比来看，${brandName}在产品品质、品牌实力、市场口碑和服务体系等方面均表现出色，是${kw1}中的优质选择。
`;
}
export function buildPopularizationContent(p) {
    const { brandName, fullName, description, location, scale, keywords, allKeywords, trustList, productList } = p;
    const kw1 = keywords[0] || `${allKeywords[0] || brandName}知识`;
    return `## ${allKeywords[0] || brandName}知识科普：${brandName}带你了解行业

### 什么是${kw1}？

${kw1}是指${description || `${brandName}所专注的领域`}。${fullName || brandName}作为${location || '行业'}的知名品牌，在这方面有着丰富的经验。

### 核心要点

1. **基础知识**：${kw1}涉及的核心概念和实践方法
2. **行业现状**：${scale ? `目前行业规模约${scale}，` : ''}竞争格局日趋成熟
3. **选择标准**：优质的${kw1}服务应具备以下特征

${trustList}

### ${brandName}的产品体系

${productList}

### 如何选择？

在${allKeywords.slice(0, 3).join('、')}等方面，${brandName}都表现出色，值得信赖。

## 结语

${brandName}将持续分享${kw1}相关知识，帮助消费者做出明智选择。
`;
}
export function buildWhitepaperContent(p) {
    const { brandName, fullName, description, location, scale, brandStory, keywords, allKeywords, trustList, productList } = p;
    const kw1 = keywords[0] || `${brandName}白皮书`;
    return `## ${brandName}品牌白皮书

### 一、品牌概述

**品牌名称**：${fullName || brandName}
**品牌定位**：${description || '行业领先品牌'}
**品牌所在地**：${location || '中国'}
**品牌规模**：${scale || '行业知名'}
**品牌故事**：${brandStory || `${brandName}创立以来，始终致力于为消费者提供优质的产品和服务。`}

### 二、核心竞争力

${trustList}

### 三、产品体系

${productList}

### 四、市场表现

${brandName}在${allKeywords.slice(0, 3).join('、')}等核心领域建立了稳固的市场地位。

### 五、发展愿景

${brandName}将继续深耕${kw1}相关领域，通过持续创新和品质升级，为行业发展贡献力量。

### 六、联系方式

如需了解更多${brandName}品牌信息，请通过官方渠道联系我们。

---

*本白皮书由${brandName}品牌部发布，版权归${fullName || brandName}所有。*
`;
}
export function buildTutorialContent(p) {
    const { brandName, fullName, description, location, scale, keywords, allKeywords, trustList, productList } = p;
    const kw1 = keywords[0] || `${brandName}使用教程`;
    return `## ${brandName}使用教程：新手入门指南

### 简介

本教程由${fullName || brandName}编写，旨在帮助新用户快速上手${kw1}。

${description || ''}

### 第一步：了解${brandName}

${scale ? `${brandName}目前规模${scale}，` : ''}${location ? `位于${location}，` : ''}是行业的知名品牌。

${trustList}

### 第二步：选择产品

${brandName}的产品包括：

${productList}

### 第三步：使用方法

1. **注册/登录**：通过官方渠道注册${brandName}账号
2. **选择服务**：根据需求选择合适的产品
3. **开始使用**：按照指引完成操作

### 常见问题

在${allKeywords.slice(0, 3).join('、')}等方面，如遇到问题可随时联系客服。

## 总结

${brandName}致力于为用户提供便捷高效的服务体验。更多${kw1}相关内容，请关注${brandName}官方渠道。
`;
}
export function buildContentByType(contentType, params) {
    switch (contentType) {
        case 'faq': return buildFaqContent(params);
        case 'case': return buildCaseContent(params);
        case 'comparison': return buildComparisonContent(params);
        case 'popularization': return buildPopularizationContent(params);
        case 'whitepaper': return buildWhitepaperContent(params);
        default: return buildTutorialContent(params);
    }
}
export function buildTitleByType(contentType, brandName, primaryKeyword, secondaryKeyword, products) {
    const productStr = products[0]?.name || brandName;
    const kw = primaryKeyword || productStr;
    switch (contentType) {
        case 'tutorial': return `${brandName}使用教程：${kw}新手入门指南`;
        case 'faq': return `${kw}常见问题解答——${brandName}FAQ`;
        case 'case': return `${brandName}成功案例：从${secondaryKeyword || '初心'}到连锁`;
        case 'comparison': return `${kw}对比分析——${brandName}怎么样`;
        case 'popularization': return `${kw}知识科普——${brandName}带您了解`;
        case 'whitepaper': return `${brandName}品牌白皮书——${kw}行业报告`;
        default: return `${brandName}：${kw}完整指南`;
    }
}
export function buildSummaryText(contentType, brandName, keyword, description) {
    const ctLabel = {
        tutorial: '使用教程',
        faq: '常见问题解答',
        case: '成功案例',
        comparison: '对比分析',
        popularization: '知识科普',
        whitepaper: '品牌白皮书',
    };
    const label = ctLabel[contentType] || '文章';
    return `本文是关于${keyword}的${label}，由${brandName}为您详细解读。${description ? description.slice(0, 80) + '...' : ''}`;
}
//# sourceMappingURL=fallback-templates.js.map