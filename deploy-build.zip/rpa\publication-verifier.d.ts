import type { PlatformId } from '@zemingengine/shared';
import type { Page } from 'playwright';
export type VerificationStatus = 'verified' | 'unverified' | 'failed';
export interface VerificationResult {
    status: VerificationStatus;
    message: string;
}
/**
 * Post-publish publication verifier.
 *
 * Responsible for verifying that a published article is actually live
 * by navigating to its URL and checking for error indicators.
 */
export declare class PublicationVerifier {
    /**
     * Verify that a published article is actually live by navigating to its URL.
     */
    verifyPublication(page: Page, postUrl: string, platform: PlatformId): Promise<VerificationResult>;
}
//# sourceMappingURL=publication-verifier.d.ts.map