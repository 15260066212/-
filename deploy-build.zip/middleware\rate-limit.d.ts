import type { MiddlewareHandler } from 'hono';
import type { AppEnv } from '../db.js';
export declare function rateLimiter(): MiddlewareHandler<AppEnv>;
//# sourceMappingURL=rate-limit.d.ts.map