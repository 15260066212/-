/**
 * ReloginManager — Coordinates automatic re-login for platforms with
 * username/password login forms.
 *
 * Flow:
 * 1. Health checker detects expired session (3 consecutive failures)
 * 2. ReloginManager.attemptRelogin() is called
 * 3. Calls harvester's /api/rpa/relogin endpoint with stored credentials
 * 4. On success: updates credential data, marks as active
 * 5. On captcha: creates alert for manual intervention
 * 6. On failure: logs attempt, schedules retry with cooldown
 *
 * Supported platforms (auto-relogin): csdn, juejin, bilibili
 * Unsupported platforms (require manual): zhihu, baijia, toutiao, sohu, netease, zhidao
 */
import type { DatabaseAccess } from '../db.js';
interface ReloginResult {
    success: boolean;
    platform: string;
    errorType?: string;
    errorMessage?: string;
    cookieCount?: number;
    cookies?: string;
    screenshot?: string;
}
export declare class ReloginManager {
    private db;
    private alerter;
    private lastAttemptTime;
    private attemptCount;
    constructor(db: DatabaseAccess);
    /** Check if a platform supports automatic re-login. */
    isPlatformSupported(platform: string): boolean;
    /** Check if a relogin attempt is allowed (not in cooldown, under rate limit). */
    canAttempt(platform: string): boolean;
    /** Validate prerequisites and extract credentials; returns null with an error result if any check fails. */
    private checkPrerequisites;
    /** Record this attempt in cooldown and rate-limit tracking. */
    private recordAttempt;
    /** Call the harvester /api/rpa/relogin endpoint. */
    private callReloginApi;
    /** Persist successful relogin: update credentials, record attempt, invalidate browser session, alert. */
    private handleSuccess;
    /** Record failed relogin and create appropriate alert (captcha vs generic failure). */
    private handleFailure;
    /** Handle HTTP-level errors from the relogin API call. */
    private handleHttpError;
    /** Handle network/timeout exceptions from the relogin API call. */
    private handleNetworkError;
    attemptRelogin(platform: string, userId?: string): Promise<ReloginResult>;
    /**
     * Get the status of the relogin system.
     * Used by the monitor dashboard.
     */
    getStatus(): {
        supportedPlatforms: string[];
        cooldowns: Array<{
            platform: string;
            lastAttemptAt: number;
            cooldownEndsAt: number;
            remainingMin: number;
        }>;
        attemptHistory: Array<{
            platform: string;
            recentAttempts: number;
        }>;
    };
}
export {};
//# sourceMappingURL=relogin-manager.d.ts.map