import Database from 'better-sqlite3';
export type DB = InstanceType<typeof Database>;
import { SessionRepository, type SessionListItem as SessionListItemType } from './repositories/session-repository.js';
import { ArticleRepository } from './repositories/article-repository.js';
import { ReviewRepository } from './repositories/review-repository.js';
import { PublishRepository } from './repositories/publish-repository.js';
import { CredentialRepository } from './repositories/credential-repository.js';
import { SelectorRepository } from './repositories/selector-repository.js';
import { PipelineRepository } from './repositories/pipeline-repository.js';
import { MonitorRepository } from './repositories/monitor-repository.js';
import { UserRepository } from './repositories/user-repository.js';
import { PlanRepository } from './repositories/plan-repository.js';
export interface User {
    id: string;
    username: string;
    displayName: string;
    role: 'admin' | 'user';
    apiKey: string;
    passwordHash?: string;
    createdAt: string;
    lastActiveAt?: string;
}
export type SessionListItem = SessionListItemType;
/** Hono environment type for routes that need access to the authenticated user. */
export type AppEnv = {
    Variables: {
        user?: User;
    };
};
export declare function createDatabase(): DB;
/**
 * DatabaseAccess — holds the underlying DB connection and exposes the 10
 * domain repositories as public readonly properties.
 *
 * Consumers call repository methods directly, e.g. `db.articles.getArticle(id)`,
 * `db.sessions.upsertSession(...)`, keeping DatabaseAccess a thin composition
 * root rather than a God Object facade.
 *
 * Only cross-cutting concerns (transactions, health checks, connection
 * lifecycle) live on this class.
 */
export declare class DatabaseAccess {
    private db;
    readonly sessions: SessionRepository;
    readonly articles: ArticleRepository;
    readonly reviews: ReviewRepository;
    readonly publish: PublishRepository;
    readonly credentials: CredentialRepository;
    readonly selectors: SelectorRepository;
    readonly pipeline: PipelineRepository;
    readonly monitor: MonitorRepository;
    readonly users: UserRepository;
    readonly plans: PlanRepository;
    constructor(db: DB);
    /**
     * Wrap a function in a better-sqlite3 transaction.
     *
     * better-sqlite3's `transaction()` returns a reusable transaction function;
     * invoking it executes the transaction. If the wrapped function throws,
     * the transaction is automatically rolled back.
     */
    private wrapTransaction;
    /**
     * Public entry point for running multiple DB operations atomically.
     * Use this to group related writes that must succeed or fail together.
     *
     * @example
     * db.runInTransaction(() => {
     *   db.publish.updatePublishTask(id, { status: 'published' });
     *   db.articles.updateArticle(articleId, { status: 'published' });
     * });
     */
    runInTransaction<T>(fn: () => T): T;
    /**
     * Check the health of the database.
     *
     * Verifies that every expected table exists and is queryable, gathers
     * per-table row counts, and reports the WAL file size when available.
     * The check never throws - a table that fails to query is reported as
     * missing and marks the overall result as unhealthy.
     */
    healthCheck(): {
        healthy: boolean;
        details: Record<string, unknown>;
    };
    /** Close the underlying database connection. */
    close(): void;
}
//# sourceMappingURL=db.d.ts.map