import type { StageHandler } from '../types.js';
export declare const knowledgeStage: StageHandler;
//# sourceMappingURL=stage4-knowledge.d.ts.map