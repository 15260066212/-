export { WechatAdapter } from './wechat.js';
//# sourceMappingURL=index.d.ts.map