/**
 * Default constants and configuration values.
 */
import type { Stage } from '../types/session.types.js';
export declare const API_BASE_URL = "/api";
export declare const SESSION_STORAGE_KEY = "zemingengine_session";
export declare const STAGE_DISPLAY_NAMES: Record<Stage, string>;
export declare const STAGE_DESCRIPTIONS: Record<Stage, string>;
//# sourceMappingURL=defaults.d.ts.map