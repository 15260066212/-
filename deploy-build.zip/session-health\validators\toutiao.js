import { HarvesterBrowserValidator } from './harvester-browser.js';
export class ToutiaoValidator extends HarvesterBrowserValidator {
    platform = 'toutiao';
    get harvesterPlatform() {
        return 'toutiaohao';
    }
}
//# sourceMappingURL=toutiao.js.map