import Database from 'better-sqlite3';
import { existsSync, mkdirSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { initDatabase } from './schema.js';
import { SessionRepository } from './repositories/session-repository.js';
import { ArticleRepository } from './repositories/article-repository.js';
import { ReviewRepository } from './repositories/review-repository.js';
import { PublishRepository } from './repositories/publish-repository.js';
import { CredentialRepository } from './repositories/credential-repository.js';
import { SelectorRepository } from './repositories/selector-repository.js';
import { PipelineRepository } from './repositories/pipeline-repository.js';
import { MonitorRepository } from './repositories/monitor-repository.js';
import { UserRepository } from './repositories/user-repository.js';
import { PlanRepository } from './repositories/plan-repository.js';
const __dirname = dirname(fileURLToPath(import.meta.url));
const DB_PATH = process.env.DATABASE_PATH ?? join(__dirname, '../../data/geo-assistant.db');
export function createDatabase() {
    const dir = dirname(DB_PATH);
    if (!existsSync(dir))
        mkdirSync(dir, { recursive: true });
    const db = new Database(DB_PATH);
    initDatabase(db);
    return db;
}
/**
 * DatabaseAccess — holds the underlying DB connection and exposes the 10
 * domain repositories as public readonly properties.
 *
 * Consumers call repository methods directly, e.g. `db.articles.getArticle(id)`,
 * `db.sessions.upsertSession(...)`, keeping DatabaseAccess a thin composition
 * root rather than a God Object facade.
 *
 * Only cross-cutting concerns (transactions, health checks, connection
 * lifecycle) live on this class.
 */
export class DatabaseAccess {
    db;
    sessions;
    articles;
    reviews;
    publish;
    credentials;
    selectors;
    pipeline;
    monitor;
    users;
    plans;
    constructor(db) {
        this.db = db;
        this.sessions = new SessionRepository(db);
        this.articles = new ArticleRepository(db);
        this.reviews = new ReviewRepository(db);
        this.publish = new PublishRepository(db);
        this.credentials = new CredentialRepository(db);
        this.selectors = new SelectorRepository(db);
        this.pipeline = new PipelineRepository(db);
        this.monitor = new MonitorRepository(db);
        this.users = new UserRepository(db);
        this.plans = new PlanRepository(db);
    }
    // === Transactions ===
    /**
     * Wrap a function in a better-sqlite3 transaction.
     *
     * better-sqlite3's `transaction()` returns a reusable transaction function;
     * invoking it executes the transaction. If the wrapped function throws,
     * the transaction is automatically rolled back.
     */
    wrapTransaction(fn) {
        return this.db.transaction(fn)();
    }
    /**
     * Public entry point for running multiple DB operations atomically.
     * Use this to group related writes that must succeed or fail together.
     *
     * @example
     * db.runInTransaction(() => {
     *   db.publish.updatePublishTask(id, { status: 'published' });
     *   db.articles.updateArticle(articleId, { status: 'published' });
     * });
     */
    runInTransaction(fn) {
        return this.wrapTransaction(fn);
    }
    // === Health Check ===
    /**
     * Check the health of the database.
     *
     * Verifies that every expected table exists and is queryable, gathers
     * per-table row counts, and reports the WAL file size when available.
     * The check never throws - a table that fails to query is reported as
     * missing and marks the overall result as unhealthy.
     */
    healthCheck() {
        const tables = [
            'sessions',
            'articles',
            'reviews',
            'publish_tasks',
            'publish_logs',
            'platform_credentials',
            'pipeline_runs',
            'schema_version',
            'users',
        ];
        const tableExists = {};
        const tableCounts = {};
        let healthy = true;
        for (const table of tables) {
            try {
                // Verify the table is queryable
                this.db.prepare(`SELECT 1 FROM ${table} LIMIT 1`).get();
                tableExists[table] = true;
                const row = this.db.prepare(`SELECT COUNT(*) as c FROM ${table}`).get();
                tableCounts[table] = Number(row.c) || 0;
            }
            catch {
                tableExists[table] = false;
                tableCounts[table] = 0;
                healthy = false;
            }
        }
        // Report WAL file size when the database is file-backed
        let walSize = null;
        try {
            const walPath = `${DB_PATH}-wal`;
            if (existsSync(walPath)) {
                walSize = statSync(walPath).size;
            }
        }
        catch {
            // WAL file may not exist (e.g. in-memory db or not yet created) - ignore
        }
        return {
            healthy,
            details: {
                tables: tableCounts,
                tableExists,
                walSize,
            },
        };
    }
    /** Close the underlying database connection. */
    close() {
        this.db.close();
    }
}
//# sourceMappingURL=db.js.map