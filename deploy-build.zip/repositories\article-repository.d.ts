import type { DB } from '../db.js';
import type { Article, ArticleStatus } from '@zemingengine/shared';
export declare class ArticleRepository {
    private db;
    constructor(db: DB);
    insertArticle(article: Article): void;
    updateArticle(id: string, updates: Partial<Article>): void;
    getArticle(id: string): Article | undefined;
    getArticlesBySession(sessionId: string): Article[];
    getArticlesByStatus(status: ArticleStatus): Article[];
    /**
     * Query articles matching any of the given statuses.
     * Returns an empty array when no statuses are provided.
     */
    getArticlesByStatuses(statuses: ArticleStatus[]): Article[];
    private mapArticle;
}
//# sourceMappingURL=article-repository.d.ts.map