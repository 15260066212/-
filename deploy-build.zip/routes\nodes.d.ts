/**
 * Node Management Routes — 节点管理 & 云端部署 API
 *
 * 节点（harvester 单机）通过这些 API 注册、心跳、拉取部署任务。
 * 管理员通过这些 API 查看节点状态、发起批量部署。
 *
 * Mounted at: /api/nodes
 */
import { Hono } from 'hono';
import type { AppEnv } from '../db.js';
import { NodeRegistry } from '../node-registry.js';
export declare function createNodeRoutes(registry: NodeRegistry): Hono<AppEnv>;
//# sourceMappingURL=nodes.d.ts.map