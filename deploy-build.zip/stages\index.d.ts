import type { StageHandler } from '../types.js';
export declare const stageHandlers: StageHandler[];
export declare function getStageHandler(stage: string): StageHandler | undefined;
//# sourceMappingURL=index.d.ts.map