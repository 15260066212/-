import type { DB } from '../db.js';
import type { PlatformCredentials } from '@zemingengine/shared';
export declare class CredentialRepository {
    private db;
    constructor(db: DB);
    /**
     * Upsert a credential. If accountId is not provided, defaults to 'default'.
     */
    upsertCredential(platform: string, cred: PlatformCredentials, userId?: string): void;
    /** Upsert a credential for a specific user (explicit userId). */
    upsertCredentialForUser(userId: string, platform: string, cred: PlatformCredentials): void;
    /** Save a browser session's storageState (encrypted) for reuse. */
    saveBrowserSession(accountId: string, platform: string, storageState: string, fingerprintId?: string): void;
    /** Load a saved browser session for the given account + platform. */
    getBrowserSession(accountId: string, platform: string): {
        storageState: string;
        valid: boolean;
        savedAt: number;
        maxAge?: number;
    } | null;
    /**
     * Map a database row to PlatformCredentials.
     */
    private rowToCredential;
    /**
     * Get a credential by platform and accountId.
     * If accountId is not provided, returns the 'default' account.
     */
    getCredential(platform: string, userId?: string, accountId?: string): PlatformCredentials | undefined;
    updateCredentialStatus(platform: string, status: string, userId?: string, accountId?: string): void;
    deleteCredential(platform: string, userId?: string, accountId?: string): void;
    getAllCredentials(userId?: string): PlatformCredentials[];
    /** Get all credentials for a specific user. */
    getCredentialsByUser(userId: string): PlatformCredentials[];
    /** Get credentials filtered by brand ID. */
    getCredentialsByBrand(brandId: number, userId?: string): PlatformCredentials[];
    /** Get all credentials for a specific platform (all accounts). */
    getCredentialsByPlatform(platform: string, userId?: string): PlatformCredentials[];
    /**
     * Get credentials that are due for a health check.
     * Returns credentials where last_checked_at is null or older than check_interval_ms,
     * limited to batchSize, ordered by last_checked_at ASC (oldest first).
     */
    getCredentialsDueForCheck(batchSize?: number, userId?: string): PlatformCredentials[];
    /** Record the result of a health check. */
    recordHealthCheck(platform: string, status: 'valid' | 'expired' | 'checking' | 'error', durationMs: number, errorMessage?: string, userId?: string): void;
    /** Get credential health statistics for the monitor dashboard. */
    getCredentialHealthStats(): {
        total: number;
        valid: number;
        checking: number;
        expired: number;
        invalid: number;
        byPlatform: Array<{
            platform: string;
            total: number;
            valid: number;
            expired: number;
            healthRate: number;
        }>;
    };
    /** Get detailed health info for a credential including consecutive failures. */
    getCredentialHealthDetail(platform: string, userId?: string): {
        platform: string;
        status: string;
        lastCheckStatus: string;
        consecutiveFailures: number;
        lastCheckedAt: number | null;
        checkError: string | null;
        lastValidatedAt: string | null;
    } | undefined;
    /** Get the consecutive failure count for a credential. */
    getConsecutiveFailures(platform: string, userId?: string): number;
    /** Explicitly mark a credential as expired with a reason. */
    markCredentialExpired(platform: string, reason: string, userId?: string): void;
    /** Get recent health check logs, optionally filtered by platform. */
    getHealthLogs(limit?: number, platform?: string, userId?: string): Array<{
        id: number;
        platform: string;
        userId: string;
        status: string;
        durationMs: number;
        errorMessage: string | null;
        checkedAt: number;
    }>;
    /** Insert a health alert. */
    insertHealthAlert(platform: string, alertType: string, message: string, userId?: string): number;
    /** Get unsent alerts. */
    getUnsentAlerts(): Array<{
        id: number;
        platform: string;
        userId: string;
        alertType: string;
        message: string;
        createdAt: string;
    }>;
    /** Mark an alert as sent. */
    markAlertSent(alertId: number): void;
    /** Get alert statistics. */
    getAlertStats(): {
        total: number;
        unsent: number;
        sent: number;
    };
    /** Record a relogin attempt result. */
    recordReloginAttempt(platform: string, userId: string, success: boolean, errorType?: string, errorMessage?: string, cookieCount?: number): void;
    /** Get recent relogin attempts. */
    getReloginLogs(limit?: number, platform?: string): Array<{
        id: number;
        platform: string;
        userId: string;
        success: boolean;
        errorType: string | null;
        errorMessage: string | null;
        cookieCount: number | null;
        attemptedAt: number;
    }>;
    /** Get relogin statistics. */
    getReloginStats(): {
        total: number;
        successful: number;
        failed: number;
        byPlatform: Array<{
            platform: string;
            total: number;
            success: number;
            failed: number;
            successRate: number;
        }>;
    };
    /** Get all credentials for a platform across all accounts (for dynamic account allocation). */
    getAllCredentialsForPlatform(platform: string, userId?: string): PlatformCredentials[];
    /** Get all active credentials for a platform (for dynamic account allocation). */
    getActiveCredentialsForPlatform(platform: string, userId?: string): PlatformCredentials[];
    /** Get active credentials for a platform filtered by brand ID. */
    getActiveCredentialsForPlatformAndBrand(platform: string, brandId: number, userId?: string): PlatformCredentials[];
    /** Update credential data (e.g., after successful relogin with new cookies). */
    updateCredentialData(platform: string, data: Record<string, string>, userId?: string, accountId?: string): void;
    /** Invalidate a browser session (mark as invalid so next acquire creates fresh context). */
    invalidateBrowserSession(accountId: string, platform: string): void;
}
//# sourceMappingURL=credential-repository.d.ts.map