/**
 * Basic Markdown to HTML conversion utility.
 *
 * This is a lightweight converter for common Markdown syntax used in
 * article publishing. It is intentionally dependency-free to keep the
 * publisher package lightweight.
 *
 * Supported syntax:
 * - Headings: # h1, ## h2, ### h3
 * - Bold: **text**
 * - Italic: *text*
 * - Links: [text](url)
 * - Code blocks: ``` ... ```
 * - Inline code: `code`
 * - Blockquotes: > quote
 * - Unordered lists: - item, * item
 * - Paragraphs (double newline)
 */
export declare function markdownToHtml(markdown: string): string;
//# sourceMappingURL=markdown.d.ts.map