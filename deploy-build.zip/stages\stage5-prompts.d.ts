import type { StageHandler } from '../types.js';
export declare const promptsStage: StageHandler;
//# sourceMappingURL=stage5-prompts.d.ts.map