/**
 * Publishing Strategy Service — GEO Publishing Strategy Engine
 *
 * Based on citation source weight analysis across 6 major Chinese LLM platforms.
 * Guides users on where to publish content for maximum AI citation visibility.
 *
 * Data sources:
 * - CSDN 2026.03 four-platform field test
 * - xfunnel 250K citation study
 * - Profound 680M citation analysis
 * - Binance cross-check data
 * See: https://fp8.co/articles/AI-Citation-Source-Preferences-GEO-Data-Map
 */
interface PlatformCitationProfile {
    platform: string;
    label: string;
    topSources: {
        source: string;
        label: string;
        weight: number;
    }[];
    freshnessWindow: string;
    walledGarden: boolean;
    contentFormat: string;
}
interface StrategyRecommendation {
    platform: string;
    priority: 'high' | 'medium' | 'low';
    actions: string[];
    rationale: string;
}
interface PublishingStrategy {
    targetPlatforms: StrategyRecommendation[];
    universalActions: string[];
    contentFormatTips: {
        platform: string;
        tip: string;
    }[];
    freshnessGuidance: {
        platform: string;
        window: string;
        action: string;
    }[];
}
export declare class PublishingStrategyService {
    /**
     * Get the citation profile for a specific platform.
     */
    getPlatformProfile(platform: string): PlatformCitationProfile | null;
    /**
     * Generate publishing strategy recommendations for a set of target platforms.
     */
    generateStrategy(targetPlatforms: string[]): PublishingStrategy;
    /**
     * Get a quick summary of which platforms to prioritize for a given industry.
     */
    getIndustryPriority(industry: string): {
        platforms: string[];
        reason: string;
    };
}
export declare const publishingStrategyService: PublishingStrategyService;
export {};
//# sourceMappingURL=publishing-strategy-service.d.ts.map