import { Hono } from 'hono';
import type { DatabaseAccess } from '../db.js';
export declare function createMessageRoutes(db: DatabaseAccess): Hono;
//# sourceMappingURL=message.d.ts.map