import { PlatformAdapter } from './base.js';
export class BaiduZhidaoAdapter extends PlatformAdapter {
    constructor() {
        super('zhidao');
    }
    getMethod() {
        return 'rpa';
    }
    async publish(_params) {
        return {
            success: true,
            postId: 'mock_rpa_post_id',
            postUrl: 'https://example.com',
        };
    }
}
//# sourceMappingURL=baidu-zhidao.js.map