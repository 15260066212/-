import { HarvesterBrowserValidator } from './harvester-browser.js';
export declare class JuejinValidator extends HarvesterBrowserValidator {
    readonly platform: "juejin";
}
//# sourceMappingURL=juejin.d.ts.map