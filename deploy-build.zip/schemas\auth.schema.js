import { createHash } from 'node:crypto';
// ---------------------------------------------------------------------------
// Users / Auth
// ---------------------------------------------------------------------------
export function initUserTables(db, currentVersion) {
    // Migration v4 (partial): multi-user support - users table + default admin
    if (currentVersion < 4) {
        // Create users table
        db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        display_name TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        api_key TEXT NOT NULL UNIQUE,
        created_at TEXT NOT NULL,
        last_active_at TEXT
      );
    `);
        // Create default admin user with secure random API key
        const defaultUser = db.prepare('SELECT id FROM users WHERE id = ?').get('user_default');
        if (!defaultUser) {
            // Use env var if provided, otherwise generate a secure random key
            const defaultApiKey = process.env.DEFAULT_ADMIN_API_KEY
                ?? `geo-${Date.now()}-${crypto.randomUUID().replace(/-/g, '')}`;
            db.prepare('INSERT INTO users (id, username, display_name, role, api_key, created_at) VALUES (?, ?, ?, ?, ?, ?)').run('user_default', 'hsq', 'Administrator', 'admin', defaultApiKey, new Date().toISOString());
            console.log(`[DB] Default admin user created with API key: ${defaultApiKey.slice(0, 8)}... (set DEFAULT_ADMIN_API_KEY to customize)`);
        }
        db.prepare('INSERT INTO schema_version (version, applied_at) VALUES (?, ?)').run(4, new Date().toISOString());
        console.log('[DB] Migration v4 applied: added multi-user support');
    }
    // Migration v15: password_hash column on users for username/password login
    const row15 = db.prepare('SELECT version FROM schema_version WHERE version = ?').get(15);
    if (!row15) {
        // Add password_hash column (SQLite ADD COLUMN is safe if not exists)
        try {
            db.exec('ALTER TABLE users ADD COLUMN password_hash TEXT');
        }
        catch {
            // Column may already exist
        }
        // Set default admin password hash (XTGEO123)
        const hash = createHash('sha256').update('XTGEO123').digest('hex');
        db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, 'user_default');
        // Ensure all users without a password get the default too
        db.prepare('UPDATE users SET password_hash = ? WHERE password_hash IS NULL').run(hash);
        db.prepare('INSERT INTO schema_version (version, applied_at) VALUES (?, ?)').run(15, new Date().toISOString());
        console.log('[DB] Migration v15 applied: password_hash on users');
    }
}
//# sourceMappingURL=auth.schema.js.map