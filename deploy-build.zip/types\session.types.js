/**
 * Session-related type definitions and stage constants.
 */
// === Stage definitions ===
export const STAGES = [
    'intro',
    'profile',
    'keywords',
    'knowledge',
];
/** @deprecated Use STAGES instead. Retained for backward compatibility only. */
export const LEGACY_STAGES = [
    'wordbank',
    'prompts',
    'platforms',
];
export function createEmptySession(id) {
    return {
        id,
        currentStage: 'intro',
        enterprise: {
            fullName: '',
            shortName: '',
            description: '',
            scale: '',
            location: '',
            foundedYear: '',
            website: '',
            products: [],
            brandStory: '',
            trustAnchors: [],
            brandTone: [],
            userPainPoints: [],
        },
        confirmedProfileFields: [],
        keywords: [],
        wordBank: { brandTerms: [], productTerms: [], industryTerms: [], prefixes: [], suffixes: [] },
        knowledgeBase: { documents: [], images: [], tags: [] },
        promotionGoal: {
            productName: '',
            positioning: '',
            coreValue: '',
            targetUsers: '',
            coreSellingPoint: '',
        },
        audienceSegments: [],
        keywordStrategy: {
            categories: [],
            distillation: {
                seedKeyword: '',
                quantity: 30,
                mode: '精准模式',
                questionTypes: [],
            },
            combinations: [],
            questionMappings: [],
        },
        knowledgePlan: [],
        imagePlan: [],
        contentPlaybook: [],
        trackingPlan: {
            metrics: [],
            weeklyReview: [],
            contentOptimization: [],
            keywordOptimization: [],
            platformOptimization: [],
            publishChecklist: [],
            weeklyChecklist: [],
        },
        prompts: [],
        platforms: [],
    };
}
//# sourceMappingURL=session.types.js.map