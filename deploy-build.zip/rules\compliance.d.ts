import type { Article, ReviewIssue } from '@zemingengine/shared';
export declare function checkCompliance(article: Article): ReviewIssue[];
//# sourceMappingURL=compliance.d.ts.map