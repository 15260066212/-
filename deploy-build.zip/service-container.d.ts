import { Hono } from 'hono';
import { Publisher } from '@zemingengine/publisher';
import type { AppEnv } from './db.js';
import { CachedDatabaseAccess } from './cached-db.js';
import { SessionPoolAdapter } from './session-pool-adapter.js';
import { ReloginManager, SelectorMonitor, CaptchaManager } from './session-health/index.js';
export interface ServiceContainer {
    db: CachedDatabaseAccess;
    app: Hono<AppEnv>;
    publisher: Publisher;
    sessionPool: SessionPoolAdapter;
    reloginManager: ReloginManager;
    selectorMonitor: SelectorMonitor;
    captchaManager: CaptchaManager;
}
/** Create and wire all services, mount routes, return the container. */
export declare function createServices(): ServiceContainer;
//# sourceMappingURL=service-container.d.ts.map