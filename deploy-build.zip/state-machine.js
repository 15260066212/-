import { STAGES } from '@zemingengine/shared';
import { getStageHandler, stageHandlers } from './stages/index.js';
let messageCounter = 0;
function nextId() {
    return `msg_${Date.now()}_${++messageCounter}`;
}
export class DialogueEngine {
    session;
    currentQuestionId = null;
    constructor(session) {
        this.session = session;
        this.initQuestionId();
    }
    initQuestionId() {
        const handler = getStageHandler(this.session.currentStage);
        if (handler && handler.questions.length > 0) {
            this.currentQuestionId = handler.questions[0].id;
        }
    }
    getSession() {
        return { ...this.session };
    }
    setSession(session) {
        this.session = session;
    }
    getCurrentStage() {
        return this.session.currentStage;
    }
    getCurrentQuestionId() {
        return this.currentQuestionId;
    }
    setCurrentQuestionId(questionId) {
        this.currentQuestionId = questionId;
    }
    getProgress() {
        const currentIndex = STAGES.findIndex((stage) => stage === this.session.currentStage);
        return { current: currentIndex, total: STAGES.length };
    }
    getIntroMessage() {
        const handler = getStageHandler(this.session.currentStage);
        const content = handler
            ? handler.getIntroMessage(this.session)
            : '欢迎使用 芯图引擎：GEO 配置教练！';
        return {
            id: nextId(),
            role: 'system',
            content,
            stage: this.session.currentStage,
            timestamp: new Date().toISOString(),
        };
    }
    async handleUserInput(input) {
        const handler = getStageHandler(this.session.currentStage);
        if (!handler) {
            return {
                messages: [
                    {
                        id: nextId(),
                        role: 'system',
                        content: '当前阶段配置有误，请重试。',
                        stage: this.session.currentStage,
                        timestamp: new Date().toISOString(),
                    },
                ],
                isComplete: false,
            };
        }
        const questionId = this.currentQuestionId ?? handler.questions[0].id;
        const result = await handler.handleInput(this.session, questionId, input);
        // Update session
        this.session = result.sessionData;
        // Update question pointer
        if (result.stageComplete) {
            // Move to next stage's first question
            const nextHandler = getStageHandler(this.session.currentStage);
            this.currentQuestionId = nextHandler?.questions[0]?.id ?? null;
        }
        else if (result.preserveQuestion) {
            // Keep the same question (e.g., pending update awaiting confirmation)
            this.currentQuestionId = questionId;
        }
        else if (result.nextQuestionId !== undefined) {
            this.currentQuestionId = result.nextQuestionId;
        }
        else if (!result.messages.some((message) => message.role === 'user')) {
            // Validation and retry messages should keep the same question active.
            this.currentQuestionId = questionId;
        }
        else {
            // Move to next question in current stage
            const currentIndex = handler.questions.findIndex((q) => q.id === questionId);
            const nextQ = handler.questions[currentIndex + 1];
            this.currentQuestionId = nextQ?.id ?? null;
        }
        return {
            messages: result.messages,
            isComplete: result.allComplete,
        };
    }
    getStageHandlers() {
        return stageHandlers;
    }
}
//# sourceMappingURL=state-machine.js.map