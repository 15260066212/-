import { DEFAULT_REVIEW_WEIGHTS } from '@zemingengine/shared';
import { checkCompliance } from './rules/compliance.js';
import { checkQuality } from './rules/quality.js';
import { checkSEO } from './rules/seo.js';
import { checkBrand } from './rules/brand.js';
import { checkOriginality } from './rules/originality.js';
import { checkPlatformAdaptation } from './rules/platform-adaptation.js';
import { checkReadability } from './rules/readability.js';
import { checkSafety } from './rules/safety.js';
import { calculateScore, calculateWeightedScore } from './scorer.js';
import { createHash } from 'crypto';
/** Compute SHA-256 hash of review result for tamper detection. */
export function computeReviewHash(data) {
    const payload = `${data.articleId}:${data.overallScore}:${data.passed}:${data.issuesCount}:${data.reviewedAt}`;
    return createHash('sha256').update(payload).digest('hex').substring(0, 16);
}
/** Verify that a review result's content hash matches. */
export function verifyReviewHash(review) {
    if (!review.contentHash)
        return false;
    const expected = computeReviewHash({
        articleId: review.articleId,
        overallScore: review.overallScore,
        passed: review.passed,
        issuesCount: review.issues?.length ?? 0,
        reviewedAt: review.reviewedAt,
    });
    return expected === review.contentHash;
}
export class ContentReviewer {
    passThreshold;
    weights;
    constructor(options) {
        this.passThreshold = options?.passThreshold ?? 70;
        this.weights = options?.weights ?? DEFAULT_REVIEW_WEIGHTS;
    }
    review(article, session) {
        // Collect issues from all 8 dimensions
        const complianceIssues = checkCompliance(article);
        const qualityIssues = checkQuality(article);
        const seoIssues = checkSEO(article, session);
        const brandIssues = checkBrand(article, session);
        const originalityIssues = checkOriginality(article);
        const platformAdaptationIssues = checkPlatformAdaptation(article);
        const readabilityIssues = checkReadability(article);
        const safetyIssues = checkSafety(article);
        const allIssues = [
            ...complianceIssues,
            ...qualityIssues,
            ...seoIssues,
            ...brandIssues,
            ...originalityIssues,
            ...platformAdaptationIssues,
            ...readabilityIssues,
            ...safetyIssues,
        ];
        // Calculate scores for each dimension
        const compliance = calculateScore(allIssues, 'compliance');
        const quality = calculateScore(allIssues, 'quality');
        const seo = calculateScore(allIssues, 'seo');
        const brand = calculateScore(allIssues, 'brand');
        const originality = calculateScore(allIssues, 'originality');
        const platform_adaptation = calculateScore(allIssues, 'platform_adaptation');
        const readability = calculateScore(allIssues, 'readability');
        const safety = calculateScore(allIssues, 'safety');
        const dimensions = {
            compliance,
            quality,
            seo,
            brand,
            originality,
            platform_adaptation,
            readability,
            safety,
        };
        // Calculate weighted overall score
        const overallScore = calculateWeightedScore(dimensions, this.weights);
        // Veto conditions: certain critical issues auto-fail regardless of overall score
        // 1. High-severity compliance issues (illegal/sensitive content)
        const hasHighSeverityCompliance = complianceIssues.some((i) => i.severity === 'high');
        // 2. High-severity platform adaptation issues (content doesn't meet platform minimum requirements)
        const hasHighSeverityPlatform = platformAdaptationIssues.some((i) => i.severity === 'high');
        // 3. High-severity safety issues (misleading claims, missing disclaimers)
        const hasHighSeveritySafety = safetyIssues.some((i) => i.severity === 'high');
        // 4. Any dimension scoring below 50 (critical failure in a single dimension)
        const minDimensionScore = Math.min(compliance.score, quality.score, seo.score, brand.score, originality.score, platform_adaptation.score, readability.score, safety.score);
        const passed = overallScore >= this.passThreshold &&
            !hasHighSeverityCompliance &&
            !hasHighSeverityPlatform &&
            !hasHighSeveritySafety &&
            minDimensionScore >= 50;
        // Extract all unique suggestions
        const suggestionsSet = new Set();
        for (const issue of allIssues) {
            if (issue.suggestion) {
                suggestionsSet.add(issue.suggestion);
            }
        }
        const suggestions = Array.from(suggestionsSet);
        // Compute content hash for tamper detection
        const contentHash = computeReviewHash({
            articleId: article.id,
            overallScore,
            passed,
            issuesCount: allIssues.length,
            reviewedAt: new Date().toISOString(),
        });
        return {
            articleId: article.id,
            round: article.generationRound,
            passed,
            overallScore,
            dimensions,
            issues: allIssues,
            suggestions,
            reviewedAt: new Date().toISOString(),
            contentHash,
        };
    }
}
//# sourceMappingURL=reviewer.js.map