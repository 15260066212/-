import { Hono } from 'hono';
import type { DatabaseAccess } from '../db.js';
export declare function createScrapeRoutes(db: DatabaseAccess): Hono;
//# sourceMappingURL=scrape.d.ts.map