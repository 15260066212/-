import type { Article, ReviewIssue } from '@zemingengine/shared';
/**
 * Check article content for safety and trust issues.
 */
export declare function checkSafety(article: Article): ReviewIssue[];
//# sourceMappingURL=safety.d.ts.map