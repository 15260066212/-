import type { DB } from '../db.js';
export declare function initMonitorTables(db: DB, currentVersion: number): void;
//# sourceMappingURL=competitor-monitor.schema.d.ts.map