import { PlatformAdapter } from './base.js';
import type { PublishParams, PublishResult } from '../types.js';
export declare class ZhihuAdapter extends PlatformAdapter {
    constructor();
    getMethod(): 'api' | 'rpa';
    publish(_params: PublishParams): Promise<PublishResult>;
}
//# sourceMappingURL=zhihu.d.ts.map