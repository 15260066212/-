import { BaseValidator } from './base.js';
export class HarvesterBrowserValidator extends BaseValidator {
    platform;
    /** Database access for saving refreshed cookies / storageState / fingerprint */
    db;
    /** Harvester service platform ID, if different from system platform ID */
    _harvesterPlatform;
    constructor(platform, harvesterPlatform) {
        super();
        this.platform = platform;
        this._harvesterPlatform = harvesterPlatform;
    }
    /** Inject database access for cookie refresh on successful check */
    setDatabase(db) {
        this.db = db;
    }
    /** Harvester service platform ID, if different from system platform ID */
    get harvesterPlatform() {
        return this._harvesterPlatform ?? this.platform;
    }
    /** Build the request body from credentials, preferring storageState over raw cookies. */
    buildRequestBody(credentials) {
        const cookie = credentials.data.cookie || credentials.data.cookies || '';
        const storageState = credentials.data.storageState || '';
        const fingerprintData = credentials.data.fingerprintData || '';
        if (!cookie && !storageState) {
            return null;
        }
        const body = { platform: this.harvesterPlatform };
        if (storageState) {
            body.storageState = storageState;
        }
        else if (cookie) {
            body.cookies = cookie;
        }
        if (fingerprintData) {
            body.fingerprintData = fingerprintData;
        }
        return body;
    }
    /** Call the harvester's /api/rpa/check-session endpoint. */
    async callCheckSession(harvesterUrl, body) {
        const checkUrl = `${harvesterUrl.replace(/\/+$/, '')}/api/rpa/check-session`;
        const res = await fetch(checkUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            signal: AbortSignal.timeout(45000),
        });
        if (!res.ok) {
            const text = await res.text().catch(() => '');
            throw new Error(`Harvester returned HTTP ${res.status}: ${text.slice(0, 200)}`);
        }
        return (await res.json());
    }
    /** If session is valid, attempt cookie refresh and persist updated credentials. */
    async refreshCookies(harvesterUrl, body, credentials) {
        if (!this.db)
            return;
        try {
            const refreshUrl = `${harvesterUrl.replace(/\/+$/, '')}/api/rpa/refresh-cookies`;
            const refreshRes = await fetch(refreshUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
                signal: AbortSignal.timeout(30000),
            });
            if (!refreshRes.ok)
                return;
            const refreshData = (await refreshRes.json());
            if (!refreshData.success || !refreshData.valid)
                return;
            const updateData = {};
            const accountId = credentials.accountId || 'default';
            const userId = credentials.brandId ? 'user_default' : 'user_default';
            if (refreshData.refreshedStorageState) {
                updateData.storageState = refreshData.refreshedStorageState;
                if (refreshData.refreshedCookies) {
                    updateData.cookie = refreshData.refreshedCookies;
                }
            }
            else if (refreshData.refreshedCookies) {
                updateData.cookie = refreshData.refreshedCookies;
            }
            if (refreshData.refreshedFingerprintData) {
                updateData.fingerprintData = refreshData.refreshedFingerprintData;
            }
            if (Object.keys(updateData).length > 0) {
                this.db.credentials.updateCredentialData(this.platform, updateData, userId, accountId);
                console.log(`[HealthCheck] State refreshed and saved for ${this.platform}:${accountId}`);
            }
        }
        catch (refreshErr) {
            console.warn(`[HealthCheck] Refresh failed for ${this.platform}:`, refreshErr instanceof Error ? refreshErr.message : refreshErr);
        }
    }
    async validate(credentials) {
        const { result, durationMs } = await this.measure(async () => {
            const harvesterUrl = process.env.RPA_REMOTE_URL;
            if (!harvesterUrl) {
                return { valid: true, error: undefined };
            }
            const body = this.buildRequestBody(credentials);
            if (!body) {
                return { valid: false, error: 'No cookie or storageState found in credentials' };
            }
            try {
                const data = await this.callCheckSession(harvesterUrl, body);
                if (!data.success) {
                    return { valid: false, error: data.error || 'Harvester check failed' };
                }
                if (data.valid) {
                    await this.refreshCookies(harvesterUrl, body, credentials);
                }
                return {
                    valid: data.valid,
                    error: data.valid ? undefined : data.reason || 'Session expired',
                    evidence: {
                        pageTitle: data.pageTitle,
                        finalUrl: data.finalUrl,
                        screenshot: data.screenshot,
                    },
                };
            }
            catch (err) {
                return {
                    valid: false,
                    error: `Harvester check error: ${err instanceof Error ? err.message : String(err)}`,
                };
            }
        });
        return {
            ...result,
            durationMs,
        };
    }
}
//# sourceMappingURL=harvester-browser.js.map