import { PlatformAdapter } from './base.js';
export class ZhihuAdapter extends PlatformAdapter {
    constructor() {
        super('zhihu');
    }
    getMethod() {
        return 'rpa';
    }
    async publish(_params) {
        return {
            success: true,
            postId: 'mock_rpa_post_id',
            postUrl: 'https://example.com',
        };
    }
}
//# sourceMappingURL=zhihu.js.map