import type { DB } from '../db.js';
export declare function initPipelineTables(db: DB, currentVersion: number): void;
//# sourceMappingURL=pipeline.schema.d.ts.map