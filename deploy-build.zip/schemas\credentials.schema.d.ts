import type { DB } from '../db.js';
/** Default credential health check interval (6 hours in milliseconds) */
export declare const DEFAULT_CREDENTIAL_CHECK_INTERVAL_MS: number;
export declare function initCredentialsTable(db: DB, currentVersion: number): void;
//# sourceMappingURL=credentials.schema.d.ts.map