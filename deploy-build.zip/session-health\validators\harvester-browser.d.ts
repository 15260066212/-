import type { PlatformCredentials, PlatformId } from '@zemingengine/shared';
import { BaseValidator } from './base.js';
import type { ValidationResult } from '../types.js';
import type { DatabaseAccess } from '../../db.js';
export declare class HarvesterBrowserValidator extends BaseValidator {
    readonly platform: PlatformId;
    /** Database access for saving refreshed cookies / storageState / fingerprint */
    protected db?: DatabaseAccess;
    /** Harvester service platform ID, if different from system platform ID */
    private readonly _harvesterPlatform?;
    constructor(platform: PlatformId, harvesterPlatform?: string);
    /** Inject database access for cookie refresh on successful check */
    setDatabase(db: DatabaseAccess): void;
    /** Harvester service platform ID, if different from system platform ID */
    protected get harvesterPlatform(): string;
    /** Build the request body from credentials, preferring storageState over raw cookies. */
    private buildRequestBody;
    /** Call the harvester's /api/rpa/check-session endpoint. */
    private callCheckSession;
    /** If session is valid, attempt cookie refresh and persist updated credentials. */
    private refreshCookies;
    validate(credentials: PlatformCredentials): Promise<ValidationResult>;
}
//# sourceMappingURL=harvester-browser.d.ts.map