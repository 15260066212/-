import { type Article, type PlatformCredentials } from '@zemingengine/shared';
import type { Page } from 'playwright';
import type { PublishResult } from '../types.js';
import { RpaHandler } from './base.js';
/**
 * Baidu Zhidao (百度知道) RPA handler - publishes Q&A content via browser automation.
 * Requires cookie-based authentication (BAIDUID, BDUSS, STOKEN, etc.)
 *
 * Supports two publishing modes:
 * 1. **Ask mode** (default): Post a new question. Article.title = question text.
 * 2. **Answer mode**: Answer an existing question. Requires `questionUrl` in
 *    credentials.data or article metadata. Article.contentMarkdown = answer text.
 *
 * The mode is determined by:
 * - If `credentials.data.questionUrl` exists → answer mode
 * - Otherwise → ask mode
 *
 * Publishing flow (Ask mode):
 * 1. Navigate to https://zhidao.baidu.com/ask
 * 2. Fill in question title
 * 3. Optionally fill in supplementary details
 * 4. Select category if prompted
 * 5. Click submit button
 * 6. Extract the question URL and ID
 *
 * Publishing flow (Answer mode):
 * 1. Navigate to the question URL
 * 2. Click "我来回答" or locate the answer editor
 * 3. Fill in the answer content
 * 4. Click submit button
 * 5. Extract the answer post URL
 */
export declare class BaiduZhidaoRpaHandler extends RpaHandler {
    constructor();
    publish(page: Page, article: Article, credentials: PlatformCredentials): Promise<PublishResult>;
    /**
     * Ask a new question on Baidu Zhidao.
     * Uses article.title as the question text.
     */
    private askQuestion;
    /**
     * Answer an existing question on Baidu Zhidao.
     * Navigates to the question URL and posts the answer.
     */
    private answerQuestion;
    /**
     * Fill the answer editor on Baidu Zhidao.
     * Supports multiple editor types: rich text (ProseMirror/Quill), textarea, contenteditable.
     */
    private fillAnswerEditor;
    /**
     * Select a category if the category selection dialog appears.
     * Uses article.metadata.category if available, otherwise skips.
     */
    private selectCategory;
}
//# sourceMappingURL=baidu-zhidao.d.ts.map