import { Publisher } from '@zemingengine/publisher';
import type { PublishTask } from '@zemingengine/shared';
import type { DatabaseAccess } from '../db.js';
/**
 * Recover tasks that were interrupted by a server restart.
 *
 * 1. Tasks stuck in 'publishing' status for more than 5 minutes are marked as
 *    'failed' — the server restart interrupted their execution.
 * 2. Tasks in 'retrying' status are reset to 'pending' so the scheduler can
 *    reprocess them on the next poll.
 */
export declare function recoverStaleTasks(db: DatabaseAccess): void;
/** Filter tasks that are due for processing (pending/retrying with scheduledAt arrived). */
export declare function filterDueTasks(tasks: PublishTask[], now: number): PublishTask[];
interface DispatchGuard {
    accountKey: string;
    skipReason: 'concurrency' | 'in_progress' | 'cooldown' | null;
}
/** Check if a task can be dispatched or should be skipped. */
export declare function checkDispatchGuard(task: PublishTask, activeCount: number, publishingAccounts: Set<string>, accountCooldowns: Map<string, number>, now: number): DispatchGuard;
/**
 * Start the scheduled publish task dispatcher.
 *
 * Polls the database every POLL_INTERVAL_MS for due publish tasks and
 * dispatches them, respecting concurrency limits and per-account cooldowns.
 * Before the first poll, `recoverStaleTasks()` is called to clean up any
 * tasks that were interrupted by a previous server restart.
 *
 * Idempotent — calling startScheduler() while already running is a no-op.
 */
export declare function startScheduler(db: DatabaseAccess, publisher: Publisher): void;
/**
 * Stop the scheduled publish task dispatcher.
 * Idempotent — safe to call even if not running.
 */
export declare function stopScheduler(): void;
export {};
//# sourceMappingURL=publish-scheduler.d.ts.map