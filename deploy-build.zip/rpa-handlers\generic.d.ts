import type { Article, PlatformCredentials, PlatformId } from '@zemingengine/shared';
import type { Page } from 'playwright';
import type { PublishResult } from '../types.js';
import { RpaHandler } from './base.js';
/**
 * Generic RPA handler for platforms that don't have a dedicated handler yet.
 * Returns a clear error indicating the platform needs a dedicated implementation.
 */
export declare class GenericRpaHandler extends RpaHandler {
    constructor(platform: PlatformId);
    publish(_page: Page, _article: Article, _credentials: PlatformCredentials): Promise<PublishResult>;
}
//# sourceMappingURL=generic.d.ts.map