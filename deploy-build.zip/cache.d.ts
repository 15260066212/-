/**
 * LRU Cache with TTL support.
 *
 * Features:
 * - LRU eviction when maxEntries is exceeded
 * - TTL-based expiration (per-entry or default)
 * - Hit/miss/eviction statistics
 * - Pattern-based invalidation (prefix:* wildcard)
 * - wrap() for async function caching
 * - cleanup() for removing expired entries
 */
export interface CacheEntry<T> {
    value: T;
    expiresAt: number;
    lastAccessed: number;
    hits: number;
}
export interface CacheStats {
    entries: number;
    hits: number;
    misses: number;
    hitRate: number;
    evictions: number;
}
export interface LRUCacheOptions {
    maxEntries?: number;
    defaultTtlMs?: number;
}
export declare class LRUCache<T = unknown> {
    private cache;
    private readonly maxEntries;
    private readonly defaultTtlMs;
    private statsHits;
    private statsMisses;
    private statsEvictions;
    constructor(options?: LRUCacheOptions);
    /**
     * Get a value from the cache.
     * Returns undefined if the key doesn't exist or has expired.
     * Updates lastAccessed for LRU tracking.
     *
     * The optional type parameter K allows callers to specify the expected type,
     * which is useful when the cache stores mixed types (T = unknown).
     */
    get<K = T>(key: string): K | undefined;
    /**
     * Set a value in the cache.
     * @param ttlMs Time to live in ms. 0 = use defaultTtl, -1 = never expires.
     */
    set(key: string, value: T, ttlMs?: number): void;
    /** Delete a key from the cache. Returns true if the key existed. */
    delete(key: string): boolean;
    /** Check if a key exists and is not expired. */
    has(key: string): boolean;
    /** Clear all entries. */
    clear(): void;
    /** Current number of entries (including potentially expired ones). */
    size(): number;
    /** Get cache statistics. */
    stats(): CacheStats;
    /**
     * Remove all expired entries.
     * @returns number of entries removed
     */
    cleanup(): number;
    /**
     * Invalidate entries matching a pattern.
     * Supports prefix matching with `prefix:*` wildcard.
     * @returns number of entries invalidated
     */
    invalidatePattern(pattern: string): number;
    /**
     * Wrap an async function with caching.
     * If the key exists in cache, returns cached value.
     * Otherwise, executes fn, caches the result, and returns it.
     */
    wrap<K>(key: string, fn: () => Promise<K>, ttlMs?: number): Promise<K>;
    /** Evict the least recently used entry. */
    private evictLRU;
}
//# sourceMappingURL=cache.d.ts.map