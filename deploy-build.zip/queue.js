/**
 * In-memory publish queue for tracking active publishing tasks.
 * Works alongside the DB-backed publish_tasks table for persistence.
 */
export class PublishQueue {
    tasks = new Map();
    processing = new Set();
    enqueue(task) {
        this.tasks.set(task.id, task);
    }
    dequeue() {
        const pending = this.getPending();
        if (pending.length === 0)
            return undefined;
        const task = pending[0];
        this.processing.add(task.id);
        return task;
    }
    getPending() {
        return Array.from(this.tasks.values()).filter((t) => (t.status === 'pending' || t.status === 'retrying') && !this.processing.has(t.id));
    }
    getTask(taskId) {
        return this.tasks.get(taskId);
    }
    updateTask(taskId, updates) {
        const task = this.tasks.get(taskId);
        if (task) {
            this.tasks.set(taskId, { ...task, ...updates, updatedAt: new Date().toISOString() });
        }
    }
    remove(taskId) {
        this.tasks.delete(taskId);
        this.processing.delete(taskId);
    }
    /** Mark a task as being actively processed. */
    markProcessing(taskId) {
        this.processing.add(taskId);
    }
    /** Mark a task as done processing (success or failure). */
    markDone(taskId) {
        this.processing.delete(taskId);
    }
    get size() {
        return this.tasks.size;
    }
}
//# sourceMappingURL=queue.js.map