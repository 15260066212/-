import type { Article, ReviewIssue, SessionData } from '@zemingengine/shared';
export declare function checkSEO(article: Article, session: SessionData): ReviewIssue[];
//# sourceMappingURL=seo.d.ts.map