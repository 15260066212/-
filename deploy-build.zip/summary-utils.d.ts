/**
 * Shared summary generation for analysis results.
 * Both website analysis and PPT analysis produce structurally identical
 * profile summaries — this module centralizes the formatting logic.
 */
/** Fields needed to generate a profile summary. */
export interface SummaryFields {
    fullName?: string;
    shortName?: string;
    description?: string;
    scale?: string;
    location?: string;
    products: string[];
    trustAnchors: string[];
    brandTone: string[];
    keywords: ({
        question: string;
    } | string)[];
}
/**
 * Build the common profile summary lines (without header/footer).
 * Each line is conditionally added based on whether the field is present.
 */
export declare function buildProfileSummaryLines(fields: SummaryFields): string[];
//# sourceMappingURL=summary-utils.d.ts.map