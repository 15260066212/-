import type { Page } from 'playwright';
import { SimpleRpaHandler } from './base.js';
/**
 * Bilibili (哔哩哔哩) RPA handler - publishes articles via browser automation.
 * Requires cookie-based authentication (SESSDATA, bili_jct, DedeUserID, etc.)
 *
 * Publishing flow:
 * 1. Navigate to https://member.bilibili.com/article-text/home
 * 2. Fill in title
 * 3. Fill in content (Quill editor)
 * 4. Add tags if tag input available
 * 5. Select category if dropdown available (skip if not found)
 * 6. Click publish button
 * 7. Extract the published article URL
 */
export declare class BilibiliRpaHandler extends SimpleRpaHandler {
    protected readonly cookieDomain = ".bilibili.com";
    protected readonly titleSelectors: string[];
    protected readonly contentEditorSelectors: string[];
    protected readonly maxTags = 10;
    protected readonly publishButtonSelectors: string[];
    protected readonly hasConfirmDialog = false;
    protected readonly postIdPatterns: RegExp[];
    protected readonly platformDisplayName = "Bilibili";
    constructor();
    /**
     * Select category from the dropdown if available.
     * Category selection is optional — silently skipped if not found.
     */
    protected selectCategory(page: Page): Promise<void>;
}
//# sourceMappingURL=bilibili.d.ts.map