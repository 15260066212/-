import { PlatformAdapter } from './base.js';
export class SohuAdapter extends PlatformAdapter {
    constructor() {
        super('sohu');
    }
    getMethod() {
        return 'rpa';
    }
    async publish(_params) {
        return {
            success: true,
            postId: 'mock_rpa_post_id',
            postUrl: 'https://example.com',
        };
    }
}
//# sourceMappingURL=sohu.js.map