import type { DatabaseAccess } from '../db.js';
export declare function startPlanTaskScheduler(db: DatabaseAccess, executeTaskFn: (task: any) => Promise<void>): void;
export declare function stopPlanScheduler(): void;
//# sourceMappingURL=plan-scheduler.d.ts.map