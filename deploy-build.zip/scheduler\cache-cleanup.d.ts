import type { DatabaseAccess } from '../db.js';
/**
 * Start a periodic cache cleanup scheduler.
 *
 * Every 5 minutes, calls `cache.cleanup()` on the CachedDatabaseAccess
 * instance to remove expired entries from the LRU cache. This prevents
 * stale entries from consuming memory.
 *
 * Idempotent — calling startCacheCleanup() while already running is a no-op.
 */
export declare function startCacheCleanup(db: DatabaseAccess): void;
/**
 * Stop the cache cleanup scheduler.
 * Idempotent — safe to call even if not running.
 */
export declare function stopCacheCleanup(): void;
//# sourceMappingURL=cache-cleanup.d.ts.map