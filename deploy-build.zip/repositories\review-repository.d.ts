import type { DB } from '../db.js';
import type { ReviewResult } from '@zemingengine/shared';
export declare class ReviewRepository {
    private db;
    constructor(db: DB);
    insertReview(review: ReviewResult): string;
    getReviewsByArticle(articleId: string): ReviewResult[];
    getLatestReview(articleId: string): ReviewResult | undefined;
    private mapReview;
    /** Get dimension scores from recent reviews for health monitoring. */
    getReviewDimensionStats(limit?: number): Array<Record<string, number>>;
    /** Get review safety statistics (hash coverage, publish protection). */
    getReviewSafetyStats(): {
        totalReviews: number;
        reviewsWithHash: number;
        hashCoverage: number;
        publishedArticles: number;
        publishedWithReview: number;
    };
    /** Record a review audit event. */
    recordReviewAudit(reviewId: string, articleId: string, action: string, actor?: string, details?: string): void;
    /** Get audit trail for an article. */
    getReviewAuditTrail(articleId: string, limit?: number): Array<{
        id: number;
        reviewId: string;
        articleId: string;
        action: string;
        actor: string;
        details: string | null;
        createdAt: number;
    }>;
    /** Check if an article has a passing review (rollback protection). */
    hasPassingReview(articleId: string): boolean;
    /** Get latest review status for an article (for publish guard). */
    getLatestReviewStatus(articleId: string): {
        passed: boolean;
        overallScore: number;
        round: number;
    } | null;
}
//# sourceMappingURL=review-repository.d.ts.map