import { type Article, type PlatformCredentials } from '@zemingengine/shared';
import type { Page } from 'playwright';
import type { PublishResult } from '../types.js';
import { RpaHandler } from './base.js';
/**
 * Zhihu RPA handler - publishes articles via browser automation.
 * Requires cookie-based authentication (z_c0, q_c1, or unlock_ticket cookie)
 *
 * Publishing flow:
 * 1. Navigate to https://zhuanlan.zhihu.com/write
 * 2. Fill in title
 * 3. Fill in content (rich text editor)
 * 4. Click publish button
 * 5. Extract the published article URL
 */
export declare class ZhihuRpaHandler extends RpaHandler {
    constructor();
    publish(page: Page, article: Article, credentials: PlatformCredentials): Promise<PublishResult>;
    private addTopics;
}
//# sourceMappingURL=zhihu.d.ts.map