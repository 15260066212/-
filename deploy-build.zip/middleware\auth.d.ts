import type { MiddlewareHandler } from 'hono';
import type { AppEnv, DatabaseAccess } from '../db.js';
/**
 * Create an authentication middleware that resolves the current user from
 * the `x-api-key` header or `Authorization: Bearer <key>` header.
 *
 * - If a valid API key is provided, the corresponding user is attached to
 *   the Hono context via `c.set('user', user)`.
 * - If AUTH_REQUIRE_API_KEY is not set to 'true' (dev mode) and no API key
 *   is provided, the default admin user (`user_default`) is used for
 *   backward compatibility.
 * - If AUTH_REQUIRE_API_KEY is 'true' and no API key is provided, 401 is returned.
 * - If an invalid API key is provided, a 401 response is returned.
 */
export declare function createAuthMiddleware(db: DatabaseAccess): MiddlewareHandler<AppEnv>;
//# sourceMappingURL=auth.d.ts.map