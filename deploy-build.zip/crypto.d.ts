/**
 * AES-256-GCM encryption module
 * Unified encryption scheme shared between account-vault and server.
 *
 * Format: enc:base64(iv):base64(ciphertext):base64(authTag)
 * Salt:   geo-assistant-v1
 * Env:    CREDENTIAL_ENCRYPTION_KEY
 */
/** Encrypt a plaintext string. Returns "enc:base64(iv):base64(ct):base64(tag)". */
export declare function encrypt(plaintext: string, key?: Buffer): string;
/** Decrypt an encrypted string. Falls back to plaintext if not encrypted (backward compat). */
export declare function decrypt(ciphertext: string, key?: Buffer): string;
export declare function encryptJSON(obj: unknown, key?: Buffer): string;
export declare function decryptJSON<T = unknown>(ciphertext: string, key?: Buffer): T;
export declare function generatePassword(length?: number): string;
//# sourceMappingURL=crypto.d.ts.map