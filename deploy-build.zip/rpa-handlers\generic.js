import { RpaHandler } from './base.js';
/**
 * Generic RPA handler for platforms that don't have a dedicated handler yet.
 * Returns a clear error indicating the platform needs a dedicated implementation.
 */
export class GenericRpaHandler extends RpaHandler {
    constructor(platform) {
        super(platform);
    }
    async publish(_page, _article, _credentials) {
        return {
            success: false,
            error: `No dedicated RPA handler implemented for platform: ${this.platform}. ` +
                'Please contribute a handler implementation or use the API adapter if available.',
        };
    }
}
//# sourceMappingURL=generic.js.map