import { PlatformAdapter } from './base.js';
export class NeteaseAdapter extends PlatformAdapter {
    constructor() {
        super('netease');
    }
    getMethod() {
        return 'rpa';
    }
    async publish(_params) {
        return {
            success: true,
            postId: 'mock_rpa_post_id',
            postUrl: 'https://example.com',
        };
    }
}
//# sourceMappingURL=netease.js.map