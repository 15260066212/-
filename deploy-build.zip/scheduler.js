import { classifyFailure } from '@zemingengine/publisher';
const POLL_INTERVAL_MS = 30_000; // 30 seconds
const STALE_THRESHOLD_MS = 5 * 60 * 1000; // 5 minutes
const MAX_CONCURRENT = 5;
const MIN_COOLDOWN_MS = 30_000; // 30s minimum cooldown (healthy platform)
const DEFAULT_COOLDOWN_MS = 60_000; // 60s default cooldown
const RATE_LIMIT_COOLDOWN_MS = 3 * 60_000; // 3 min cooldown after rate limit
const CAPTCHA_COOLDOWN_MS = 5 * 60_000; // 5 min cooldown after captcha
/**
 * Calculate dynamic cooldown for a platform based on recent performance.
 *
 * - High success rate (>80%) → 30s cooldown (fast lane)
 * - Medium success rate (50-80%) → 60s cooldown (normal)
 * - Low success rate (<50%) → 120s cooldown (cautious)
 * - Rate limit failure → 180s cooldown
 * - Captcha detected → 300s cooldown
 */
function calculateDynamicCooldown(db, platform, _lastFailureType, captchaPending) {
    // Captcha takes priority — longest cooldown
    if (captchaPending) {
        console.log(`[Scheduler] ${platform}: captcha cooldown (${CAPTCHA_COOLDOWN_MS}ms)`);
        return CAPTCHA_COOLDOWN_MS;
    }
    // Check recent platform health for failure type
    const health = db.publish.getPlatformPublishHealth(platform, 10);
    // Rate limit error — extended cooldown
    if (health.lastError && health.lastError.toLowerCase().includes('rate')) {
        console.log(`[Scheduler] ${platform}: rate-limit cooldown (${RATE_LIMIT_COOLDOWN_MS}ms)`);
        return RATE_LIMIT_COOLDOWN_MS;
    }
    if (health.total < 3) {
        return DEFAULT_COOLDOWN_MS; // Not enough data, use default
    }
    if (health.successRate >= 80) {
        return MIN_COOLDOWN_MS; // Healthy platform — fast cooldown
    }
    else if (health.successRate >= 50) {
        return DEFAULT_COOLDOWN_MS; // Normal
    }
    else {
        return 2 * DEFAULT_COOLDOWN_MS; // 120s — cautious approach
    }
}
/**
 * Recover tasks that were interrupted by a server restart.
 *
 * 1. Tasks stuck in 'publishing' status for more than 5 minutes are marked as
 *    'failed' — the server restart interrupted their execution.
 * 2. Tasks in 'retrying' status are reset to 'pending' so the scheduler can
 *    reprocess them on the next poll.
 */
export function recoverStaleTasks(db) {
    // 1. Mark stale 'publishing' tasks as 'failed'
    const stalePublishing = db.publish.getStalePublishingTasks(STALE_THRESHOLD_MS);
    for (const task of stalePublishing) {
        db.publish.updatePublishTask(task.id, {
            status: 'failed',
            errorMessage: 'Task interrupted by server restart',
            failureType: 'unknown',
        });
        console.warn(`[Scheduler] Recovered stale publishing task ${task.id} ` +
            `(last updated: ${task.updatedAt})`);
    }
    if (stalePublishing.length > 0) {
        console.log(`[Scheduler] Recovered ${stalePublishing.length} stale publishing task(s)`);
    }
    // 2. Reset 'retrying' tasks to 'pending' so the scheduler reprocesses them
    const pendingTasks = db.publish.getPendingPublishTasks();
    const retryingTasks = pendingTasks.filter((t) => t.status === 'retrying');
    for (const task of retryingTasks) {
        db.publish.updatePublishTask(task.id, { status: 'pending' });
        console.log(`[Scheduler] Reset retrying task ${task.id} to pending`);
    }
    if (retryingTasks.length > 0) {
        console.log(`[Scheduler] Reset ${retryingTasks.length} retrying task(s) to pending`);
    }
}
const HEALTH_CHECK_INTERVAL_MS = 10 * 60 * 1000; // 每 10 分钟检查一批
let healthCheckTimer = null;
export function startHealthChecker(checker) {
    if (healthCheckTimer) {
        console.warn('[HealthChecker] Already running');
        return;
    }
    console.log('[HealthChecker] Starting (batch check every 10 min)');
    // Run first check after a short delay (let server fully start)
    setTimeout(() => {
        checker.runCheckBatch().catch((err) => {
            console.error('[HealthChecker] First batch failed:', err.message);
        });
    }, 5000);
    healthCheckTimer = setInterval(() => {
        checker.runCheckBatch().catch((err) => {
            console.error('[HealthChecker] Batch check failed:', err.message);
        });
    }, HEALTH_CHECK_INTERVAL_MS);
}
// === Cookie Warmer ===
// Periodically visits platform pages with saved cookies to trigger Set-Cookie refresh,
// extending cookie lifetime without requiring re-login. Runs every 2 hours.
const COOKIE_WARMER_INTERVAL_MS = parseFloat(process.env.COOKIE_WARMER_INTERVAL_HOURS || '0.5') * 60 * 60 * 1000;
const COOKIE_WARMER_BATCH_SIZE = parseInt(process.env.COOKIE_WARMER_BATCH_SIZE || '5', 10);
let cookieWarmerTimer = null;
let cookieWarmerLastRunAt = null;
let cookieWarmerLastResult = null;
let cookieWarmerRunning = false;
/**
 * Run one batch of cookie warming: visit platform pages with saved cookies,
 * let the platform issue fresh Set-Cookie headers, and persist the refreshed cookies.
 */
async function runCookieWarmBatch(db) {
    const harvesterUrl = process.env.RPA_REMOTE_URL;
    if (!harvesterUrl) {
        console.warn('[CookieWarmer] RPA_REMOTE_URL not set, skipping');
        return;
    }
    cookieWarmerRunning = true;
    cookieWarmerLastRunAt = new Date();
    let warmed = 0;
    let skipped = 0;
    let failed = 0;
    const due = selectCredentialsForWarming(db);
    if (due.length === 0) {
        console.log('[CookieWarmer] No credentials due for warming');
        cookieWarmerLastResult = { warmed: 0, skipped: 0, failed: 0 };
        cookieWarmerRunning = false;
        return;
    }
    console.log(`[CookieWarmer] Warming ${due.length} credentials...`);
    for (const cred of due) {
        const result = await warmSingleCredential(db, harvesterUrl, cred);
        if (result === 'warmed')
            warmed++;
        else if (result === 'skipped')
            skipped++;
        else
            failed++;
        await new Promise((resolve) => setTimeout(resolve, 2000));
    }
    cookieWarmerLastResult = { warmed, skipped, failed };
    cookieWarmerRunning = false;
    console.log(`[CookieWarmer] Batch complete (warmed: ${warmed}, skipped: ${skipped}, failed: ${failed})`);
}
/** Select credentials due for warming: active + expired, not validated in last 2h. */
function selectCredentialsForWarming(db) {
    const allCreds = db.credentials.getAllCredentials();
    const warmThreshold = Date.now() - 2 * 60 * 60 * 1000;
    return allCreds
        .filter((c) => {
        if (c.status === 'invalid')
            return false;
        const lastValidated = c.lastValidatedAt ? new Date(c.lastValidatedAt).getTime() : 0;
        return lastValidated < warmThreshold;
    })
        .slice(0, COOKIE_WARMER_BATCH_SIZE);
}
const PLATFORM_HARVESTER_MAP = {
    weixin: 'wechat',
    baijia: 'baijiahao',
    toutiao: 'toutiaohao',
    sohu: 'sohuhao',
    netease: 'wangyihao',
};
/** Warm a single credential by calling the harvester's refresh endpoint. */
async function warmSingleCredential(db, harvesterUrl, cred) {
    const cookie = cred.data.cookie || cred.data.cookies || '';
    if (!cookie || cookie === 'placeholder_pending_login') {
        console.log(`[CookieWarmer] Skipping ${cred.platform}:${cred.accountId} - no real cookie`);
        return 'skipped';
    }
    const harvesterPlatform = PLATFORM_HARVESTER_MAP[cred.platform] || cred.platform;
    try {
        const refreshUrl = `${harvesterUrl.replace(/\/+$/, '')}/api/rpa/refresh-cookies`;
        const res = await fetch(refreshUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ platform: harvesterPlatform, cookies: cookie }),
            signal: AbortSignal.timeout(30000),
        });
        if (!res.ok) {
            console.warn(`[CookieWarmer] ${cred.platform}:${cred.accountId} - HTTP ${res.status}`);
            return 'failed';
        }
        const data = (await res.json());
        if (data.success && data.valid && data.refreshedCookies) {
            db.credentials.updateCredentialData(cred.platform, { cookie: data.refreshedCookies }, 'user_default', cred.accountId);
            db.credentials.updateCredentialStatus(cred.platform, 'active', 'user_default', cred.accountId);
            console.log(`[CookieWarmer] Refreshed ${cred.platform}:${cred.accountId} - OK`);
            return 'warmed';
        }
        console.log(`[CookieWarmer] ${cred.platform}:${cred.accountId} - ${data.reason || 'not valid'}`);
        if (data.success && !data.valid) {
            db.credentials.updateCredentialStatus(cred.platform, 'expired', 'user_default', cred.accountId);
        }
        return 'failed';
    }
    catch (err) {
        console.warn(`[CookieWarmer] Error warming ${cred.platform}:${cred.accountId}:`, err instanceof Error ? err.message : err);
        return 'failed';
    }
}
export function startCookieWarmer(db) {
    if (cookieWarmerTimer) {
        console.warn('[CookieWarmer] Already running');
        return;
    }
    const intervalHours = process.env.COOKIE_WARMER_INTERVAL_HOURS || '2';
    console.log(`[CookieWarmer] Starting (every ${intervalHours}h, batch size ${COOKIE_WARMER_BATCH_SIZE})`);
    // First run after a delay (stagger with health checker)
    setTimeout(() => {
        runCookieWarmBatch(db).catch((err) => {
            console.error('[CookieWarmer] First batch failed:', err instanceof Error ? err.message : err);
        });
    }, 30000); // 30s delay
    cookieWarmerTimer = setInterval(() => {
        runCookieWarmBatch(db).catch((err) => {
            console.error('[CookieWarmer] Batch failed:', err instanceof Error ? err.message : err);
        });
    }, COOKIE_WARMER_INTERVAL_MS);
}
export function stopCookieWarmer() {
    if (cookieWarmerTimer) {
        clearInterval(cookieWarmerTimer);
        cookieWarmerTimer = null;
        console.log('[CookieWarmer] Stopped');
    }
}
export function stopHealthChecker() {
    if (healthCheckTimer) {
        clearInterval(healthCheckTimer);
        healthCheckTimer = null;
        console.log('[HealthChecker] Stopped');
    }
}
/**
 * Start the scheduled-publish scheduler.
 *
 * Polls the database every 30 seconds for publish tasks that are in the
 * `pending` or `retrying` state and have a `scheduledAt` time which has
 * arrived. When a task is due it is atomically transitioned to `publishing`
 * (to prevent duplicate execution) and then published asynchronously.
 *
 * Concurrency control:
 * - Global: at most MAX_CONCURRENT tasks executing simultaneously.
 * - Per-platform: at most 1 task per platform at a time, with a 60-second
 *   cooldown between publishes to the same platform (rate-limit protection).
 *
 * Before the first poll, `recoverStaleTasks()` is called to clean up any
 * tasks that were interrupted by a previous server restart.
 *
 * @returns a NodeJS.Timeout handle that can be passed to `clearInterval()`
 *          to stop the scheduler.
 */
export function startScheduler(db, publisher) {
    console.log('[Scheduler] Scheduled-publish scheduler started (polling every 30s)');
    // Concurrency tracking (account-level: key is "platform:accountId")
    const publishingAccounts = new Set();
    let activeCount = 0;
    const accountCooldowns = new Map();
    // Recover stale tasks before starting the poll loop
    recoverStaleTasks(db);
    const tick = async () => {
        try {
            const tasks = db.publish.getPendingPublishTasks();
            const now = Date.now();
            // Process both 'pending' and 'retrying' tasks whose scheduledAt has arrived
            const dueTasks = tasks.filter((t) => ['pending', 'retrying'].includes(t.status) &&
                t.scheduledAt &&
                new Date(t.scheduledAt).getTime() <= now);
            console.log(`[Scheduler] Poll: ${tasks.length} pending/retrying task(s) in queue, ` +
                `${dueTasks.length} due for processing, ${activeCount}/${MAX_CONCURRENT} active`);
            if (dueTasks.length === 0)
                return;
            let dispatched = 0;
            let skipped = 0;
            for (const task of dueTasks) {
                // Stop if global concurrency limit reached
                if (activeCount >= MAX_CONCURRENT) {
                    console.log(`[Scheduler] Global concurrency limit reached (${MAX_CONCURRENT}), ` +
                        `${dueTasks.length - dispatched} task(s) deferred to next poll`);
                    break;
                }
                const accountId = task.accountId ?? 'default';
                const accountKey = `${task.platform}:${accountId}`;
                // Skip if this specific account is currently publishing
                if (publishingAccounts.has(accountKey)) {
                    console.log(`[Scheduler] Skipping task ${task.id}: ${task.platform} (${accountId}) already in progress`);
                    skipped++;
                    continue;
                }
                // Skip if this account is in cooldown period
                const cooldownEnd = accountCooldowns.get(accountKey);
                if (cooldownEnd && cooldownEnd > now) {
                    console.log(`[Scheduler] Skipping task ${task.id}: ${task.platform} (${accountId}) in cooldown ` +
                        `until ${new Date(cooldownEnd).toISOString()}`);
                    skipped++;
                    continue;
                }
                // Prevent duplicate execution: mark as publishing before executing
                db.publish.updatePublishTask(task.id, { status: 'publishing' });
                publishingAccounts.add(accountKey);
                activeCount++;
                dispatched++;
                console.log(`[Scheduler] Triggering publish for task ${task.id} ` +
                    `(platform: ${task.platform}, account: ${accountId}, scheduledAt: ${task.scheduledAt})`);
                // Fire-and-forget with cleanup on completion
                void executeScheduledPublish(db, publisher, { ...task, status: 'publishing' })
                    .finally(() => {
                    publishingAccounts.delete(accountKey);
                    activeCount--;
                    // Dynamic cooldown based on recent performance and failure type
                    const captchaPending = db.selectors.getPendingCaptchaEvents(1).some((e) => e.platform === task.platform);
                    const cooldownMs = calculateDynamicCooldown(db, task.platform, undefined, captchaPending);
                    accountCooldowns.set(accountKey, Date.now() + cooldownMs);
                });
            }
            console.log(`[Scheduler] Poll complete: dispatched ${dispatched}, skipped ${skipped}, ` +
                `active ${activeCount}/${MAX_CONCURRENT}`);
        }
        catch (err) {
            console.error('[Scheduler] Error during scheduled publish poll:', err instanceof Error ? err.message : err);
        }
    };
    // Run an initial tick immediately, then on the interval
    void tick();
    return setInterval(() => void tick(), POLL_INTERVAL_MS);
}
/**
 * Execute a single scheduled publish task.
 *
 * Mirrors the `publishArticleAsync` logic in routes/publish.ts: fetches the
 * article and credentials from the database, calls
 * `publisher.publishWithRetry()`, and updates the task + article status
 * based on the result.
 */
async function executeScheduledPublish(db, publisher, task) {
    const article = db.articles.getArticle(task.articleId);
    if (!article) {
        console.error(`[Scheduler] Article ${task.articleId} not found for task ${task.id}`);
        db.publish.updatePublishTask(task.id, {
            status: 'failed',
            errorMessage: `Article not found: ${task.articleId}`,
            failureType: 'platform',
        });
        return;
    }
    // Rollback protection: skip publishing if article hasn't passed review
    if (!db.reviews.hasPassingReview(task.articleId)) {
        const latestReview = db.reviews.getLatestReviewStatus(task.articleId);
        const reviewStatus = latestReview
            ? `审核未通过（评分: ${latestReview.overallScore}, 第${latestReview.round}轮）`
            : '文章尚未审核';
        console.warn(`[Scheduler] Task ${task.id} blocked: ${reviewStatus}`);
        db.publish.updatePublishTask(task.id, {
            status: 'failed',
            errorMessage: `发布被阻止：${reviewStatus}`,
            failureType: 'platform',
        });
        return;
    }
    const credentials = resolveScheduledCredentials(db, task, article);
    if (!credentials)
        return; // already marked as failed
    try {
        const result = await publisher.publishWithRetry(task, article, credentials, (updates) => db.publish.updatePublishTask(task.id, updates));
        if (result.success) {
            db.publish.updatePublishTask(task.id, {
                status: 'published',
                platformPostId: result.postId,
                platformPostUrl: result.postUrl,
                publishedAt: new Date().toISOString(),
            });
            db.articles.updateArticle(article.id, { status: 'published' });
            console.log(`[Scheduler] Task ${task.id} published successfully`);
        }
        else {
            const error = result.error ?? 'Unknown publish error';
            const analysis = classifyFailure(error);
            db.publish.updatePublishTask(task.id, {
                status: 'failed',
                errorMessage: error,
                failureType: analysis.type,
            });
            db.articles.updateArticle(article.id, { status: 'failed' });
            console.warn(`[Scheduler] Task ${task.id} publish failed: ${error} (${analysis.category})`);
        }
    }
    catch (err) {
        const error = err instanceof Error ? err.message : 'Unknown error';
        const analysis = classifyFailure(error);
        db.publish.updatePublishTask(task.id, {
            status: 'failed',
            errorMessage: error,
            failureType: analysis.type,
        });
        db.articles.updateArticle(article.id, { status: 'failed' });
        console.error(`[Scheduler] Task ${task.id} publish threw error:`, error);
    }
}
/**
 * Resolve credentials for a scheduled task, with dynamic account pool fallback.
 * Returns the credential to use, or null if the task has been marked as failed.
 */
function resolveScheduledCredentials(db, task, article) {
    const taskUserId = task.userId ?? 'user_default';
    const taskAccountId = task.accountId ?? 'default';
    let credentials = db.credentials.getCredential(task.platform, taskUserId, taskAccountId);
    if (!credentials || credentials.status === 'expired' || credentials.status === 'invalid') {
        const originalStatus = credentials?.status ?? 'not_found';
        console.log(`[Scheduler] Primary credential for ${task.platform} (${taskAccountId}) is ${originalStatus}, ` +
            `searching for alternative active credentials...`);
        const alternatives = db.credentials.getActiveCredentialsForPlatform(task.platform, taskUserId);
        const usable = alternatives.filter((c) => c.accountId !== taskAccountId);
        if (usable.length > 0) {
            credentials = usable[0];
            console.log(`[Scheduler] Using alternative active credential for ${task.platform} ` +
                `(account: ${credentials.accountId}, switched from ${originalStatus})`);
        }
        else {
            return failTaskOnCredentialError(db, task, article, credentials);
        }
    }
    return credentials;
}
/** Mark a task as failed due to credential issues. Returns null (no credential). */
function failTaskOnCredentialError(db, task, article, credentials) {
    let errorMessage;
    let failureType = 'auth';
    if (!credentials) {
        errorMessage = `Credentials not found for platform: ${task.platform}`;
    }
    else if (credentials.status === 'expired') {
        errorMessage = '账号登录态已过期，且无可用替代账号';
        console.warn(`[Scheduler] Task ${task.id}: credential expired, no alternatives available`);
    }
    else if (credentials.status === 'invalid') {
        errorMessage = '账号凭证无效，且无可用替代账号';
    }
    else {
        errorMessage = 'Unknown credential error';
    }
    db.publish.updatePublishTask(task.id, { status: 'failed', errorMessage, failureType });
    db.articles.updateArticle(article.id, { status: 'failed' });
    return null;
}
const CACHE_CLEANUP_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes
/**
 * Start a periodic cache cleanup timer.
 *
 * Every 5 minutes, calls `cache.cleanup()` on the CachedDatabaseAccess
 * instance to remove expired entries from the LRU cache. This prevents
 * stale entries from consuming memory.
 *
 * @returns a NodeJS.Timeout handle that can be passed to `clearInterval()`.
 */
export function startCacheCleanup(db) {
    // Only run cleanup if the db instance supports caching
    const cachedDb = db;
    if (typeof cachedDb.getCache !== 'function') {
        console.log('[Scheduler] Cache cleanup skipped (db does not support caching)');
        return setInterval(() => { }, 24 * 60 * 60 * 1000); // no-op interval
    }
    console.log('[Scheduler] Cache cleanup started (every 5 minutes)');
    const cleanup = () => {
        try {
            const removed = cachedDb.getCache().cleanup();
            if (removed > 0) {
                const stats = cachedDb.getCache().stats();
                console.log(`[Scheduler] Cache cleanup: ${removed} entries removed, ` +
                    `${stats.entries} remaining (hit rate: ${stats.hitRate.toFixed(1)}%)`);
            }
        }
        catch (err) {
            console.error('[Scheduler] Cache cleanup error:', err instanceof Error ? err.message : err);
        }
    };
    // Run cleanup after the first interval (not immediately)
    return setInterval(cleanup, CACHE_CLEANUP_INTERVAL_MS);
}
// === Plan Task Scheduler ===
// Checks daily for due scheduled plan tasks and executes them via pipeline
const PLAN_CHECK_INTERVAL_MS = 60 * 60 * 1000; // Check every hour
let planSchedulerTimer = null;
export function startPlanTaskScheduler(db, executeTaskFn) {
    if (planSchedulerTimer) {
        console.warn('[PlanScheduler] Already running');
        return;
    }
    console.log('[PlanScheduler] Starting (check every 1 hour)');
    const tick = async () => {
        try {
            const dueTasks = db.plans.getDueScheduledTasks();
            if (dueTasks.length === 0)
                return;
            console.log(`[PlanScheduler] Found ${dueTasks.length} due plan task(s)`);
            for (const task of dueTasks) {
                try {
                    db.plans.updateScheduledTaskStatus(task.id, 'running', { executedAt: new Date().toISOString() });
                    await executeTaskFn(task);
                }
                catch (err) {
                    const msg = err instanceof Error ? err.message : 'Unknown error';
                    console.error(`[PlanScheduler] Task ${task.id} failed:`, msg);
                    db.plans.updateScheduledTaskStatus(task.id, 'failed', { errorMessage: msg });
                }
            }
        }
        catch (err) {
            console.error('[PlanScheduler] Tick failed:', err instanceof Error ? err.message : err);
        }
    };
    // Run first check after 30 seconds
    setTimeout(() => { tick().catch(() => { }); }, 30000);
    planSchedulerTimer = setInterval(() => { tick().catch(() => { }); }, PLAN_CHECK_INTERVAL_MS);
}
export function stopPlanScheduler() {
    if (planSchedulerTimer) {
        clearInterval(planSchedulerTimer);
        planSchedulerTimer = null;
        console.log('[PlanScheduler] Stopped');
    }
}
//# sourceMappingURL=scheduler.js.map