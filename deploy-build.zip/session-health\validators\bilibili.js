import { HarvesterBrowserValidator } from './harvester-browser.js';
export class BilibiliValidator extends HarvesterBrowserValidator {
    platform = 'bilibili';
}
//# sourceMappingURL=bilibili.js.map