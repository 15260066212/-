export interface RefreshResponse {
    success: boolean;
    valid: boolean;
    refreshedCookies?: string;
    refreshedStorageState?: string;
    refreshedFingerprintData?: string;
    reason?: string;
}
export interface ProfileInfo {
    platform: string;
    accountName: string;
    sizeBytes: number;
    sizeMB: number;
}
export interface ProfileHealthResponse {
    success: boolean;
    platform: string;
    account: string;
    loggedIn: boolean;
    url?: string;
    authCookies?: boolean;
    sizeBytes?: number;
    sizeMB?: number;
    error?: string;
}
export interface ProfileRenewResponse {
    success: boolean;
    platform: string;
    account: string;
    loggedIn: boolean;
    error?: string;
}
export interface RenewAllResponse {
    total: number;
    renewed: number;
    stillLoggedIn: number;
    failed: number;
    results: Array<{
        platform: string;
        accountName: string;
        success: boolean;
        loggedIn: boolean;
        error?: string;
    }>;
}
export interface LLMwikiPublishResponse {
    success: boolean;
    publishMode: 'profile' | 'cookie' | 'fresh';
    verificationStatus?: string;
    verificationMessage?: string;
    error?: string;
    [key: string]: unknown;
}
/**
 * Encapsulates HTTP communication with the RPA harvester service.
 * Provides shared methods for building request bodies, calling endpoints,
 * and extracting credential updates from refresh responses.
 */
export declare class HarvesterClient {
    private readonly baseUrl;
    constructor(harvesterUrl: string);
    /**
     * Build a refresh-cookies request body from credential data.
     * Returns null if no real auth data (cookie or storageState) is present.
     */
    buildRefreshBody(data: Record<string, string>, platform: string): Record<string, string> | null;
    /** Call /api/rpa/refresh-cookies. Returns null on HTTP error or fetch failure. */
    refreshCookies(body: Record<string, string>, timeoutMs?: number): Promise<RefreshResponse | null>;
    /** Extract credential update fields from a successful refresh response. */
    static extractUpdateData(data: RefreshResponse): Record<string, string>;
    /** List all account profiles on the harvester. */
    listProfiles(timeoutMs?: number): Promise<ProfileInfo[] | null>;
    /** Check login health of a specific profile. */
    checkProfileHealth(platform: string, accountName: string, timeoutMs?: number): Promise<ProfileHealthResponse | null>;
    /** Delete an account profile. */
    deleteProfile(platform: string, accountName: string, timeoutMs?: number): Promise<boolean>;
    /** Renew a single profile's login state. */
    renewProfile(platform: string, accountName: string, timeoutMs?: number): Promise<ProfileRenewResponse | null>;
    /** Renew all profiles at once. */
    renewAllProfiles(timeoutMs?: number): Promise<RenewAllResponse | null>;
    /**
     * Publish an article via LLMwiki endpoint (profile-first mode).
     * @param platform Harvester platform name (e.g. 'toutiaohao')
     * @param article Article content
     * @param options Account name + optional cookie/storageState fallback
     */
    publishLLMwiki(platform: string, article: {
        title: string;
        contentMarkdown?: string;
        contentHtml?: string;
    }, options: {
        accountName: string;
        cookieString?: string;
        storageState?: string;
    }, timeoutMs?: number): Promise<LLMwikiPublishResponse | null>;
}
//# sourceMappingURL=harvester-client.d.ts.map