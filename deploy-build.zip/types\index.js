/**
 * Shared type definitions — organized by domain.
 *
 * Sub-path import: `import { PlatformId, Article } from '@zemingengine/shared/types'`
 */
// Session types (includes STAGES, LEGACY_STAGES, createEmptySession)
export { STAGES, LEGACY_STAGES, createEmptySession, } from './session.types.js';
// Article & review types
export { DEFAULT_REVIEW_WEIGHTS } from './article.types.js';
//# sourceMappingURL=index.js.map