﻿import 'dotenv/config';
import { serve } from '@hono/node-server';
import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { logger } from 'hono/logger';
import { isAIAvailable } from '@zemingengine/ai-engine';
import { Publisher, RPAEngine } from '@zemingengine/publisher';
import { createSessionRoutes } from './routes/session.js';
import { createMessageRoutes } from './routes/message.js';
import { createScrapeRoutes } from './routes/scrape.js';
import { createManualRoutes } from './routes/manual.js';
import { createArticleRoutes } from './routes/article.js';
import { createReviewRoutes } from './routes/review.js';
import { createPublishRoutes } from './routes/publish.js';
import { createPipelineRoutes } from './routes/pipeline.js';
import { createCredentialRoutes } from './routes/credentials.js';
import { createCookieHarvesterRoutes } from './routes/cookie-harvester.js';
import { createMonitorRoutes } from './routes/monitor.js';
import { createUserRoutes } from './routes/user.js';
import { createQuotaRoutes } from './quota-routes.js';
import { runMigration, setDefaultQuotas } from './quota-manager.js';
import { createAuthMiddleware } from './middleware/auth.js';
import { CachedDatabaseAccess } from './cached-db.js';
import { startScheduler, startCacheCleanup, stopHealthChecker, startHealthChecker, startCookieWarmer, stopCookieWarmer } from './scheduler.js';
import { SessionPoolAdapter } from './session-pool-adapter.js';
import { SessionHealthChecker, ReloginManager, SelectorMonitor, CaptchaManager } from './session-health/index.js';
// Database instance (with cache layer)
const db = CachedDatabaseAccess.create();
const app = new Hono();
// Middleware
app.use('*', logger());
app.use('*', cors());
// Auth middleware — resolves user from API key header (falls back to default admin)
app.use('*', createAuthMiddleware(db));
// SessionPool adapter for browser session persistence with fingerprint isolation
const sessionPool = new SessionPoolAdapter(db);
// Publisher instance with SessionPool-enabled RPAEngine (shared across routes and scheduler)
const rpaEngine = new RPAEngine(sessionPool);
const publisher = Publisher.createDefault(rpaEngine);
// Relogin manager for auto-relogin when session expires
const reloginManager = new ReloginManager(db);
// Selector monitor for detecting platform page structure changes
const selectorMonitor = new SelectorMonitor(db);
// Captcha manager for detecting and tracking captcha challenges
const captchaManager = new CaptchaManager(db);
// Wire up log callback to persist publish logs to DB
publisher.logCallback = (entry) => {
    const log = {
        id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        taskId: entry.taskId,
        level: entry.level,
        message: entry.message,
        metadata: entry.metadata,
        createdAt: new Date().toISOString(),
    };
    try {
        db.insertPublishLog(log);
    }
    catch {
        // Logging should never break the publish flow
    }
};
// Health check (includes cache stats)
app.get('/api/health', (c) => {
    const dbHealth = db.healthCheck();
    const cacheStats = db.getCache().stats();
    return c.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        aiEnabled: isAIAvailable(),
        database: {
            healthy: dbHealth.healthy,
            tables: dbHealth.details.tables,
            tableExists: dbHealth.details.tableExists,
            walSize: dbHealth.details.walSize,
        },
        cache: {
            entries: cacheStats.entries,
            hits: cacheStats.hits,
            misses: cacheStats.misses,
            hitRate: cacheStats.hitRate,
            evictions: cacheStats.evictions,
        },
    });
});
// Cache management endpoints
app.get('/api/cache/stats', (c) => {
    const stats = db.getCache().stats();
    return c.json({ success: true, data: stats });
});
app.delete('/api/cache', (c) => {
    db.getCache().clear();
    console.log('[Server] Cache cleared by request');
    return c.json({ success: true, message: 'Cache cleared' });
});
// Mount routes
app.route('/api/monitor', createMonitorRoutes(db, reloginManager, selectorMonitor, captchaManager));
app.route('/api/users', createUserRoutes(db));
app.route('/api/session', createSessionRoutes(db));
app.route('/api/session', createMessageRoutes(db));
app.route('/api/session', createScrapeRoutes(db));
app.route('/api/session', createManualRoutes(db));
app.route('/api/articles', createArticleRoutes(db));
app.route('/api/reviews', createReviewRoutes(db));
app.route('/api/publish', createPublishRoutes(db, publisher));
app.route('/api/pipeline', createPipelineRoutes(db));
app.route('/api/credentials', createCredentialRoutes(db));
app.route('/api/cookie-harvester', createCookieHarvesterRoutes(db));
app.route('/api/publish-quotas', createQuotaRoutes(db));
// Start server
const port = Number(process.env.PORT ?? 3000);
// Scheduler handle for graceful shutdown
let schedulerHandle;
let cacheCleanupHandle;
const server = serve({ fetch: app.fetch, port }, (info) => {
    console.log(`泽铭引擎 server running at http://localhost:${info.port}`);
    console.log(`AI Engine: ${isAIAvailable() ? 'Enabled' : 'Disabled (set OPENAI_API_KEY to enable)'}`);
    // Initialize publish quota system (migration + default quotas)
    try {
        runMigration(db.db);
        setDefaultQuotas(db.db);
        console.log('[Server] Publish quota system initialized');
    } catch (e) {
        console.error('[Server] Quota init failed:', e.message);
    }
    // Start the scheduled-publish scheduler
    schedulerHandle = startScheduler(db, publisher);
    // Session health checker with auto-relogin support
    const healthChecker = new SessionHealthChecker(db, reloginManager);
    startHealthChecker(healthChecker);
    // Selector health monitor — checks platform page structure every 6 hours
    selectorMonitor.start();
    // Start periodic cache cleanup (every 5 minutes)
    cacheCleanupHandle = startCacheCleanup(db);
    // Start cookie warmer — refreshes cookies every 2 hours to extend session lifetime
    startCookieWarmer(db);
});
server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error(`Port ${port} is already in use.`);
        console.error(`Set a different PORT in apps/server/.env, then restart pnpm dev.`);
        process.exit(1);
    }
    console.error(err);
    process.exit(1);
});
// === Graceful shutdown ===
async function gracefulShutdown(signal) {
    console.log(`[Server] Received ${signal}, shutting down gracefully...`);
    // 0. Stop the health checker, selector monitor, and cookie warmer
    stopHealthChecker();
    stopCookieWarmer();
    selectorMonitor.stop();
    // 1. Clear the scheduler and cache cleanup intervals
    if (schedulerHandle) {
        clearInterval(schedulerHandle);
        schedulerHandle = undefined;
        console.log('[Server] Scheduler stopped');
    }
    if (cacheCleanupHandle) {
        clearInterval(cacheCleanupHandle);
        cacheCleanupHandle = undefined;
        console.log('[Server] Cache cleanup stopped');
    }
    // 2. Close the RPA engine browser (if running)
    try {
        await publisher.close();
    }
    catch (err) {
        console.error('[Server] Error closing publisher/RPA engine:', err instanceof Error ? err.message : err);
    }
    // 3. Close the database connection
    try {
        db.close();
        console.log('[Server] Database closed');
    }
    catch (err) {
        console.error('[Server] Error closing database:', err instanceof Error ? err.message : err);
    }
    // 4. Exit
    process.exit(0);
}
process.on('SIGTERM', () => void gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => void gracefulShutdown('SIGINT'));
//# sourceMappingURL=index.js.map
