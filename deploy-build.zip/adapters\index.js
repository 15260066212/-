export { WechatAdapter } from './wechat.js';
//# sourceMappingURL=index.js.map