import { Hono } from 'hono';
import type { DatabaseAccess } from '../db.js';
export declare function createCookieHarvesterRoutes(db: DatabaseAccess): Hono;
//# sourceMappingURL=cookie-harvester.d.ts.map