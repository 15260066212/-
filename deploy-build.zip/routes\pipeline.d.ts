import { Hono } from 'hono';
import type { DatabaseAccess } from '../db.js';
export declare function createPipelineRoutes(db: DatabaseAccess): Hono;
//# sourceMappingURL=pipeline.d.ts.map