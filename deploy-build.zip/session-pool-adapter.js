/**
 * SessionPool Adapter — implements ISessionPool for the server.
 *
 * Provides browser session persistence with fingerprint isolation:
 * - storageState save/restore (encrypted in database)
 * - WebRTC IP leak prevention
 * - Canvas/WebGL fingerprint randomization
 * - Cookie domain filtering per platform
 * - LRU eviction when pool is full
 *
 * Uses the server's existing crypto-util and database.
 * Falls back gracefully when Playwright is not installed.
 */
import { encrypt, decrypt } from '@zemingengine/account-vault';
import { getPlatformInfoBySessionName } from '@zemingengine/shared';
const MAX_CONCURRENT = 8;
const SESSION_MAX_AGE_MS = parseInt(process.env.SESSION_MAX_AGE_HOURS || '168', 10) * 60 * 60 * 1000; // 7 days default
const DEFAULT_FINGERPRINT = {
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.5493.5 Safari/537.36',
    viewport: { width: 1920, height: 1080 },
    timezone: 'Asia/Shanghai',
    locale: 'zh-CN',
    platform: 'Win32',
    webglVendor: 'Google Inc. (NVIDIA)',
    webglRenderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0)',
    canvasNoise: 0.0001,
    hardwareConcurrency: 8,
    deviceMemory: 16,
};
/**
 * Get the cookie domains for a platform from the shared platform registry.
 * Converts registry-style domains (e.g. "zhihu.com") to dot-prefixed format
 * (e.g. ".zhihu.com") for cookie filtering compatibility.
 */
function getPlatformDomains(platform) {
    const info = getPlatformInfoBySessionName(platform);
    return info?.domains?.map((d) => `.${d}`) ?? [];
}
export class SessionPoolAdapter {
    db;
    pool = new Map();
    browser = null;
    playwrightAvailable = false;
    constructor(db) {
        this.db = db;
        // Check if Playwright is available (async check, not blocking constructor)
        this.checkPlaywright();
    }
    async checkPlaywright() {
        try {
            await import('playwright');
            this.playwrightAvailable = true;
            console.log('[SessionPool] Playwright detected, session persistence enabled');
        }
        catch {
            this.playwrightAvailable = false;
            console.log('[SessionPool] Playwright not available, session persistence disabled (using remote mode)');
        }
    }
    async ensureBrowser() {
        if (this.browser && this.browser.isConnected())
            return this.browser;
        const { chromium } = await import('playwright');
        this.browser = await chromium.launch({
            headless: true,
            args: ['--no-sandbox', '--disable-blink-features=AutomationControlled', '--disable-gpu'],
        });
        console.log('[SessionPool] Browser launched');
        return this.browser;
    }
    async acquireContext(account) {
        if (!this.playwrightAvailable) {
            throw new Error('Playwright is not available — cannot acquire browser context');
        }
        const key = `${account.platform}:${account.accountId}`;
        // 1. Check pool for idle context
        const existing = this.pool.get(key);
        if (existing && !existing.inUse) {
            existing.inUse = true;
            existing.lastUsed = Date.now();
            console.log(`[SessionPool] Reused idle context for ${key}`);
            return existing.context;
        }
        // 2. Evict if full
        await this.evictIfFull();
        // 3. Create new context with fingerprint
        const browser = await this.ensureBrowser();
        const fp = DEFAULT_FINGERPRINT;
        // 4. Check for saved session
        const savedState = this.loadSession(account.accountId, account.platform);
        const sessionExpired = savedState && (Date.now() - savedState.savedAt > SESSION_MAX_AGE_MS);
        let context;
        if (savedState?.storageState && savedState.valid && !sessionExpired) {
            // Restore saved session with cookie domain filtering
            const rawState = JSON.parse(decrypt(savedState.storageState));
            const filteredState = this.filterCookiesByDomain(rawState, account.platform);
            context = await browser.newContext({
                storageState: filteredState,
                userAgent: fp.userAgent,
                viewport: fp.viewport,
                timezoneId: fp.timezone,
                locale: fp.locale,
                bypassCSP: true,
                extraHTTPHeaders: { 'Accept-Language': fp.locale },
            });
            await this.injectWebRTCBlocker(context);
            await this.injectFingerprintGuards(context, fp);
            console.log(`[SessionPool] Restored session for ${key}`);
        }
        else {
            // New context — no saved session
            context = await browser.newContext({
                userAgent: fp.userAgent,
                viewport: fp.viewport,
                timezoneId: fp.timezone,
                locale: fp.locale,
                bypassCSP: true,
                extraHTTPHeaders: { 'Accept-Language': fp.locale },
            });
            await this.injectWebRTCBlocker(context);
            await this.injectFingerprintGuards(context, fp);
            console.log(`[SessionPool] Created new context for ${key} (no saved session)`);
        }
        this.pool.set(key, {
            context,
            accountId: account.accountId,
            platform: account.platform,
            lastUsed: Date.now(),
            inUse: true,
        });
        return context;
    }
    async releaseContext(accountId, platform) {
        const key = `${platform}:${accountId}`;
        const entry = this.pool.get(key);
        if (entry) {
            entry.inUse = false;
            entry.lastUsed = Date.now();
            // Persist refreshed cookies back to database after each use
            try {
                const state = await entry.context.storageState();
                const encrypted = encrypt(JSON.stringify(state));
                this.db.credentials.saveBrowserSession(accountId, platform, encrypted);
                console.log(`[SessionPool] Session refreshed and saved after release: ${platform}:${accountId}`);
            }
            catch (err) {
                console.warn(`[SessionPool] Failed to save session on release:`, err instanceof Error ? err.message : err);
            }
        }
    }
    async saveSession(accountId, platform, context, _userDataDir, fingerprintId) {
        try {
            const state = await context.storageState();
            const encrypted = encrypt(JSON.stringify(state));
            this.db.credentials.saveBrowserSession(accountId, platform, encrypted, fingerprintId);
            console.log(`[SessionPool] Session saved for ${platform}:${accountId}`);
        }
        catch (err) {
            console.warn(`[SessionPool] Failed to save session:`, err instanceof Error ? err.message : err);
        }
    }
    async close() {
        for (const [, entry] of this.pool) {
            try {
                await entry.context.close();
            }
            catch (err) {
                console.warn('[SessionPool] Failed to close browser context', { error: err instanceof Error ? err.message : String(err) });
            }
        }
        this.pool.clear();
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
        }
        console.log('[SessionPool] Closed');
    }
    loadSession(accountId, platform) {
        return this.db.credentials.getBrowserSession(accountId, platform);
    }
    filterCookiesByDomain(storageState, platform) {
        if (!storageState || typeof storageState !== 'object')
            return storageState;
        const state = storageState;
        if (!state.cookies)
            return storageState;
        const allowedDomains = getPlatformDomains(platform);
        if (allowedDomains.length === 0)
            return storageState;
        const filtered = state.cookies.filter((cookie) => {
            const domain = cookie.domain || '';
            return allowedDomains.some((d) => domain.endsWith(d) || domain === d.slice(1));
        });
        return { ...state, cookies: filtered };
    }
    async injectWebRTCBlocker(context) {
        await context.addInitScript(() => {
            const origRTCPeerConnection = window.RTCPeerConnection;
            const origWebkitRTCPeerConnection = window.webkitRTCPeerConnection;
            window.RTCPeerConnection = function (...args) {
                if (args[0]?.iceServers) {
                    args[0].iceServers = [];
                }
                const pc = new origRTCPeerConnection(args[0]);
                return pc;
            };
            window.webkitRTCPeerConnection =
                window.RTCPeerConnection;
            void origWebkitRTCPeerConnection;
        });
    }
    async injectFingerprintGuards(context, fp) {
        await context.addInitScript((fingerprint) => {
            Object.defineProperty(navigator, 'platform', { get: () => fingerprint.platform });
            Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => fingerprint.hardwareConcurrency });
            Object.defineProperty(navigator, 'deviceMemory', { get: () => fingerprint.deviceMemory });
            Object.defineProperty(navigator, 'language', { get: () => fingerprint.locale });
            Object.defineProperty(navigator, 'languages', { get: () => [fingerprint.locale, 'en-US'] });
            const getParameterProto = WebGLRenderingContext.prototype.getParameter;
            WebGLRenderingContext.prototype.getParameter = function (param) {
                if (param === 37445)
                    return fingerprint.webglVendor;
                if (param === 37446)
                    return fingerprint.webglRenderer;
                return getParameterProto.call(this, param);
            };
            const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
            HTMLCanvasElement.prototype.toDataURL = function (...args) {
                const ctx = this.getContext('2d');
                if (ctx) {
                    const w = this.width, h = this.height;
                    if (w > 0 && h > 0) {
                        const imageData = ctx.getImageData(0, 0, w, h);
                        for (let i = 0; i < imageData.data.length; i += 4) {
                            imageData.data[i] ^= Math.floor(fingerprint.canvasNoise * 255);
                        }
                        ctx.putImageData(imageData, 0, 0);
                    }
                }
                return origToDataURL.apply(this, args);
            };
        }, fp);
    }
    async evictIfFull() {
        if (this.pool.size < MAX_CONCURRENT)
            return;
        let oldestKey = null;
        let oldestTime = Date.now();
        for (const [key, entry] of this.pool) {
            if (!entry.inUse && entry.lastUsed < oldestTime) {
                oldestTime = entry.lastUsed;
                oldestKey = key;
            }
        }
        if (oldestKey) {
            const entry = this.pool.get(oldestKey);
            if (entry) {
                await entry.context.close();
                this.pool.delete(oldestKey);
                console.log(`[SessionPool] Evicted ${oldestKey} (pool full)`);
            }
        }
    }
    getStats() {
        let active = 0, idle = 0;
        for (const [, entry] of this.pool) {
            if (entry.inUse)
                active++;
            else
                idle++;
        }
        return { total: this.pool.size, active, idle, max: MAX_CONCURRENT, playwrightAvailable: this.playwrightAvailable };
    }
}
//# sourceMappingURL=session-pool-adapter.js.map