import type { Article, ReviewIssue } from '@zemingengine/shared';
export declare function checkOriginality(article: Article): ReviewIssue[];
//# sourceMappingURL=originality.d.ts.map