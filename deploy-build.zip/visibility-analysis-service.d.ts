interface Brand {
    name?: string;
    aliases?: string[];
    primary_keywords?: string[];
    website?: string;
}
interface Competitor {
    id?: string | null;
    name?: string;
    aliases?: string[];
    website?: string;
}
interface MentionStats {
    mentions: number;
    first_index: number;
    mentioned: boolean;
}
interface Range {
    start: number;
    end: number;
}
export declare class VisibilityAnalysisService {
    /**
     * Classify a domain into an ecosystem bucket for platform-specific weighting.
     * Delegates to the shared classifier in source-utils.ts (single source of truth).
     */
    classifySourceEcosystem(domain: string): string;
    /**
     * Get the platform-specific source ecosystem weight multiplier.
     * Different LLM platforms weight sources from different ecosystems differently.
     */
    getSourceWeight(platform: string, ecosystem: string): number;
    /**
     * Calculate a freshness multiplier based on content publish date.
     * Doubao weights 1-2 week content highest; citation rates drop sharply after 1 month.
     * Returns 1.0 for fresh content, STALE_CONTENT_PENALTY for stale, 1.0 if no date available.
     */
    getFreshnessMultiplier(publishTime: string | undefined | null): number;
    /**
     * Check if a source is stale (older than FRESHNESS_THRESHOLD_DAYS).
     */
    isStaleSource(publishTime: string | undefined | null): boolean;
    normalizeTerms(name: string | undefined, aliases: string[] | undefined): string[];
    termVariants(term: string): string[];
    countTerm(text: string, term: string): {
        count: number;
        firstIndex: number;
    };
    termMatches(text: string, term: string): Range[];
    shouldSkipGenericChineseMatch(text: string, term: string, range: Range): boolean;
    canMatchModelSuffix(term: string): boolean;
    overlaps(a: Range, b: Range): boolean;
    termRanges(text: string, terms: string[]): Range[];
    mentionStats(text: string, terms: string[]): MentionStats;
    buildBrandVisibilityTerms(brand: Brand): string[];
    compactTerm(term: string): string;
    removeOverlappingTerms(terms: string[], blockedTerms: string[]): string[];
    isModelLikeProductTerm(term: string): boolean;
    isRecommended(text: string, firstIndex: number): boolean;
    isAnyMentionRecommended(text: string, terms: string[]): boolean;
    visibilityScore(stats: MentionStats, position: number | null, recommended: boolean, platform?: string, sourceDomain?: string, publishTime?: string | null): number;
    /**
     * Compute mention stats for each competitor, removing overlapping brand terms.
     */
    private collectCompetitorStats;
    /**
     * Build a position ranking from brand + competitor mention stats.
     * Returns brand position (1-based) and a map of competitor position keys to ranks.
     */
    private positionCompetitors;
    /**
     * Calculate visibility scores for brand and all competitors.
     */
    private calculateScores;
    /**
     * Assemble the final analysis result object.
     */
    private buildResult;
    analyzeResponse({ responseText, brand, competitors }: {
        responseText: string;
        brand: Brand;
        competitors: Competitor[];
    }): {
        brand_mentioned: boolean;
        brand_mentions: number;
        brand_first_index: number;
        brand_position: number;
        brand_rank: number;
        brand_recommended: boolean;
        visibility_score: number;
        competitor_mentions: {
            id: string;
            name: string;
            mentions: number;
            mentioned: boolean;
            first_index: number;
            position: number;
            rank: number;
            recommended: boolean;
            visibility_score: number;
        }[];
        share_of_voice: number;
        freshness_alerts: {
            threshold_days: number;
            warning: string;
        };
    };
}
export declare const visibilityAnalysisService: VisibilityAnalysisService;
export {};
//# sourceMappingURL=visibility-analysis-service.d.ts.map