export class BaseValidator {
    measure(fn) {
        const start = Date.now();
        return fn().then((result) => ({
            result,
            durationMs: Date.now() - start,
        }));
    }
}
//# sourceMappingURL=base.js.map