/**
 * Quota management Hono routes (brand_id based).
 *
 * Mount at: app.route('/api/publish-quotas', createQuotaRoutes(db))
 *
 * Endpoints:
 *   GET  /                          — all quotas (all brands)
 *   GET  /:brandId                  — quotas for one brand
 *   PUT  /:brandId/:platform        — set/update a quota
 *   POST /init                      — run migration + set defaults
 */
import { Hono } from 'hono';
import { getQuotaStatus, getAllQuotaStatus, setQuota, runMigration, setDefaultQuotas } from './quota-manager.js';

export function createQuotaRoutes(db) {
  const app = new Hono();

  // GET all quotas
  app.get('/', (c) => {
    try {
      const all = getAllQuotaStatus(db.db);
      return c.json({ success: true, data: all });
    } catch (e) {
      return c.json({ success: false, error: e.message }, 500);
    }
  });

  // GET quotas for one brand
  app.get('/:brandId', (c) => {
    try {
      const brandId = Number(c.req.param('brandId'));
      const quotas = getQuotaStatus(db.db, brandId);
      return c.json({ success: true, data: quotas });
    } catch (e) {
      return c.json({ success: false, error: e.message }, 500);
    }
  });

  // PUT set/update quota
  app.put('/:brandId/:platform', async (c) => {
    try {
      const body = await c.req.json();
      const { dailyLimit, minInterval, isActive } = body;
      if (dailyLimit === undefined) {
        return c.json({ success: false, error: 'dailyLimit is required' }, 400);
      }
      const brandId = Number(c.req.param('brandId'));
      setQuota(
        db.db,
        brandId,
        c.req.param('platform'),
        Number(dailyLimit),
        Number(minInterval ?? 60),
        isActive !== false
      );
      return c.json({ success: true, message: `Quota updated: brand ${brandId} ${c.req.param('platform')} = ${dailyLimit}/day` });
    } catch (e) {
      return c.json({ success: false, error: e.message }, 500);
    }
  });

  // POST init (migration + defaults)
  app.post('/init', (c) => {
    try {
      runMigration(db.db);
      setDefaultQuotas(db.db);
      return c.json({ success: true, message: 'Quota system initialized' });
    } catch (e) {
      return c.json({ success: false, error: e.message }, 500);
    }
  });

  return app;
}
