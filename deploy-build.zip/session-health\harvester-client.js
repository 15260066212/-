import { getHarvesterPlatformName } from '@zemingengine/shared';
function hasRealAuthData(cookie, storageState) {
    return (!!cookie && cookie !== 'placeholder_pending_login') || !!storageState;
}
/**
 * Encapsulates HTTP communication with the RPA harvester service.
 * Provides shared methods for building request bodies, calling endpoints,
 * and extracting credential updates from refresh responses.
 */
export class HarvesterClient {
    baseUrl;
    constructor(harvesterUrl) {
        this.baseUrl = harvesterUrl.replace(/\/+$/, '');
    }
    /**
     * Build a refresh-cookies request body from credential data.
     * Returns null if no real auth data (cookie or storageState) is present.
     */
    buildRefreshBody(data, platform) {
        const cookie = data.cookie || data.cookies || '';
        const storageState = data.storageState || '';
        const fingerprintData = data.fingerprintData || '';
        if (!hasRealAuthData(cookie, storageState))
            return null;
        const harvesterPlatform = getHarvesterPlatformName(platform);
        const body = { platform: harvesterPlatform };
        if (storageState) {
            body.storageState = storageState;
        }
        else if (cookie) {
            body.cookies = cookie;
        }
        if (fingerprintData) {
            body.fingerprintData = fingerprintData;
        }
        return body;
    }
    /** Call /api/rpa/refresh-cookies. Returns null on HTTP error or fetch failure. */
    async refreshCookies(body, timeoutMs = 30000) {
        try {
            const res = await fetch(`${this.baseUrl}/api/rpa/refresh-cookies`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
                signal: AbortSignal.timeout(timeoutMs),
            });
            if (!res.ok)
                return null;
            return (await res.json());
        }
        catch {
            return null;
        }
    }
    /** Extract credential update fields from a successful refresh response. */
    static extractUpdateData(data) {
        const updateData = {};
        if (data.refreshedStorageState) {
            updateData.storageState = data.refreshedStorageState;
            if (data.refreshedCookies) {
                updateData.cookie = data.refreshedCookies;
            }
        }
        else if (data.refreshedCookies) {
            updateData.cookie = data.refreshedCookies;
        }
        if (data.refreshedFingerprintData) {
            updateData.fingerprintData = data.refreshedFingerprintData;
        }
        return updateData;
    }
    // ============ Profile Management ============
    /** List all account profiles on the harvester. */
    async listProfiles(timeoutMs = 10000) {
        try {
            const res = await fetch(`${this.baseUrl}/api/profiles`, {
                signal: AbortSignal.timeout(timeoutMs),
            });
            if (!res.ok)
                return null;
            const data = await res.json();
            return data.profiles || [];
        }
        catch {
            return null;
        }
    }
    /** Check login health of a specific profile. */
    async checkProfileHealth(platform, accountName, timeoutMs = 20000) {
        try {
            const encodedAccount = encodeURIComponent(accountName);
            const res = await fetch(`${this.baseUrl}/api/profiles/${platform}/${encodedAccount}/health`, { signal: AbortSignal.timeout(timeoutMs) });
            if (!res.ok)
                return null;
            return (await res.json());
        }
        catch {
            return null;
        }
    }
    /** Delete an account profile. */
    async deleteProfile(platform, accountName, timeoutMs = 10000) {
        try {
            const encodedAccount = encodeURIComponent(accountName);
            const res = await fetch(`${this.baseUrl}/api/profiles/${platform}/${encodedAccount}`, {
                method: 'DELETE',
                signal: AbortSignal.timeout(timeoutMs),
            });
            if (!res.ok)
                return false;
            const data = await res.json();
            return data.deleted ?? data.success;
        }
        catch {
            return false;
        }
    }
    /** Renew a single profile's login state. */
    async renewProfile(platform, accountName, timeoutMs = 30000) {
        try {
            const encodedAccount = encodeURIComponent(accountName);
            const res = await fetch(`${this.baseUrl}/api/profiles/${platform}/${encodedAccount}/renew`, {
                method: 'POST',
                signal: AbortSignal.timeout(timeoutMs),
            });
            if (!res.ok)
                return null;
            return (await res.json());
        }
        catch {
            return null;
        }
    }
    /** Renew all profiles at once. */
    async renewAllProfiles(timeoutMs = 120000) {
        try {
            const res = await fetch(`${this.baseUrl}/api/profiles/renew-all`, {
                method: 'POST',
                signal: AbortSignal.timeout(timeoutMs),
            });
            if (!res.ok)
                return null;
            return (await res.json());
        }
        catch {
            return null;
        }
    }
    // ============ LLMwiki Publish ============
    /**
     * Publish an article via LLMwiki endpoint (profile-first mode).
     * @param platform Harvester platform name (e.g. 'toutiaohao')
     * @param article Article content
     * @param options Account name + optional cookie/storageState fallback
     */
    async publishLLMwiki(platform, article, options, timeoutMs = 60000) {
        try {
            const res = await fetch(`${this.baseUrl}/api/llmwiki/publish`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    platform,
                    article,
                    credentials: {
                        accountName: options.accountName,
                        platform,
                        data: {
                            cookie: options.cookieString || '',
                            storageState: options.storageState || '',
                        },
                    },
                }),
                signal: AbortSignal.timeout(timeoutMs),
            });
            if (!res.ok) {
                const err = await res.text().catch(() => 'Unknown error');
                return { success: false, publishMode: 'fresh', error: err };
            }
            return (await res.json());
        }
        catch (err) {
            return {
                success: false,
                publishMode: 'fresh',
                error: err instanceof Error ? err.message : String(err),
            };
        }
    }
}
//# sourceMappingURL=harvester-client.js.map