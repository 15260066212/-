import type { PublishTask } from '@zemingengine/shared';
export type DispatchSkipReason = 'concurrency' | 'in_progress' | 'cooldown' | null;
export interface DispatchGuard {
    accountKey: string;
    skipReason: DispatchSkipReason;
}
/**
 * Manages concurrency control for scheduled publishing.
 *
 * Tracks:
 * - Global concurrency limit (max active tasks)
 * - Per-account in-progress tracking (one task per account at a time)
 * - Per-account cooldown periods (rate-limit protection between publishes)
 *
 * Encapsulates all mutable state so the scheduler tick function only
 * deals with task selection and dispatch, not state bookkeeping.
 */
export declare class PublishConcurrencyController {
    private publishingAccounts;
    private accountCooldowns;
    private activeCount;
    private maxConcurrent;
    constructor(maxConcurrent?: number);
    /**
     * Check whether a task can be dispatched right now.
     * Returns a guard object with the reason if it must be skipped.
     */
    checkDispatch(task: PublishTask, now: number): DispatchGuard;
    /** Mark a task as started (increment active count, add to in-progress set). */
    startDispatch(accountKey: string): void;
    /**
     * Mark a task as finished (decrement active count, remove from in-progress,
     * set cooldown for the account).
     */
    finishDispatch(accountKey: string, cooldownMs: number, now: number): void;
    /** Get the current number of active publish tasks. */
    getActiveCount(): number;
    /** Get the max concurrent task limit. */
    getMaxConcurrent(): number;
    /** Check if a specific account is currently publishing. */
    isPublishing(accountKey: string): boolean;
    /** Get the cooldown end timestamp for an account (or undefined if not cooling). */
    getCooldownEnd(accountKey: string): number | undefined;
    /** Build the account-level key used for tracking. */
    getAccountKey(task: PublishTask): string;
}
//# sourceMappingURL=concurrency-controller.d.ts.map