import type { ReviewIssue, ReviewWeights, DimensionResult } from '@zemingengine/shared';
export declare function calculateScore(issues: ReviewIssue[], dimension: string): DimensionResult;
export declare function calculateWeightedScore(dimensions: Record<string, DimensionResult>, weights?: ReviewWeights): number;
//# sourceMappingURL=scorer.d.ts.map