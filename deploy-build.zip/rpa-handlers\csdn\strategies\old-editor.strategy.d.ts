import type { Page } from 'playwright';
import type { Article } from '@zemingengine/shared';
import type { PublishResult } from '../../../types.js';
import { BaseCsdnStrategy } from './base.js';
/**
 * Strategy 2: Old Editor + Publish Button
 *
 * Navigate to mp.csdn.net/mp_blog/creation/editor, fill title / HTML content
 * via CKEditor / tags, click "发布文章" button (NOT "保存草稿"), handle the
 * publish dialog, and capture the saveArticle response.
 */
export declare class OldEditorStrategy extends BaseCsdnStrategy {
    readonly name = "Old Editor + Publish Button";
    execute(page: Page, article: Article): Promise<PublishResult>;
}
//# sourceMappingURL=old-editor.strategy.d.ts.map