/**
 * CachedDatabaseAccess — wraps DatabaseAccess with an LRU cache layer.
 *
 * Read operations check the cache first; on miss, they delegate to the
 * underlying DatabaseAccess and store the result. Write operations
 * invalidate related cache entries after successfully writing to the DB.
 *
 * Cache TTLs:
 *   - getArticle:           60s   (article:{id})
 *   - getArticlesBySession: 30s   (articles:session:{sessionId})
 *   - getPublishTask:       30s   (task:{id})
 *   - getCredential:       120s   (cred:{platform})
 *   - getSession:           30s   (session:{id})
 *   - healthCheck:          10s   (health)
 *   - getQueueStatus:       10s   (queue:status)
 */
import type { Article, ReviewResult, PublishTask, PublishLog, PlatformCredentials, SessionData } from '@zemingengine/shared';
import { DatabaseAccess, type DB } from './db.js';
import { LRUCache } from './cache.js';
type SqliteDatabase = DB;
export declare class CachedDatabaseAccess extends DatabaseAccess {
    private cache;
    constructor(db: SqliteDatabase);
    /** Create a CachedDatabaseAccess with a fresh database connection. */
    static create(): CachedDatabaseAccess;
    /** Expose the underlying cache for stats and management. */
    getCache(): LRUCache;
    getArticle(id: string): Article | undefined;
    getArticlesBySession(sessionId: string): Article[];
    getPublishTask(id: string): PublishTask | undefined;
    getCredential(platform: string, userId?: string, accountId?: string): PlatformCredentials | undefined;
    getSession(id: string): SessionData | undefined;
    healthCheck(): {
        healthy: boolean;
        details: Record<string, unknown>;
    };
    getQueueStatus(): {
        pending: number;
        publishing: number;
        published: number;
        failed: number;
        retrying: number;
        total: number;
    };
    getLatestReview(articleId: string): ReviewResult | undefined;
    getReviewsByArticle(articleId: string): ReviewResult[];
    insertArticle(article: Article): void;
    updateArticle(id: string, updates: Partial<Article>): void;
    insertPublishTask(task: PublishTask): void;
    updatePublishTask(id: string, updates: Partial<PublishTask>): void;
    upsertCredential(platform: string, cred: PlatformCredentials, userId?: string): void;
    deleteCredential(platform: string, userId?: string, accountId?: string): void;
    upsertSession(id: string, data: SessionData, userId?: string): void;
    deleteSessionCascade(sessionId: string): void;
    insertReview(review: ReviewResult): string;
    insertPublishLog(log: PublishLog): void;
    runInTransaction<T>(fn: () => T): T;
}
export {};
//# sourceMappingURL=cached-db.d.ts.map