import { PlatformCredentials, PlatformId } from '@zemingengine/shared';
declare const DEFAULT_USER_ID = "user_default";
declare const DEFAULT_ACCOUNT_ID = "default";
/**
 * Validates a sync payload.
 * Returns null if valid, or an error message string if invalid.
 */
export declare function validateSyncPayload(body: any): string | null;
/**
 * Builds a PlatformCredentials object from a sync payload.
 * Encapsulates all the rules: type is always cookie, status defaults to active,
 * platformName has a 3-tier fallback, etc.
 */
export declare function buildCredentialFromSyncPayload(body: any, existing: PlatformCredentials | null, platform: PlatformId, accountId: string): PlatformCredentials;
/**
 * Checks if a credential is valid (has non-empty data).
 */
export declare function isCredentialValid(cred: PlatformCredentials): boolean;
export { DEFAULT_USER_ID, DEFAULT_ACCOUNT_ID };
//# sourceMappingURL=credential-sync-service.d.ts.map