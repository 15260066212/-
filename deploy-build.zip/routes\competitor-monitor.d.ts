import { Hono } from 'hono';
export declare function createCompetitorMonitorRoutes(): Hono<import("hono/types").BlankEnv, import("hono/types").BlankSchema, "/">;
//# sourceMappingURL=competitor-monitor.d.ts.map