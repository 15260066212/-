/**
 * SelectorMonitor — Periodically validates CSS selectors against live
 * platform pages to detect structural changes before they cause publish failures.
 *
 * Flow:
 * 1. Runs every 6 hours (or manually triggered)
 * 2. For each platform in SELECTOR_REGISTRY, calls harvester's /api/rpa/validate-selectors
 * 3. Records results in selector_health_logs table
 * 4. Creates health alerts for broken selector purposes
 * 5. Monitor API exposes status and manual trigger
 */
import type { DatabaseAccess } from '../db.js';
interface SelectorValidationResult {
    success: boolean;
    platform: string;
    finalUrl?: string;
    pageTitle?: string;
    results?: Array<{
        selector: string;
        purpose: string;
        found: boolean;
        count: number;
        visible: boolean;
        error?: string;
    }>;
    summary?: {
        total: number;
        found: number;
        missing: number;
        byPurpose: Array<{
            purpose: string;
            total: number;
            found: number;
            missing: number;
            status: 'ok' | 'degraded' | 'broken';
        }>;
        brokenPurposes: string[];
    };
    error?: string;
    errorType?: string;
}
export declare class SelectorMonitor {
    private db;
    private isRunning;
    private lastRunTime;
    private intervalHandle;
    constructor(db: DatabaseAccess);
    /** Start the periodic selector health check. */
    start(): void;
    /** Stop the periodic check. */
    stop(): void;
    /** Check if a check is currently running. */
    isCheckRunning(): boolean;
    /** Get the timestamp of the last completed check run. */
    getLastRunTime(): number;
    /** Get monitor status for API. */
    getStatus(): {
        running: boolean;
        lastRunTime: number;
        intervalMs: number;
        registeredPlatforms: string[];
        stats: {
            totalChecks: number;
            totalBrokenPurposes: number;
            byPlatform: Array<{
                platform: string;
                lastChecked: number;
                foundSelectors: number;
                totalSelectors: number;
                brokenPurposes: string[];
            }>;
        };
    };
    /** Run a selector health check for all registered platforms. */
    runCheck(): Promise<void>;
    /** Validate selectors for a single platform. */
    checkPlatform(platform: string, harvesterUrl?: string, triggeredBy?: string): Promise<SelectorValidationResult>;
    /** Call the harvester's validate-selectors endpoint. */
    private callHarvester;
}
export {};
//# sourceMappingURL=selector-monitor.d.ts.map