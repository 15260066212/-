import { type HealthCheckStatus } from './types.js';
/**
 * Pure utility functions for session health status transitions.
 * Extracted from SessionHealthChecker so they can be tested in isolation.
 */
export interface TransitionAlertDecision {
    shouldAlert: boolean;
    alertType?: 'session_recovered' | 'session_expired' | 'consecutive_failures';
    message?: string;
}
/**
 * Determine whether a credential should be marked as expired
 * based on the number of consecutive failures.
 *
 * Pure function — no side effects, same input always gives same output.
 */
export declare function shouldMarkExpired(failures: number, maxFailures?: number): boolean;
/**
 * Determine what alert (if any) should be created when a health check completes.
 *
 * Pure function — decides based solely on the input parameters.
 *
 * @param previousStatus - The health status before this check
 * @param currentStatus - The health status after this check (before auto-upgrade)
 * @param consecutiveFailures - Number of consecutive failures (including this one)
 * @param errorMessage - Error message from the current failed check (if any)
 * @param maxFailures - Threshold for marking a credential expired
 */
export declare function getTransitionAlert(previousStatus: HealthCheckStatus | undefined, currentStatus: HealthCheckStatus, consecutiveFailures: number, errorMessage: string | undefined, maxFailures?: number): TransitionAlertDecision;
/**
 * Compute the final status after applying consecutive-failure auto-upgrade.
 *
 * Pure function — given current status and failure count, returns the final status.
 */
export declare function computeFinalStatus(currentStatus: HealthCheckStatus, consecutiveFailures: number, maxFailures?: number): HealthCheckStatus;
//# sourceMappingURL=status-utils.d.ts.map