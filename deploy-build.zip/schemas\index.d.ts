import type { DB } from '../db.js';
export { initSessionsTable } from './sessions.schema.js';
export { initArticlesTable } from './articles.schema.js';
export { initReviewTables, DEFAULT_REVIEW_DIMENSION_SCORE } from './reviews.schema.js';
export { initPublishTables, DEFAULT_MAX_PUBLISH_RETRIES } from './publish.schema.js';
export { initCredentialsTable, DEFAULT_CREDENTIAL_CHECK_INTERVAL_MS } from './credentials.schema.js';
export { initPipelineTables } from './pipeline.schema.js';
export { initMonitorTables } from './competitor-monitor.schema.js';
export { initUserTables } from './auth.schema.js';
export { initPlanTables } from './optimization-plan.schema.js';
export declare function initDatabase(db: DB): void;
//# sourceMappingURL=index.d.ts.map