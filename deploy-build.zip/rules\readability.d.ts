import type { Article, ReviewIssue } from '@zemingengine/shared';
export declare function checkReadability(article: Article): ReviewIssue[];
//# sourceMappingURL=readability.d.ts.map