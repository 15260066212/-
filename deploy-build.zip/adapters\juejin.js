import { PlatformAdapter } from './base.js';
export class JuejinAdapter extends PlatformAdapter {
    constructor() {
        super('juejin');
    }
    getMethod() {
        return 'rpa';
    }
    async publish(_params) {
        return {
            success: true,
            postId: 'mock_post_id',
            postUrl: 'https://example.com',
        };
    }
}
//# sourceMappingURL=juejin.js.map