import { PlatformAdapter } from './base.js';
export class BilibiliAdapter extends PlatformAdapter {
    constructor() {
        super('bilibili');
    }
    getMethod() {
        return 'rpa';
    }
    async publish(_params) {
        return {
            success: true,
            postId: 'mock_post_id',
            postUrl: 'https://example.com',
        };
    }
}
//# sourceMappingURL=bilibili.js.map