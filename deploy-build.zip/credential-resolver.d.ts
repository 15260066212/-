import type { DatabaseAccess } from './db.js';
import type { PlatformCredentials } from '@zemingengine/shared';
/**
 * Options for resolving publish credentials.
 *
 * Resolution order:
 * 1. Explicit accountId (if provided) → look up that specific credential
 * 2. Brand-based lookup (if brandId provided) → find first active credential for the brand
 * 3. Dynamic pool fallback → find any active credential for the platform
 */
export interface ResolveCredentialOptions {
    /** Explicit account ID to use. If provided, this credential is tried first. */
    accountId?: string;
    /** Brand ID for brand-scoped credential pool lookup. */
    brandId?: number;
    /** Cookie string to exclude from alternatives (avoid reusing a known-bad cookie). */
    excludeCookie?: string;
}
/** Result of credential resolution. */
export type CredentialResolutionResult = {
    success: true;
    credentials: PlatformCredentials;
} | {
    success: false;
    reason: string;
    failureType: 'auth' | 'platform';
};
/**
 * Resolve credentials for publishing to a platform.
 *
 * Tries, in order:
 * 1. The explicitly specified account (if accountId provided)
 * 2. Brand-specific active credentials (if brandId provided)
 * 3. Any active credential from the platform pool
 *
 * Returns the first usable active credential found, or a failure reason.
 */
export declare function resolvePublishCredential(db: DatabaseAccess, platform: string, userId: string, options?: ResolveCredentialOptions): CredentialResolutionResult;
/**
 * Resolve accountId from a request body with multiple possible sources.
 *
 * Priority:
 * 1. body.accountIds[platform] — per-platform account map
 * 2. body.accountId — single shared account ID
 * 3. body.brandId → look up first active credential for the brand
 * 4. undefined — caller will use 'default'
 */
export declare function resolveAccountIdFromBody(body: {
    accountId?: string;
    accountIds?: Partial<Record<string, string>>;
    brandId?: number;
}, platform: string, db: DatabaseAccess, userId: string): string | undefined;
//# sourceMappingURL=credential-resolver.d.ts.map