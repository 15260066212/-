import { Hono } from 'hono';
import type { AppEnv, DatabaseAccess } from '../db.js';
/**
 * Profile management routes — proxies to harvester's profile API.
 *
 * Mounted at: /api/profiles
 *
 * Endpoints:
 *   GET    /                          - List all profiles
 *   GET    /:platform                 - List profiles for a platform
 *   GET    /:platform/:account/health - Check login health
 *   DELETE /:platform/:account        - Delete a profile
 *   POST   /:platform/:account/renew  - Renew a single profile
 *   POST   /renew-all                 - Renew all profiles
 */
export declare function createProfileRoutes(db: DatabaseAccess): Hono<AppEnv>;
//# sourceMappingURL=profiles.d.ts.map