import { HarvesterBrowserValidator } from './harvester-browser.js';
export declare class ToutiaoValidator extends HarvesterBrowserValidator {
    readonly platform: "toutiao";
    protected get harvesterPlatform(): string;
}
//# sourceMappingURL=toutiao.d.ts.map