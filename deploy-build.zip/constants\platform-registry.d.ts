/**
 * Unified platform registry — single source of truth for all platform metadata.
 *
 * Previously, platform name mappings were scattered across multiple files:
 * - PLATFORM_HARVESTER_MAP in cookie-warmer.ts
 * - PLATFORM_ID_TO_SESSION_NAME in rpa-engine.ts
 * - PLATFORM_NAMES / PLATFORM_URLS in shared
 * - PLATFORM_TO_LLMWIKI in remote-publisher.ts and llmwiki-handler.ts
 *
 * This module consolidates all platform metadata into one place so that
 * adding a new platform only requires updating this file.
 */
import type { PlatformId } from '../types/platform.types.js';
/**
 * Platform capability flags — describes what each publishing platform supports.
 */
export interface PlatformCapabilities {
    /** Whether the platform supports tags/labels */
    hasTags: boolean;
    /** Maximum number of tags allowed (if hasTags) */
    maxTags?: number;
    /** Whether the platform supports categories/channels */
    hasCategory: boolean;
    /** Content format expected by the editor */
    contentFormat: 'markdown' | 'html' | 'plaintext';
    /** Whether this platform is published via API (vs RPA) */
    isApiPlatform: boolean;
}
/**
 * Login automation configuration for platforms that support auto-login.
 */
export interface PlatformLoginConfig {
    loginUrl: string;
    usernameSelector: string;
    passwordSelector: string;
    submitSelector: string;
    switchToPasswordSelector?: string;
    successUrl: string;
    successSelectors: string[];
    captchaSelectors: string[];
    maxWaitMs: number;
}
export interface PlatformInfo {
    /** Canonical platform ID (used throughout the system) */
    id: PlatformId;
    /** Chinese display label for UI */
    label: string;
    /** Platform name used by the session pool / browser automation */
    sessionName: string;
    /** Platform name used by the harvester (cookie harvesting service) */
    harvesterName: string;
    /**
     * Editor / publish page URL (for RPA handlers and health checks).
     * @deprecated Use `editorUrl` instead — this field is kept for backward compatibility.
     */
    url?: string;
    /** Homepage URL of the platform */
    homepage?: string;
    /** Editor / publish page URL */
    editorUrl?: string;
    /** URL used to verify the user is logged in (harvester health checks) */
    checkUrl?: string;
    /** LLMWiki platform name (for LLMWiki fallback and remote publish) */
    llmwikiName?: string;
    /** Primary domain(s) for cookie filtering */
    domains?: string[];
    /** Login redirect URL patterns (indicates session expired) */
    loginRedirectPatterns?: string[];
    /** Text fragments found on login pages (for detecting login pages) */
    loginTexts?: string[];
    /** CSS selectors that indicate the user is logged in */
    loggedInSelectors?: string[];
    /** Auto-login configuration (for platforms that support it) */
    loginConfig?: PlatformLoginConfig;
    /** Names of authentication cookies for this platform */
    authCookieNames?: string[];
    /** Platform capabilities */
    capabilities: PlatformCapabilities;
}
/**
 * Get full platform info by ID.
 * Returns undefined for unknown platforms.
 */
export declare function getPlatformInfo(id: string): PlatformInfo | undefined;
/**
 * Get full platform info by session pool platform name (sessionName).
 * Falls back to ID-based lookup if no sessionName match is found.
 * Returns undefined for unknown platforms.
 */
export declare function getPlatformInfoBySessionName(sessionName: string): PlatformInfo | undefined;
/**
 * Get full platform info by harvester platform name (harvesterName).
 * Falls back to ID-based lookup if no harvesterName match is found.
 * Returns undefined for unknown platforms.
 */
export declare function getPlatformInfoByHarvesterName(harvesterName: string): PlatformInfo | undefined;
/**
 * Get the harvester platform name for a given platform ID.
 * Falls back to the original ID if no special mapping exists.
 */
export declare function getHarvesterPlatformName(platformId: string): string;
/**
 * Get the session pool platform name for a given platform ID.
 * Falls back to the original ID if no special mapping exists.
 */
export declare function getSessionPlatformName(platformId: string): string;
/**
 * Get the Chinese display label for a platform.
 * Falls back to the original ID if not found.
 */
export declare function getPlatformLabel(platformId: string): string;
/**
 * Get the editor / publish page URL for a platform.
 * Returns undefined if the platform has no editor URL (e.g., API-only platforms).
 */
export declare function getPlatformEditorUrl(id: string): string | undefined;
/**
 * Get the LLMWiki platform name for a platform.
 * Returns undefined if no LLMWiki mapping exists.
 */
export declare function getPlatformLLMWikiName(id: string): string | undefined;
/**
 * Get the primary domain(s) for a platform.
 * Returns an empty array if no domains are configured.
 */
export declare function getPlatformDomains(id: string): string[];
/**
 * Get authentication cookie names for a platform.
 */
export declare function getPlatformAuthCookieNames(id: string): string[];
/**
 * Get the capabilities descriptor for a platform.
 * Returns undefined for unknown platforms.
 */
export declare function getPlatformCapabilities(id: string): PlatformCapabilities | undefined;
/**
 * Check whether a platform is published via API (vs RPA).
 * Returns false for unknown platforms.
 */
export declare function isApiPlatform(id: string): boolean;
/**
 * Check whether a platform is published via RPA (vs API).
 * Returns false for unknown platforms.
 */
export declare function isRpaPlatform(id: string): boolean;
/**
 * List all registered publishing platforms.
 */
export declare function listAllPlatforms(): PlatformInfo[];
/**
 * List all API-based platforms.
 */
export declare function listApiPlatforms(): PlatformInfo[];
/**
 * List all RPA-based platforms.
 */
export declare function listRpaPlatforms(): PlatformInfo[];
/**
 * The full registry record (for advanced use cases like iteration).
 * Prefer the helper functions above for most usage.
 */
export declare const PLATFORM_REGISTRY: Record<PlatformId, PlatformInfo>;
//# sourceMappingURL=platform-registry.d.ts.map