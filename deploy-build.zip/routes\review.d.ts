import { Hono } from 'hono';
import type { DatabaseAccess } from '../db.js';
export declare function createReviewRoutes(db: DatabaseAccess): Hono;
//# sourceMappingURL=review.d.ts.map