import { Hono } from 'hono';
import type { AppEnv, DatabaseAccess } from '../db.js';
export declare function createCredentialRoutes(db: DatabaseAccess): Hono<AppEnv>;
//# sourceMappingURL=credentials.d.ts.map