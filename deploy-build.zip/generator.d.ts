import type { SessionData } from '@zemingengine/shared';
import type { GenerateRequest, GenerateResult } from './types.js';
export declare const FALLBACK_MODEL_ID = "fallback-template-v2";
export declare class ContentGenerator {
    private options;
    constructor(options?: {
        fallbackMode?: boolean;
    });
    generate(request: GenerateRequest, session: SessionData): Promise<GenerateResult>;
    private fallbackGenerate;
}
//# sourceMappingURL=generator.d.ts.map