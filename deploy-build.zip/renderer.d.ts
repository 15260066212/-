import type { SessionData } from '@zemingengine/shared';
export interface ManualOutput {
    markdown: string;
    filename: string;
    mimeType: string;
}
export declare function generateManual(session: SessionData): ManualOutput;
export declare function generateManualHtml(session: SessionData): string;
//# sourceMappingURL=renderer.d.ts.map