import { HarvesterBrowserValidator } from './harvester-browser.js';
export class JuejinValidator extends HarvesterBrowserValidator {
    platform = 'juejin';
}
//# sourceMappingURL=juejin.js.map