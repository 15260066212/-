import { Hono } from 'hono';
import type { DatabaseAccess } from '../db.js';
export declare const createOptimizationPlanRoutes: (db: DatabaseAccess) => Hono<import("hono/types").BlankEnv, import("hono/types").BlankSchema, "/">;
//# sourceMappingURL=optimization-plan.d.ts.map