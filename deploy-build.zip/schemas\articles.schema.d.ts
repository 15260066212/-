import type { DB } from '../db.js';
export declare function initArticlesTable(db: DB): void;
//# sourceMappingURL=articles.schema.d.ts.map