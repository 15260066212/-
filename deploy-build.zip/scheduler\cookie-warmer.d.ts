import type { DatabaseAccess } from '../db.js';
interface PlatformWarmStats {
    total: number;
    warmed: number;
    failed: number;
    lastWarmedAt: number | null;
    lastFailedAt: number | null;
}
interface WarmBatchResult {
    warmed: number;
    skipped: number;
    failed: number;
    retried: number;
}
/**
 * CookieWarmer — profile-first credential freshness manager.
 *
 * Encapsulates all warmer state (timer, stats, running flag) so there are
 * no module-level mutable variables. Exposes the same public API as the
 * previous functional version for drop-in replacement.
 */
export declare class CookieWarmer {
    private timer;
    private lastRunAt;
    private lastResult;
    private running;
    private platformStats;
    private db;
    private harvesterUrl;
    constructor(db: DatabaseAccess, harvesterUrl?: string);
    start(): void;
    stop(): void;
    getStatus(): {
        running: boolean;
        lastRunAt: Date;
        lastResult: WarmBatchResult;
        platformStats: {
            [k: string]: PlatformWarmStats;
        };
        adaptiveIntervalMs: number;
    };
    /**
     * Pre-publish warming: warm a specific platform's credentials on demand.
     * Called before publishing to ensure login state is fresh.
     */
    warmForPublish(platform: string, accountId?: string): Promise<{
        cookie: string;
        storageState?: string;
        fingerprintData?: string;
    } | null>;
    private runBatch;
    private selectCredentialsForWarming;
    private warmSingleWithRetry;
    /** Warm a single credential — try profile renewal first, fallback to cookie refresh. */
    private warmSingle;
    private getOrCreateStats;
    private getAdaptiveInterval;
}
export declare function startCookieWarmer(db: DatabaseAccess): void;
export declare function stopCookieWarmer(): void;
export declare function getCookieWarmerStatus(): {
    running: boolean;
    lastRunAt: Date;
    lastResult: WarmBatchResult;
    platformStats: {
        [k: string]: PlatformWarmStats;
    };
    adaptiveIntervalMs: number;
};
export declare function warmForPublish(db: DatabaseAccess, platform: string, accountId?: string): Promise<{
    cookie: string;
    storageState?: string;
    fingerprintData?: string;
} | null>;
export {};
//# sourceMappingURL=cookie-warmer.d.ts.map