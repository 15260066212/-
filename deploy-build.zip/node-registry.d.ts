/**
 * NodeRegistry — 节点注册中心
 *
 * 管理所有连接到主服务器的 harvester 节点（单机）。
 * 节点通过心跳维持在线状态，支持部署任务下发。
 *
 * 存储方式：内存 + JSON 文件持久化（避免改动数据库 schema）
 */
export type NodeStatus = 'online' | 'offline' | 'deploying';
export interface HarvesterNode {
    nodeId: string;
    name: string;
    endpoint?: string;
    version: string;
    status: NodeStatus;
    tags: string[];
    platformCount: number;
    activeSessions: number;
    os: string;
    cpuCores: number;
    memoryMB: number;
    registeredAt: string;
    lastHeartbeatAt: string;
    lastDeployAt?: string;
    lastDeployStatus?: 'success' | 'failed';
    ipAddress?: string;
}
export type DeployTaskStatus = 'pending' | 'running' | 'success' | 'failed' | 'cancelled';
export interface DeployTask {
    taskId: string;
    nodeId: string;
    targetVersion?: string;
    status: DeployTaskStatus;
    createdAt: string;
    startedAt?: string;
    finishedAt?: string;
    log: string[];
    error?: string;
    durationMs?: number;
}
export interface DeployBatch {
    batchId: string;
    name: string;
    targetVersion?: string;
    nodeIds: string[];
    status: DeployTaskStatus;
    createdAt: string;
    startedAt?: string;
    finishedAt?: string;
    createdBy?: string;
}
export declare class NodeRegistry {
    private nodes;
    private tasks;
    private batches;
    private pendingTasksByNode;
    private dataDir;
    private nodesFile;
    constructor(dataDir?: string);
    registerNode(info: {
        nodeId: string;
        name: string;
        endpoint?: string;
        version: string;
        tags?: string[];
        platformCount?: number;
        activeSessions?: number;
        os?: string;
        cpuCores?: number;
        memoryMB?: number;
        ipAddress?: string;
    }): HarvesterNode;
    heartbeat(nodeId: string, info?: {
        activeSessions?: number;
        platformCount?: number;
        version?: string;
    }): HarvesterNode | null;
    getNode(nodeId: string): HarvesterNode | undefined;
    listNodes(filter?: {
        tag?: string;
        status?: NodeStatus;
    }): HarvesterNode[];
    removeNode(nodeId: string): boolean;
    createDeployBatch(params: {
        nodeIds: string[];
        name?: string;
        targetVersion?: string;
        createdBy?: string;
    }): DeployBatch;
    private createTask;
    /** 节点拉取待执行的部署任务 */
    claimNextTask(nodeId: string): DeployTask | null;
    /** 节点上报部署进度 */
    updateTaskProgress(taskId: string, log: string): DeployTask | null;
    /** 节点上报部署完成 */
    completeTask(taskId: string, success: boolean, error?: string): DeployTask | null;
    getTask(taskId: string): DeployTask | undefined;
    getTasksForNode(nodeId: string, limit?: number): DeployTask[];
    getBatch(batchId: string): DeployBatch | undefined;
    listBatches(limit?: number): DeployBatch[];
    getBatchTasks(batchId: string): DeployTask[];
    cancelBatch(batchId: string): boolean;
    private checkOfflineNodes;
    private updateBatchStatusForTask;
    private timestamp;
    private loadFromDisk;
    private saveToDisk;
}
//# sourceMappingURL=node-registry.d.ts.map