import { validator } from 'hono/validator';
/**
 * Validators for common API inputs.
 * Uses hono's built-in validator (no extra dependency needed).
 */
// Message sending validation
export const messageValidator = validator('json', (value, c) => {
    const message = String(value?.message ?? '').trim();
    if (!message) {
        return c.json({ success: false, error: 'Message is required' }, 400);
    }
    if (message.length > 4000) {
        return c.json({ success: false, error: 'Message too long (max 4000 characters)' }, 400);
    }
    return { message };
});
// URL scrape validation
export const scrapeValidator = validator('json', (value, c) => {
    const url = String(value?.url ?? '').trim();
    if (!url) {
        return c.json({ success: false, error: 'URL is required' }, 400);
    }
    try {
        const parsed = new URL(url);
        if (!['http:', 'https:'].includes(parsed.protocol)) {
            return c.json({ success: false, error: 'Only http and https URLs are allowed' }, 400);
        }
    }
    catch {
        return c.json({ success: false, error: 'Invalid URL format' }, 400);
    }
    return { url };
});
// Credential upsert validation
export const credentialValidator = validator('json', (value, c) => {
    const platform = String(value?.platform ?? '').trim();
    if (!platform) {
        return c.json({ success: false, error: 'Platform is required' }, 400);
    }
    if (platform.length > 50) {
        return c.json({ success: false, error: 'Platform name too long' }, 400);
    }
    if (!value?.data || typeof value.data !== 'object') {
        return c.json({ success: false, error: 'Credential data is required and must be an object' }, 400);
    }
    return {
        platform,
        data: value.data,
        type: value?.type ? String(value.type) : 'cookie',
        status: value?.status ? String(value.status) : 'active',
    };
});
// Pipeline start validation
export const pipelineStartValidator = validator('json', (value, c) => {
    const sessionId = String(value?.sessionId ?? '').trim();
    if (!sessionId) {
        return c.json({ success: false, error: 'sessionId is required' }, 400);
    }
    const platforms = Array.isArray(value?.platforms) ? value.platforms.map(String) : undefined;
    if (platforms && platforms.length === 0) {
        return c.json({ success: false, error: 'platforms cannot be empty' }, 400);
    }
    return {
        sessionId,
        platforms,
        contentType: value?.contentType ? String(value.contentType) : 'knowledge_base_article',
    };
});
// Pagination params validator (query)
export const paginationValidator = validator('query', (value, c) => {
    const page = Math.max(1, Number(value?.page ?? 1));
    const pageSize = Math.min(100, Math.max(1, Number(value?.pageSize ?? 20)));
    return { page, pageSize };
});
//# sourceMappingURL=validators.js.map