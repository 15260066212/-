/**
 * SessionPool Adapter — implements ISessionPool for the server.
 *
 * Provides browser session persistence with fingerprint isolation:
 * - storageState save/restore (encrypted in database)
 * - WebRTC IP leak prevention
 * - Canvas/WebGL fingerprint randomization
 * - Cookie domain filtering per platform
 * - LRU eviction when pool is full
 *
 * Uses the server's existing crypto-util and database.
 * Falls back gracefully when Playwright is not installed.
 */
import type { BrowserContext } from 'playwright';
import type { DatabaseAccess } from './db.js';
import type { ISessionPool, SessionAccount } from '@zemingengine/publisher';
export declare class SessionPoolAdapter implements ISessionPool {
    private db;
    private pool;
    private browser;
    private playwrightAvailable;
    constructor(db: DatabaseAccess);
    private checkPlaywright;
    private ensureBrowser;
    acquireContext(account: SessionAccount): Promise<BrowserContext>;
    releaseContext(accountId: string, platform: string): Promise<void>;
    saveSession(accountId: string, platform: string, context: BrowserContext, _userDataDir: string, fingerprintId?: string): Promise<void>;
    close(): Promise<void>;
    private loadSession;
    private filterCookiesByDomain;
    private injectWebRTCBlocker;
    private injectFingerprintGuards;
    private evictIfFull;
    getStats(): {
        total: number;
        active: number;
        idle: number;
        max: number;
        playwrightAvailable: boolean;
    };
}
//# sourceMappingURL=session-pool-adapter.d.ts.map