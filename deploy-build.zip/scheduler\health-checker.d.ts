import type { SessionHealthChecker } from '../session-health/index.js';
export declare function startHealthChecker(checker: SessionHealthChecker): void;
export declare function stopHealthChecker(): void;
//# sourceMappingURL=health-checker.d.ts.map