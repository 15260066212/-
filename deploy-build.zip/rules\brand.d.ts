import type { Article, ReviewIssue, SessionData } from '@zemingengine/shared';
export declare function checkBrand(article: Article, session: SessionData): ReviewIssue[];
//# sourceMappingURL=brand.d.ts.map