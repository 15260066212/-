/**
 * Centralized constants for the publisher package.
 *
 * All magic numbers related to timeouts, retries, and default behavior
 * should live here so they can be tuned from a single source of truth.
 */
/** Default retry configuration for publish operations. */
export declare const PublishDefaults: {
    /** Default maximum number of retries (total attempts = maxRetries + 1). */
    readonly MAX_RETRIES: 2;
    /** Default base retry delay in ms for unknown/unclassified failures. */
    readonly BASE_RETRY_DELAY_MS: 3000;
};
/** Timeout constants used by RPAEngine for operations outside handler scope. */
export declare const EngineTimeout: {
    /** Page navigation timeout for post-publish verification. */
    readonly VERIFY_NAVIGATION_MS: 15000;
    /** Timeout for reading page content during verification. */
    readonly VERIFY_READ_MS: 5000;
    /** Timeout for LLMWiki fallback remote call. */
    readonly REMOTE_LLMWIKI_CALL_MS: 120000;
};
//# sourceMappingURL=constants.d.ts.map