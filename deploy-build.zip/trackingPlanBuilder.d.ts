import type { TrackingPlan } from '@zemingengine/shared';
export declare function buildTrackingPlan(): TrackingPlan;
//# sourceMappingURL=trackingPlanBuilder.d.ts.map