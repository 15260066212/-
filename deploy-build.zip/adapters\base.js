export class PlatformAdapter {
    platform;
    constructor(platform) {
        this.platform = platform;
    }
    getMethod() {
        return 'api';
    }
}
//# sourceMappingURL=base.js.map