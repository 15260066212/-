import type { DB } from '../db.js';
import type { SessionData } from '@zemingengine/shared';
export interface SessionListItem {
    id: string;
    stage: string;
    enterpriseName?: string;
    createdAt: string;
    updatedAt: string;
}
export declare class SessionRepository {
    private db;
    constructor(db: DB);
    /**
     * Wrap a function in a better-sqlite3 transaction.
     */
    private wrapTransaction;
    /**
     * Delete a session and all of its associated data atomically.
     *
     * Cascades to: articles (by session_id), reviews (by article_id),
     * publish_tasks (by article_id), publish_logs (by task_id), and
     * pipeline_runs (by session_id). All deletions run inside a single
     * transaction so the session is either fully removed with its
     * dependents or left untouched.
     */
    deleteSessionCascade(sessionId: string): void;
    upsertSession(id: string, data: SessionData, userId?: string): void;
    getSession(id: string): SessionData | undefined;
    deleteSession(id: string): void;
    /** Get all sessions belonging to a specific user. */
    getSessionsByUser(userId: string): SessionListItem[];
}
//# sourceMappingURL=session-repository.d.ts.map