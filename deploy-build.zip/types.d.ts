import type { Article, PlatformCredentials } from '@zemingengine/shared';
export interface PublishParams {
    article: Article;
    credentials: PlatformCredentials;
}
export interface PublishResult {
    success: boolean;
    postId?: string;
    postUrl?: string;
    error?: string;
    verificationStatus?: 'verified' | 'unverified' | 'failed' | 'api_confirmed' | 'draft_saved';
    verificationMessage?: string;
    /**
     * When true, the article was saved as a draft on the platform
     * (not actually published). The caller should treat this as a
     * partial success — the content is on the platform but needs
     * manual publishing action.
     */
    draftSaved?: boolean;
}
export type FailureType = 'network' | 'auth' | 'rate_limit' | 'content' | 'platform' | 'draft_saved' | 'unknown';
export interface FailureAnalysis {
    type: FailureType;
    category: string;
    description: string;
    retryable: boolean;
    retryDelayMs: number;
}
export declare function classifyFailure(error: string): FailureAnalysis;
//# sourceMappingURL=types.d.ts.map