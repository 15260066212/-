import { HarvesterBrowserValidator } from './harvester-browser.js';
export class SohuValidator extends HarvesterBrowserValidator {
    platform = 'sohu';
    get harvesterPlatform() {
        return 'sohuhao';
    }
}
//# sourceMappingURL=sohu.js.map