import type { DB } from '../db.js';
export declare class SelectorRepository {
    private db;
    constructor(db: DB);
    /** Record a selector health check result. */
    recordSelectorHealthCheck(platform: string, url: string, totalSelectors: number, foundSelectors: number, missingSelectors: number, brokenPurposes: string, resultsJson: string, triggeredBy?: string): void;
    /** Get recent selector health logs. */
    getSelectorHealthLogs(limit?: number, platform?: string): Array<{
        id: number;
        platform: string;
        url: string;
        totalSelectors: number;
        foundSelectors: number;
        missingSelectors: number;
        brokenPurposes: string | null;
        triggeredBy: string;
        checkedAt: number;
    }>;
    /** Get the latest selector health check for each platform. */
    getLatestSelectorHealth(): Array<{
        platform: string;
        url: string;
        totalSelectors: number;
        foundSelectors: number;
        missingSelectors: number;
        brokenPurposes: string | null;
        checkedAt: number;
    }>;
    /** Get selector health statistics. */
    getSelectorHealthStats(): {
        totalChecks: number;
        totalBrokenPurposes: number;
        byPlatform: Array<{
            platform: string;
            lastChecked: number;
            foundSelectors: number;
            totalSelectors: number;
            brokenPurposes: string[];
        }>;
    };
    /** Record a captcha event. */
    recordCaptchaEvent(platform: string, captchaType: string, captchaSource: string, taskId?: string, userId?: string, pageUrl?: string, screenshot?: string): number;
    /** Get pending captcha events (awaiting manual intervention). */
    getPendingCaptchaEvents(limit?: number): Array<{
        id: number;
        platform: string;
        taskId: string | null;
        userId: string;
        captchaType: string;
        captchaSource: string;
        pageUrl: string | null;
        screenshot: string | null;
        createdAt: number;
    }>;
    /** Get recent captcha events. */
    getCaptchaEvents(limit?: number, platform?: string, status?: string): Array<{
        id: number;
        platform: string;
        taskId: string | null;
        captchaType: string;
        captchaSource: string;
        status: string;
        resolvedBy: string | null;
        resolvedAt: number | null;
        createdAt: number;
    }>;
    /** Resolve a captcha event. */
    resolveCaptchaEvent(eventId: number, resolvedBy?: string): boolean;
    /** Get captcha statistics. */
    getCaptchaStats(): {
        total: number;
        pending: number;
        resolved: number;
        expired: number;
        byPlatform: Array<{
            platform: string;
            total: number;
            pending: number;
            resolved: number;
        }>;
        byType: Array<{
            captchaType: string;
            total: number;
        }>;
    };
}
//# sourceMappingURL=selector-repository.d.ts.map