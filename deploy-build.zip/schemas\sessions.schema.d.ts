import type { DB } from '../db.js';
export declare function initSessionsTable(db: DB, currentVersion: number): void;
//# sourceMappingURL=sessions.schema.d.ts.map