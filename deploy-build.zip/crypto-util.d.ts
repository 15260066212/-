/** Encrypt a plaintext string using AES-256-GCM. Returns "enc:iv:ciphertext:tag" in base64. */
export declare function encrypt(plaintext: string): string;
/** Decrypt an encrypted string. Falls back to plaintext if not encrypted (backward compat). */
export declare function decrypt(data: string): string;
/** Encrypt a JSON-serializable object. Returns encrypted string. */
export declare function encryptJSON(obj: unknown): string;
/** Decrypt an encrypted JSON string and parse it back to an object. */
export declare function decryptJSON<T>(encrypted: string): T;
//# sourceMappingURL=crypto-util.d.ts.map