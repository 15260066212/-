import type { DB } from '../db.js';
import type { User } from '../db.js';
export declare class UserRepository {
    private db;
    constructor(db: DB);
    insertUser(user: User): void;
    getUserByUsername(username: string): User | undefined;
    getUserByApiKey(apiKey: string): User | undefined;
    getUserById(id: string): User | undefined;
    updateUserLastActive(id: string): void;
    listUsers(): User[];
    deleteUser(id: string): void;
    /** Regenerate the API key for a user. Returns the updated user or undefined if not found. */
    regenerateUserApiKey(id: string): User | undefined;
    private mapUser;
}
//# sourceMappingURL=user-repository.d.ts.map