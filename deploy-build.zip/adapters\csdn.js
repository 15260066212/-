import { PlatformAdapter } from './base.js';
export class CsdnAdapter extends PlatformAdapter {
    constructor() {
        super('csdn');
    }
    getMethod() {
        return 'rpa';
    }
    async publish(_params) {
        return {
            success: true,
            postId: 'mock_post_id',
            postUrl: 'https://example.com',
        };
    }
}
//# sourceMappingURL=csdn.js.map