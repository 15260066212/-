import type { DB } from '../db.js';
/** Default maximum retry count for publish tasks */
export declare const DEFAULT_MAX_PUBLISH_RETRIES = 2;
export declare function initPublishTables(db: DB, currentVersion: number): void;
//# sourceMappingURL=publish.schema.d.ts.map