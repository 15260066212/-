/**
 * CachedDatabaseAccess — wraps DatabaseAccess with an LRU cache layer.
 *
 * Read operations check the cache first; on miss, they delegate to the
 * underlying DatabaseAccess and store the result. Write operations
 * invalidate related cache entries after successfully writing to the DB.
 *
 * Cache TTLs:
 *   - getArticle:           60s   (article:{id})
 *   - getArticlesBySession: 30s   (articles:session:{sessionId})
 *   - getPublishTask:       30s   (task:{id})
 *   - getCredential:       120s   (cred:{platform})
 *   - getSession:           30s   (session:{id})
 *   - healthCheck:          10s   (health)
 *   - getQueueStatus:       10s   (queue:status)
 */
import { DatabaseAccess, createDatabase } from './db.js';
import { LRUCache } from './cache.js';
// TTL constants (ms)
const TTL_ARTICLE = 60_000;
const TTL_ARTICLES_SESSION = 30_000;
const TTL_TASK = 30_000;
const TTL_CREDENTIAL = 120_000;
const TTL_SESSION = 30_000;
const TTL_HEALTH = 10_000;
const TTL_QUEUE = 10_000;
export class CachedDatabaseAccess extends DatabaseAccess {
    cache;
    constructor(db) {
        super(db);
        this.cache = new LRUCache({
            maxEntries: 200,
            defaultTtlMs: 60_000,
        });
    }
    /** Create a CachedDatabaseAccess with a fresh database connection. */
    static create() {
        return new CachedDatabaseAccess(createDatabase());
    }
    /** Expose the underlying cache for stats and management. */
    getCache() {
        return this.cache;
    }
    // === Cached read methods ===
    getArticle(id) {
        const cacheKey = `article:${id}`;
        const cached = this.cache.get(cacheKey);
        if (cached !== undefined) {
            return cached;
        }
        const result = this.articles.getArticle(id);
        if (result) {
            this.cache.set(cacheKey, result, TTL_ARTICLE);
        }
        return result;
    }
    getArticlesBySession(sessionId) {
        const cacheKey = `articles:session:${sessionId}`;
        const cached = this.cache.get(cacheKey);
        if (cached !== undefined) {
            return cached;
        }
        const result = this.articles.getArticlesBySession(sessionId);
        this.cache.set(cacheKey, result, TTL_ARTICLES_SESSION);
        return result;
    }
    getPublishTask(id) {
        const cacheKey = `task:${id}`;
        const cached = this.cache.get(cacheKey);
        if (cached !== undefined) {
            return cached;
        }
        const result = this.publish.getPublishTask(id);
        if (result) {
            this.cache.set(cacheKey, result, TTL_TASK);
        }
        return result;
    }
    getCredential(platform, userId = 'user_default', accountId = 'default') {
        const cacheKey = `cred:${userId}:${platform}:${accountId}`;
        const cached = this.cache.get(cacheKey);
        if (cached !== undefined) {
            return cached;
        }
        const result = this.credentials.getCredential(platform, userId, accountId);
        if (result) {
            this.cache.set(cacheKey, result, TTL_CREDENTIAL);
        }
        return result;
    }
    getSession(id) {
        const cacheKey = `session:${id}`;
        const cached = this.cache.get(cacheKey);
        if (cached !== undefined) {
            return cached;
        }
        const result = this.sessions.getSession(id);
        if (result) {
            this.cache.set(cacheKey, result, TTL_SESSION);
        }
        return result;
    }
    healthCheck() {
        const cacheKey = 'health';
        const cached = this.cache.get(cacheKey);
        if (cached !== undefined) {
            return cached;
        }
        const result = super.healthCheck();
        this.cache.set(cacheKey, result, TTL_HEALTH);
        return result;
    }
    getQueueStatus() {
        const cacheKey = 'queue:status';
        const cached = this.cache.get(cacheKey);
        if (cached !== undefined) {
            return cached;
        }
        const result = this.publish.getQueueStatus();
        this.cache.set(cacheKey, result, TTL_QUEUE);
        return result;
    }
    getLatestReview(articleId) {
        const cacheKey = `review:latest:${articleId}`;
        const cached = this.cache.get(cacheKey);
        if (cached !== undefined) {
            return cached;
        }
        const result = this.reviews.getLatestReview(articleId);
        if (result) {
            this.cache.set(cacheKey, result, 30_000);
        }
        return result;
    }
    getReviewsByArticle(articleId) {
        const cacheKey = `reviews:${articleId}`;
        const cached = this.cache.get(cacheKey);
        if (cached !== undefined) {
            return cached;
        }
        const result = this.reviews.getReviewsByArticle(articleId);
        this.cache.set(cacheKey, result, 30_000);
        return result;
    }
    // === Write methods with cache invalidation ===
    insertArticle(article) {
        this.articles.insertArticle(article);
        this.cache.invalidatePattern(`articles:session:${article.sessionId}`);
    }
    updateArticle(id, updates) {
        this.articles.updateArticle(id, updates);
        this.cache.delete(`article:${id}`);
        // Invalidate session article list if we can determine the session
        const article = this.articles.getArticle(id);
        if (article) {
            this.cache.invalidatePattern(`articles:session:${article.sessionId}`);
        }
        this.cache.delete(`review:latest:${id}`);
        this.cache.delete(`reviews:${id}`);
    }
    insertPublishTask(task) {
        this.publish.insertPublishTask(task);
        this.cache.delete('queue:status');
    }
    updatePublishTask(id, updates) {
        this.publish.updatePublishTask(id, updates);
        this.cache.delete(`task:${id}`);
        this.cache.delete('queue:status');
        this.cache.delete('health');
    }
    upsertCredential(platform, cred, userId = 'user_default') {
        this.credentials.upsertCredential(platform, cred, userId);
        const accountId = cred.accountId || 'default';
        this.cache.delete(`cred:${userId}:${platform}:${accountId}`);
        this.cache.delete('cred:all');
        this.cache.delete('health');
    }
    deleteCredential(platform, userId = 'user_default', accountId = 'default') {
        this.credentials.deleteCredential(platform, userId, accountId);
        this.cache.delete(`cred:${userId}:${platform}:${accountId}`);
        this.cache.delete('cred:all');
        this.cache.delete('health');
    }
    upsertSession(id, data, userId) {
        this.sessions.upsertSession(id, data, userId);
        this.cache.delete(`session:${id}`);
    }
    deleteSessionCascade(sessionId) {
        // Get article IDs before deletion to invalidate their caches
        const articles = this.articles.getArticlesBySession(sessionId);
        this.sessions.deleteSessionCascade(sessionId);
        // Invalidate all related caches
        this.cache.delete(`session:${sessionId}`);
        this.cache.invalidatePattern(`articles:session:${sessionId}`);
        for (const article of articles) {
            this.cache.delete(`article:${article.id}`);
            this.cache.delete(`review:latest:${article.id}`);
            this.cache.delete(`reviews:${article.id}`);
            // Invalidate task caches for this article
            const tasks = this.publish.getPublishTasksByArticle(article.id);
            for (const task of tasks) {
                this.cache.delete(`task:${task.id}`);
            }
        }
        this.cache.delete('queue:status');
        this.cache.delete('health');
    }
    insertReview(review) {
        const id = this.reviews.insertReview(review);
        this.cache.delete(`review:latest:${review.articleId}`);
        this.cache.delete(`reviews:${review.articleId}`);
        return id;
    }
    insertPublishLog(log) {
        this.publish.insertPublishLog(log);
        // Logs don't affect cached reads, no invalidation needed
    }
    // === Transaction support ===
    runInTransaction(fn) {
        // Execute the transaction, then clear the cache to ensure consistency.
        // We can't know what was modified inside the transaction, so be safe.
        const result = super.runInTransaction(fn);
        // Don't clear everything — just invalidate health and queue which are
        // commonly affected by transactional writes.
        this.cache.delete('health');
        this.cache.delete('queue:status');
        return result;
    }
}
//# sourceMappingURL=cached-db.js.map