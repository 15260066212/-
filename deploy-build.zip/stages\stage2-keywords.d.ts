import type { StageHandler } from '../types.js';
export declare const keywordsStage: StageHandler;
//# sourceMappingURL=stage2-keywords.d.ts.map