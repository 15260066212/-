import type { ValidationResult } from './types.js';
export declare function required(input: string): ValidationResult;
export declare function minLength(min: number): (input: string) => ValidationResult;
export declare function maxLength(max: number): (input: string) => ValidationResult;
export declare function isUrl(input: string): ValidationResult;
export declare function combine(...validators: Array<(input: string) => ValidationResult>): (input: string) => ValidationResult;
//# sourceMappingURL=validators.d.ts.map