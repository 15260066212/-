export { generateManual, generateManualHtml } from './renderer.js';
//# sourceMappingURL=index.js.map