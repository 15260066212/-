/**
 * @zemingengine/shared — 共享类型、常量、工具函数和数据库 schema。
 *
 * 此文件为向后兼容的总入口，所有导出名称保持不变。
 * 推荐使用子路径导入以获得更好的 tree-shaking：
 *   import { PlatformId } from '@zemingengine/shared/types'
 *   import { API_BASE_URL } from '@zemingengine/shared/constants'
 *   import { resolveStorageState } from '@zemingengine/shared/utils'
 *   import { initSessionTables } from '@zemingengine/shared/db'
 */
// === Types (按领域组织) ===
export { STAGES, LEGACY_STAGES, createEmptySession, DEFAULT_REVIEW_WEIGHTS, } from './types/index.js';
// === Constants ===
export { API_BASE_URL, SESSION_STORAGE_KEY, STAGE_DISPLAY_NAMES, STAGE_DESCRIPTIONS, PLATFORM_NAMES, PLATFORM_LABELS, PLATFORM_URLS, 
// Platform registry
PLATFORM_REGISTRY, getPlatformInfo, getPlatformInfoBySessionName, getPlatformInfoByHarvesterName, getHarvesterPlatformName, getSessionPlatformName, getPlatformLabel, getPlatformEditorUrl, getPlatformLLMWikiName, getPlatformDomains, getPlatformAuthCookieNames, getPlatformCapabilities, isApiPlatform, isRpaPlatform, listAllPlatforms, listApiPlatforms, listRpaPlatforms, } from './constants/index.js';
// === Utils ===
export { cookieStringToStorageState, storageStateToCookieString, resolveStorageState, mergeRefreshedCookies, hasFullStorageState, filterCookiesByDomain, isLoginRedirectUrl, } from './utils/index.js';
// === DB ===
export { initSessionTables } from './db/index.js';
//# sourceMappingURL=index.js.map