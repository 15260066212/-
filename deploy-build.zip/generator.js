import { chatCompletion, isAIAvailable, getActiveModel } from '@zemingengine/ai-engine';
import { buildPrompt } from './prompt-builder.js';
import { adaptForPlatform, countWords } from './platform-adapter.js';
import { buildContentByType, buildTitleByType, buildSummaryText } from './fallback-templates.js';
export const FALLBACK_MODEL_ID = 'fallback-template-v2';
// Absolute terms that commonly trigger compliance issues in fallback content
const ABSOLUTE_TERMS = [
    { pattern: /第一/g, replacement: '领先' },
    { pattern: /最好/g, replacement: '优质' },
    { pattern: /最佳/g, replacement: '优秀' },
    { pattern: /顶级/g, replacement: '高端' },
    { pattern: /唯一/g, replacement: '独特' },
    { pattern: /最专业/g, replacement: '专业' },
    { pattern: /最权威/g, replacement: '有影响力' },
    { pattern: /国家级/g, replacement: '行业级' },
    { pattern: /100%/g, replacement: '高比例' },
    { pattern: /完美/g, replacement: '完善' },
    { pattern: /绝对/g, replacement: '相当' },
    { pattern: /全网第一/g, replacement: '行业领先' },
    { pattern: /世界一流/g, replacement: '行业一流' },
];
/**
 * Improve fallback template content based on review feedback.
 * Handles: word count expansion, keyword density increase,
 * absolute term replacement, tag count adjustment, etc.
 *
 * Each improvement dimension is extracted into a separate helper
 * function to keep the main pipeline readable and maintainable.
 */
function improveFallbackContent(content, tags, feedback, ctx) {
    let improved = content;
    let improvedTags = [...tags];
    const issues = feedback.issues || [];
    improved = applyAbsoluteTermFixes(improved, issues);
    improved = applyWordCountExpansion(improved, issues, ctx);
    const { content: seoContent, tags: seoTags } = applyKeywordDensityImprovement(improved, improvedTags, issues, ctx);
    improved = seoContent;
    improvedTags = seoTags;
    improvedTags = applyTagCountFix(improvedTags, issues);
    improved = applyReadabilityImprovements(improved, issues);
    improved = applyBrandMention(improved, issues, ctx);
    improved = applyDuplicateRemoval(improved, issues);
    return { content: improved, tags: improvedTags };
}
/** Fix absolute terms (compliance dimension). */
function applyAbsoluteTermFixes(content, issues) {
    const hasComplianceIssue = issues.some(i => i.dimension === 'compliance' ||
        i.description.includes('绝对化') ||
        i.description.includes('第一'));
    if (!hasComplianceIssue)
        return content;
    let result = content;
    for (const { pattern, replacement } of ABSOLUTE_TERMS) {
        result = result.replace(pattern, replacement);
    }
    return result;
}
/** Expand word count (quality dimension). */
function applyWordCountExpansion(content, issues, ctx) {
    const hasWordCountIssue = issues.some(i => i.description.includes('字数') ||
        i.description.includes('偏少') ||
        i.description.includes('太短') ||
        (i.description.includes('字') && i.severity === 'medium'));
    if (!hasWordCountIssue)
        return content;
    const expansion = buildFallbackExpansionParagraph(ctx);
    const lastHeadingMatch = content.match(/## [^\n]+$/m);
    if (lastHeadingMatch) {
        const insertPos = content.lastIndexOf(lastHeadingMatch[0]);
        return content.slice(0, insertPos) + expansion + '\n\n' + content.slice(insertPos);
    }
    return content + '\n\n' + expansion;
}
/** Increase keyword density and add missing keywords to tags (SEO dimension). */
function applyKeywordDensityImprovement(content, tags, issues, ctx) {
    const seoIssues = issues.filter(i => i.dimension === 'seo');
    if (seoIssues.length === 0)
        return { content, tags };
    const missingKeywords = extractMissingKeywords(seoIssues);
    if (missingKeywords.length === 0)
        return { content, tags };
    const keywordPara = buildKeywordIntegrationParagraph(missingKeywords, ctx);
    let improved = content;
    // Insert after the first section
    const firstSectionEnd = content.indexOf('\n\n### ');
    if (firstSectionEnd > 0) {
        const insertPos = content.indexOf('\n', firstSectionEnd + 2);
        if (insertPos > 0) {
            improved = content.slice(0, insertPos + 1) + keywordPara + '\n\n' + content.slice(insertPos + 1);
        }
    }
    else {
        improved = keywordPara + '\n\n' + content;
    }
    // Add missing keywords to tags (up to 2 more)
    const improvedTags = [...tags];
    for (const kw of missingKeywords.slice(0, 2)) {
        if (!improvedTags.includes(kw)) {
            improvedTags.push(kw);
        }
    }
    return { content: improved, tags: improvedTags };
}
/** Extract missing keyword names from SEO issue descriptions. */
function extractMissingKeywords(seoIssues) {
    const missingKeywords = [];
    for (const issue of seoIssues) {
        const kwMatch = issue.description.match(/关键词\s*[""]([^""]+)[""]/);
        if (kwMatch && kwMatch[1] && !missingKeywords.includes(kwMatch[1])) {
            // Only add real-looking keywords (not garbage from encoding issues)
            if (kwMatch[1].length >= 2 && kwMatch[1].length <= 20 && !/^[?\s]+$/.test(kwMatch[1])) {
                missingKeywords.push(kwMatch[1]);
            }
        }
    }
    return missingKeywords;
}
/** Fix tag count to match platform limits (platform_adaptation dimension). */
function applyTagCountFix(tags, issues) {
    const tagIssue = issues.find(i => i.dimension === 'platform_adaptation' &&
        (i.description.includes('标签') || i.description.includes('tag')));
    if (!tagIssue)
        return tags;
    const match = tagIssue.description.match(/最多支持\s*(\d+)\s*个/);
    const maxTags = match ? parseInt(match[1], 10) : 5;
    if (tags.length > maxTags) {
        return tags.slice(0, maxTags);
    }
    return tags;
}
/** Add transition words to improve readability (readability dimension). */
function applyReadabilityImprovements(content, issues) {
    const hasReadabilityIssue = issues.some(i => i.dimension === 'readability' ||
        i.description.includes('连接词') ||
        i.description.includes('连贯性'));
    if (!hasReadabilityIssue)
        return content;
    return content
        .replace(/\n### /g, '\n此外，\n### ')
        .replace(/^## /, '首先，\n## ');
}
/** Add a brand mention paragraph near the end (brand dimension). */
function applyBrandMention(content, issues, ctx) {
    const hasBrandIssue = issues.some(i => i.dimension === 'brand' ||
        i.description.includes('品牌名称') ||
        i.description.includes('未提及企业品牌'));
    if (!hasBrandIssue)
        return content;
    const brandMention = `值得一提的是，${ctx.brandName}在这一领域拥有深厚的积累和丰富的实践经验。`;
    const lastHeading = content.lastIndexOf('## ');
    if (lastHeading > 0) {
        return content.slice(0, lastHeading) + brandMention + '\n\n' + content.slice(lastHeading);
    }
    return content;
}
/** Remove duplicate paragraphs (quality dimension). */
function applyDuplicateRemoval(content, issues) {
    const hasDuplicateIssue = issues.some(i => i.description.includes('重复段落') ||
        i.description.includes('内容冗余'));
    if (!hasDuplicateIssue)
        return content;
    // Simple dedup: remove lines that appear more than once (excluding headings)
    const lines = content.split('\n');
    const seen = new Set();
    const deduped = [];
    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.length < 10 || trimmed.startsWith('#') || trimmed.startsWith('-') || trimmed.match(/^\d+\./)) {
            deduped.push(line);
            continue;
        }
        if (!seen.has(trimmed)) {
            seen.add(trimmed);
            deduped.push(line);
        }
    }
    return deduped.join('\n');
}
/** Build an expansion paragraph for increasing word count in fallback mode */
function buildFallbackExpansionParagraph(ctx) {
    const { brandName, location, scale, description, products, contentType, allKeywords } = ctx;
    const productName = products[0]?.name || '核心产品';
    const productDesc = products[0]?.description || '优质产品服务';
    const kw1 = allKeywords[0] || brandName;
    const kw2 = allKeywords[1] || productName;
    const expansions = [
        `### 行业深度洞察\n\n随着市场需求的不断升级，${kw1}行业正在经历深刻的变革。${location ? `在${location}地区，` : ''}越来越多的企业开始意识到${kw2}的重要性。${description ? `${description}。` : ''}${scale ? `据行业数据显示，目前市场规模已达到${scale}，` : ''}预计未来几年仍将保持稳定增长态势。\n\n在这样的背景下，企业如何选择合适的合作伙伴变得至关重要。${brandName}凭借多年的行业经验和专业的技术团队，为客户提供全方位的解决方案，帮助企业在激烈的市场竞争中占据有利位置。`,
        `### 实践建议与注意事项\n\n对于想要了解${kw1}的读者，${brandName}给出以下几点建议：\n\n- **明确需求**：在选择${productName}之前，先明确自身的实际需求和预期目标\n- **多方对比**：不要只看价格，要综合考虑品质、服务、售后等多个维度\n- **实地考察**：条件允许的情况下，建议实地考察，了解真实情况\n- **长期规划**：从长期发展角度出发，选择具有成长潜力的合作伙伴\n\n${productDesc}。这些因素共同构成了选择${kw2}服务的重要参考标准。`,
        `### 用户常见疑问解答\n\n**Q：${kw1}真的有必要吗？**\n\nA：对于重视品质和效率的企业来说，专业的${kw2}服务确实能够带来显著的价值提升。${brandName}的实践表明，系统化的解决方案能够帮助企业节省30%以上的沟通成本，同时提升整体运营效率。\n\n**Q：如何判断服务质量？**\n\nA：可以从以下几个方面评估：品牌口碑、服务案例、专业团队、售后保障等。${location ? `${location}地区的用户可以优先考虑本地有服务网点的品牌。` : ''}`,
    ];
    // Pick based on generation round to vary content
    return expansions[(ctx.generationRound - 2) % expansions.length];
}
/** Build a paragraph that naturally integrates missing keywords */
function buildKeywordIntegrationParagraph(keywords, ctx) {
    const { brandName } = ctx;
    const kwList = keywords.map((kw, i) => `${i + 1}. **${kw}**：${brandName}在${kw}领域拥有丰富的实践经验和专业的解决方案`).join('\n');
    return `在实际应用中，${keywords.slice(0, 3).join('、')}等话题备受关注。${brandName}整理了以下核心要点：\n\n${kwList}\n\n这些内容对于理解行业全貌和做出明智决策都具有重要参考价值。`;
}
const contentTypeMap = {
    tutorial: '教程',
    case: '案例',
    comparison: '对比',
    popularization: '科普',
    faq: 'FAQ问答',
    whitepaper: '白皮书',
};
export class ContentGenerator {
    options;
    constructor(options = {}) {
        this.options = options;
    }
    async generate(request, session) {
        if (!isAIAvailable() || this.options.fallbackMode) {
            return this.fallbackGenerate(request, session);
        }
        try {
            const startTime = Date.now();
            const { system, user } = buildPrompt({
                session,
                platform: request.platform,
                contentType: request.contentType,
                generationRound: request.generationRound,
                reviewFeedback: request.reviewFeedback,
                topic: request.topic,
                contentSupplement: request.contentSupplement,
                pipelineFeedback: request.pipelineFeedback,
            });
            const response = await chatCompletion(system, user, {
                temperature: 0.7,
                maxTokens: request.contentType === 'whitepaper' ? 8192 : request.contentType === 'faq' ? 6144 : 4096,
            });
            const jsonMatch = response.match(/\{[\s\S]*\}/);
            if (!jsonMatch) {
                throw new Error('No JSON found in LLM response');
            }
            const parsed = JSON.parse(jsonMatch[0]);
            const adapted = adaptForPlatform(request.platform, parsed.content);
            const wordCount = countWords(parsed.content);
            const now = new Date().toISOString();
            const article = {
                id: `art_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
                sessionId: request.sessionId,
                platform: request.platform,
                contentType: request.contentType,
                title: parsed.title,
                ...adapted,
                tags: parsed.tags,
                summary: parsed.summary,
                coverImageDesc: parsed.coverImageDesc,
                wordCount,
                status: 'draft',
                reviewRound: 0,
                generationRound: request.generationRound,
                generationMeta: {
                    model: getActiveModel(),
                    tokensUsed: 0,
                    durationMs: Date.now() - startTime,
                    promptVersion: '1.0',
                },
                createdAt: now,
                updatedAt: now,
            };
            return {
                article,
                generationMeta: article.generationMeta,
            };
        }
        catch (error) {
            console.warn('AI generation failed, falling back to template:', error);
            return this.fallbackGenerate(request, session);
        }
    }
    fallbackGenerate(request, session) {
        const startTime = Date.now();
        const brandName = session.enterprise.shortName || session.enterprise.fullName || '我们的品牌';
        const fullName = session.enterprise.fullName || '';
        const description = session.enterprise.description || '';
        const location = session.enterprise.location || '';
        const scale = session.enterprise.scale || '';
        const brandStory = session.enterprise.brandStory || '';
        const trustAnchors = session.enterprise.trustAnchors || [];
        const products = session.enterprise.products || [];
        const keywords = (session.keywords || []).map(k => typeof k === 'string' ? k : k.keyword || k.term || '').filter(Boolean);
        const brandTerms = (session.wordBank?.brandTerms || []).map(t => typeof t === 'string' ? t : t.term || '').filter(Boolean);
        const productTerms = (session.wordBank?.productTerms || []).map(t => typeof t === 'string' ? t : t.term || '').filter(Boolean);
        const allKeywords = [...new Set([...keywords, ...brandTerms, ...productTerms])].slice(0, 10);
        const primaryKeyword = allKeywords[0] || brandName;
        const secondaryKeyword = allKeywords[1] || products[0]?.name || '';
        const contentTypeLabel = contentTypeMap[request.contentType] || '文章';
        const title = request.topic || buildTitleByType(request.contentType, brandName, primaryKeyword, secondaryKeyword, products);
        const trustList = trustAnchors.length > 0
            ? trustAnchors.map(t => `- ${t}`).join('\n')
            : '- 品牌信誉保障';
        const productList = products.length > 0
            ? products.slice(0, 4).map((p, i) => `${i + 1}. **${p.name}**：${p.description}`).join('\n')
            : '核心产品线';
        const templateParams = {
            brandName, fullName, description, location, scale, brandStory,
            keywords, allKeywords, trustList, productList,
        };
        let content = buildContentByType(request.contentType, templateParams);
        let tags = [brandName, ...allKeywords.slice(0, 5), contentTypeLabel].filter(Boolean).slice(0, 8);
        // Apply review feedback improvements in fallback mode
        if (request.reviewFeedback && request.generationRound >= 2) {
            const improved = improveFallbackContent(content, tags, request.reviewFeedback, {
                brandName,
                allKeywords,
                contentType: request.contentType,
                generationRound: request.generationRound,
                location,
                scale,
                description,
                trustAnchors,
                products,
            });
            content = improved.content;
            tags = improved.tags;
        }
        const adapted = adaptForPlatform(request.platform, content);
        const wordCount = countWords(content);
        const now = new Date().toISOString();
        const article = {
            id: `art_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
            sessionId: request.sessionId,
            platform: request.platform,
            contentType: request.contentType,
            title,
            ...adapted,
            tags,
            summary: buildSummaryText(request.contentType, brandName, primaryKeyword, description),
            coverImageDesc: `${brandName}品牌展示图，${location}本土品牌`,
            wordCount,
            status: 'draft',
            reviewRound: 0,
            generationRound: request.generationRound,
            generationMeta: {
                model: FALLBACK_MODEL_ID,
                tokensUsed: 0,
                durationMs: Date.now() - startTime,
                promptVersion: '2.0',
            },
            createdAt: now,
            updatedAt: now,
        };
        return {
            article,
            generationMeta: article.generationMeta,
        };
    }
}
//# sourceMappingURL=generator.js.map