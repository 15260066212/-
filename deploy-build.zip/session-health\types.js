export const DEFAULT_CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000; // 6 hours
export const CHECK_BATCH_SIZE = 3; // Max 3 concurrent checks per batch
export const MAX_CONSECUTIVE_FAILURES = 3; // Mark expired after 3 consecutive failures
//# sourceMappingURL=types.js.map