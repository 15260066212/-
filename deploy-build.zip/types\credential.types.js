/**
 * Credential-related type definitions.
 */
export {};
//# sourceMappingURL=credential.types.js.map