/**
 * Platform-related derived constants (names, labels, URLs).
 *
 * These are computed from the unified platform registry for single-source-of-truth.
 */
import type { PlatformId } from '../types/platform.types.js';
/**
 * Chinese display names for publishing platforms.
 * Derived from the unified platform registry for single-source-of-truth.
 */
export declare const PLATFORM_NAMES: Record<string, string>;
/** Chinese display labels for all platforms (publishing + AI monitoring). */
export declare const PLATFORM_LABELS: Record<string, string>;
/**
 * Editor/publish page URLs for each RPA-supported platform.
 * Derived from the unified platform registry for single-source-of-truth.
 * Both rpa-handlers and session-health selector-registry reference this map.
 */
export declare const PLATFORM_URLS: Partial<Record<PlatformId, string>>;
//# sourceMappingURL=platform-constants.d.ts.map