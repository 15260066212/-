import type { SessionData, DialogueMessage, Stage } from '@zemingengine/shared';
export declare class DialogueEngine {
    private session;
    private currentQuestionId;
    constructor(session: SessionData);
    private initQuestionId;
    getSession(): SessionData;
    setSession(session: SessionData): void;
    getCurrentStage(): Stage;
    getCurrentQuestionId(): string | null;
    setCurrentQuestionId(questionId: string | null): void;
    getProgress(): {
        current: number;
        total: number;
    };
    getIntroMessage(): DialogueMessage;
    handleUserInput(input: string): Promise<{
        messages: DialogueMessage[];
        isComplete: boolean;
    }>;
    getStageHandlers(): import("./types.js").StageHandler[];
}
//# sourceMappingURL=state-machine.d.ts.map