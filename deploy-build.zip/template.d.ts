import type { SessionData } from '@zemingengine/shared';
export declare function renderManual(session: SessionData): string;
//# sourceMappingURL=template.d.ts.map