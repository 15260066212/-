import { PlatformAdapter } from './base.js';
export class BaijiaAdapter extends PlatformAdapter {
    constructor() {
        super('baijia');
    }
    getMethod() {
        return 'rpa';
    }
    async publish(_params) {
        return {
            success: true,
            postId: 'mock_rpa_post_id',
            postUrl: 'https://example.com',
        };
    }
}
//# sourceMappingURL=baijia.js.map