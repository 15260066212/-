import { Publisher } from '@zemingengine/publisher';
import type { DatabaseAccess } from './db.js';
import { SessionHealthChecker } from './session-health/index.js';
/**
 * Recover tasks that were interrupted by a server restart.
 *
 * 1. Tasks stuck in 'publishing' status for more than 5 minutes are marked as
 *    'failed' — the server restart interrupted their execution.
 * 2. Tasks in 'retrying' status are reset to 'pending' so the scheduler can
 *    reprocess them on the next poll.
 */
export declare function recoverStaleTasks(db: DatabaseAccess): void;
export declare function startHealthChecker(checker: SessionHealthChecker): void;
export declare function startCookieWarmer(db: DatabaseAccess): void;
export declare function stopCookieWarmer(): void;
export declare function stopHealthChecker(): void;
/**
 * Start the scheduled-publish scheduler.
 *
 * Polls the database every 30 seconds for publish tasks that are in the
 * `pending` or `retrying` state and have a `scheduledAt` time which has
 * arrived. When a task is due it is atomically transitioned to `publishing`
 * (to prevent duplicate execution) and then published asynchronously.
 *
 * Concurrency control:
 * - Global: at most MAX_CONCURRENT tasks executing simultaneously.
 * - Per-platform: at most 1 task per platform at a time, with a 60-second
 *   cooldown between publishes to the same platform (rate-limit protection).
 *
 * Before the first poll, `recoverStaleTasks()` is called to clean up any
 * tasks that were interrupted by a previous server restart.
 *
 * @returns a NodeJS.Timeout handle that can be passed to `clearInterval()`
 *          to stop the scheduler.
 */
export declare function startScheduler(db: DatabaseAccess, publisher: Publisher): NodeJS.Timeout;
/**
 * Start a periodic cache cleanup timer.
 *
 * Every 5 minutes, calls `cache.cleanup()` on the CachedDatabaseAccess
 * instance to remove expired entries from the LRU cache. This prevents
 * stale entries from consuming memory.
 *
 * @returns a NodeJS.Timeout handle that can be passed to `clearInterval()`.
 */
export declare function startCacheCleanup(db: DatabaseAccess): NodeJS.Timeout;
export declare function startPlanTaskScheduler(db: DatabaseAccess, executeTaskFn: (task: any) => Promise<void>): void;
export declare function stopPlanScheduler(): void;
//# sourceMappingURL=scheduler.d.ts.map