import type { PlatformCredentials } from '@zemingengine/shared';
import { BaseValidator } from './base.js';
import type { ValidationResult } from '../types.js';
export declare class WechatValidator extends BaseValidator {
    readonly platform: "weixin";
    validate(credentials: PlatformCredentials): Promise<ValidationResult>;
}
//# sourceMappingURL=wechat.d.ts.map