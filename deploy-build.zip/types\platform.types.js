/**
 * Platform-related type definitions.
 */
export {};
//# sourceMappingURL=platform.types.js.map