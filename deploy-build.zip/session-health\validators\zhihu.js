import { HarvesterBrowserValidator } from './harvester-browser.js';
export class ZhihuValidator extends HarvesterBrowserValidator {
    platform = 'zhihu';
}
//# sourceMappingURL=zhihu.js.map