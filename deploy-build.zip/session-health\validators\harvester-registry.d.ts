import type { PlatformId } from '@zemingengine/shared';
import { HarvesterBrowserValidator } from './harvester-browser.js';
/**
 * Configuration for a harvester-based platform validator.
 * When harvesterPlatform is omitted, the platform ID is used directly.
 */
export interface HarvesterPlatformConfig {
    platform: PlatformId;
    harvesterPlatform?: string;
}
/**
 * Registry of all RPA/harvester platform configurations.
 * Replaces the 10 previously empty Validator subclasses.
 */
export declare const HARVESTER_PLATFORMS: HarvesterPlatformConfig[];
/**
 * Factory function that creates HarvesterBrowserValidator instances
 * for all registered harvester platforms.
 */
export declare function createHarvesterValidators(): HarvesterBrowserValidator[];
//# sourceMappingURL=harvester-registry.d.ts.map