import { Hono } from 'hono';
import type { DatabaseAccess } from '../db.js';
export declare function createManualRoutes(db: DatabaseAccess): Hono;
//# sourceMappingURL=manual.d.ts.map