import { type Article, type PlatformCredentials, type PlatformId } from '@zemingengine/shared';
import type { PublishResult } from '../types.js';
/**
 * Remote RPA publisher that delegates publishing to a remote harvester service over HTTP.
 *
 * When RPA_REMOTE_URL is set, publish calls are delegated to the
 * harvester service instead of launching a local Playwright browser.
 * This is used in Docker deployments where the geo-app container
 * does not have Playwright browsers installed, but the harvester container does.
 */
export declare class RemotePublisher {
    /**
     * Whether remote RPA execution is enabled via the RPA_REMOTE_URL env var.
     */
    isRemoteMode(): boolean;
    /**
     * Delegate RPA publishing to the LLMWiki pipeline service over HTTP.
     * Calls POST /api/llmwiki/publish on the service specified by RPA_REMOTE_URL.
     */
    remotePublish(platform: PlatformId, article: Article, credentials: PlatformCredentials): Promise<PublishResult>;
}
//# sourceMappingURL=remote-publisher.d.ts.map