import { Hono } from 'hono';
import type { AppEnv, DatabaseAccess } from '../db.js';
export declare function createAuthRoutes(db: DatabaseAccess): Hono<AppEnv>;
//# sourceMappingURL=auth.d.ts.map