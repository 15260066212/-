import type { StageHandler } from '../types.js';
export declare const platformsStage: StageHandler;
//# sourceMappingURL=stage6-platforms.d.ts.map