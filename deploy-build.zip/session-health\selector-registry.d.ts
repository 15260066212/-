/**
 * Selector Registry — Centralized registry of all CSS selectors used in
 * RPA automation across 11 publishing platforms.
 *
 * Organized by platform and purpose (login, session check, publishing).
 * Each entry includes a fallback chain: if selector[0] fails, try selector[1], etc.
 *
 * The SelectorMonitor periodically validates these against live platform pages
 * to detect structural changes before they cause publish failures.
 */
export interface SelectorEntry {
    /** CSS selector string (Playwright format) */
    selector: string;
    /** What this selector targets */
    purpose: SelectorPurpose;
}
export type SelectorPurpose = 'login_username' | 'login_password' | 'login_submit' | 'login_switch_mode' | 'login_captcha' | 'session_check_element' | 'publish_title_input' | 'publish_content_editor' | 'publish_button' | 'publish_confirm_button' | 'publish_tag_input' | 'publish_category_select';
export interface PlatformSelectorSet {
    platform: string;
    /** Page to navigate to for validation (editor or publish page URL) */
    validateUrl: string;
    /** Login page URL (for login selectors) */
    loginUrl?: string;
    /** Success URL pattern after login */
    successUrlPattern?: string;
    /** Selectors grouped by purpose */
    selectors: SelectorEntry[];
}
export declare const SELECTOR_REGISTRY: PlatformSelectorSet[];
/** Get a platform's selector set by platform name. */
export declare function getPlatformSelectors(platform: string): PlatformSelectorSet | undefined;
//# sourceMappingURL=selector-registry.d.ts.map