import { Hono } from 'hono';
import type { AppEnv, DatabaseAccess } from '../db.js';
export declare function createImportRoutes(db: DatabaseAccess): Hono<AppEnv>;
//# sourceMappingURL=import.d.ts.map