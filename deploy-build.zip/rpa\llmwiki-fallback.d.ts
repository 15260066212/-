import type { Article, PlatformCredentials } from '@zemingengine/shared';
import type { PublishResult } from '../types.js';
/**
 * LLMWiki Fallback Publisher
 *
 * Provides LLMWiki-based self-healing fallback when regular RPA publishing fails.
 * This is a stub implementation — the full feature uses the LLMWiki platform
 * as an alternative publishing channel when the primary platform has issues.
 */
export declare class LLMWikiFallback {
    private enabled;
    constructor(enabled?: boolean);
    /**
     * Enable or disable the LLMWiki fallback at runtime.
     */
    setEnabled(enabled: boolean): void;
    /**
     * Check if LLMWiki fallback can be used for the given platform.
     * Returns true only when fallback is enabled AND the platform is supported.
     */
    canUseLLMWikiFallback(platform: string): boolean;
    /**
     * Attempt to publish via LLMWiki as a fallback channel.
     * Returns a PublishResult on success, or throws on failure.
     *
     * Note: This is a stub. The real implementation would:
     * 1. Acquire an LLMWiki browser session
     * 2. Publish the article through the LLMWiki interface
     * 3. Return the published URL and status
     */
    tryFallback(article: Article, credentials: PlatformCredentials, accountId: string): Promise<PublishResult>;
}
//# sourceMappingURL=llmwiki-fallback.d.ts.map