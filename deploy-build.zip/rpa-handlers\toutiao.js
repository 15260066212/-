import { SimpleRpaHandler } from './base.js';
/**
 * Toutiao (头条号) RPA handler - publishes articles via browser automation.
 * Requires cookie-based authentication (sessionid, ttwid, etc.)
 *
 * Publishing flow:
 * 1. Navigate to https://mp.toutiao.com/profile_v4/graphic/publish
 * 2. Fill in title
 * 3. Fill in content (ProseMirror editor)
 * 4. Set cover image (optional)
 * 5. Click publish button
 * 6. Handle confirmation dialog
 * 7. Extract the published article URL
 */
export class ToutiaoRpaHandler extends SimpleRpaHandler {
    cookieDomain = '.toutiao.com';
    loginUrlKeywords = ['login', 'sso', 'passport'];
    platformDisplayName = 'Toutiao';
    titleSelectors = [
        'input[placeholder*="请输入标题"]',
        'input[placeholder*="输入文章标题"]',
        'input[placeholder*="文章标题"]',
        'input[placeholder*="标题"]',
        'textarea[placeholder*="请输入标题"]',
        '.article-title input',
        '.title-input input',
        '.title-editor input',
        '[class*="title"] input',
        '[class*="title"] textarea',
    ];
    contentEditorSelectors = [
        '.ProseMirror',
        '.prose-editor',
        '.editor-content',
        '.content-editor',
        '.article-editor',
        '[class*="prose"]',
    ];
    enableTags = false; // Toutiao uses topics/categories differently
    publishButtonSelectors = [
        'button:has-text("发布")',
        '.publish-btn',
        '.btn-publish',
        'button[class*="publish"]',
        '.byte-btn--primary',
    ];
    hasConfirmDialog = true;
    confirmButtonSelectors = [
        'button:has-text("确认发布")',
        'button:has-text("确认")',
        '.btn-confirm',
        '.confirm-btn',
        '.dialog-footer .byte-btn--primary',
    ];
    postIdPatterns = [
        /toutiao\.com\/article\/(\d+)/,
        /toutiao\.com\/group\/(\d+)/,
        /article\/(\d{15,})/,
    ];
    constructor() {
        super('toutiao');
    }
    /**
     * Hook: Enter the editor. For Toutiao, we may need to:
     * - Close onboarding popups
     * - Wait for the ProseMirror editor to initialize
     */
    async enterEditor(page) {
        // Wait for editor frame to load
        try {
            await page.waitForSelector([
                ...this.titleSelectors,
                ...this.contentEditorSelectors,
            ].join(', '), {
                timeout: this.timeouts.EXTRA_LONG,
            });
        }
        catch {
            // Continue even if wait fails
        }
        // Close popups (welcome, guide, etc.)
        try {
            await page.evaluate(() => {
                const closeButtons = document.querySelectorAll('.close-btn, .close-icon, [class*="close"], .byte-drawer__close');
                Array.from(closeButtons).forEach((btn) => {
                    const rect = btn.getBoundingClientRect();
                    if (rect.width > 0 && rect.width < 60 && rect.height > 0) {
                        const text = btn.textContent?.trim() || '';
                        if (text === '×' ||
                            text === '关闭' ||
                            text === '跳过' ||
                            text === '我知道了') {
                            btn.click();
                        }
                    }
                });
            });
            await page.waitForTimeout(800);
        }
        catch {
            // Optional
        }
        return true;
    }
}
//# sourceMappingURL=toutiao.js.map