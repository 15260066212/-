import { HarvesterBrowserValidator } from './harvester-browser.js';
export declare class ZhihuValidator extends HarvesterBrowserValidator {
    readonly platform: "zhihu";
}
//# sourceMappingURL=zhihu.d.ts.map