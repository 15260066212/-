/**
 * Article and review-related type definitions.
 */
export const DEFAULT_REVIEW_WEIGHTS = {
    compliance: 0.20,
    quality: 0.15,
    seo: 0.15,
    brand: 0.15,
    originality: 0.10,
    platform_adaptation: 0.10,
    readability: 0.05,
    safety: 0.10,
};
//# sourceMappingURL=article.types.js.map