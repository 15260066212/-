import type { DB } from '../db.js';
export declare class PlanRepository {
    private db;
    constructor(db: DB);
    saveOptimizationPlan(plan: {
        id: string;
        sessionId: string;
        enterpriseName: string;
        duration: string;
        platforms: string[];
        contentTypes: string[];
        htmlContent: string;
        planArticles: any[];
        autoPublish: boolean;
        contentSupplement?: string;
    }): void;
    getOptimizationPlan(sessionId: string): any | null;
    updatePlanContentSupplement(planId: string, supplement: string): void;
    createScheduledPlanTasks(tasks: any[]): void;
    getScheduledPlanTasks(planId: string): any[];
    getDueScheduledTasks(): any[];
    updateScheduledTaskStatus(taskId: string, status: string, extra?: {
        articleId?: string;
        runId?: string;
        errorMessage?: string;
        executedAt?: string;
    }): void;
    getScheduledTasksBySession(sessionId: string): any[];
}
//# sourceMappingURL=plan-repository.d.ts.map