/**
 * Shared database schema initialization for sessions and fingerprints tables.
 *
 * Both `account-vault` and `session-pool` need the same `sessions` and
 * `fingerprints` table structures. This module centralizes the DDL so the
 * two packages never drift apart.
 */
/**
 * Minimal database interface for schema initialization.
 * Structurally compatible with better-sqlite3's `Database` (which exposes
 * `exec(sql: string): void`), so callers can pass their `Database.Database`
 * instance without the shared package needing a better-sqlite3 dependency.
 */
export interface SchemaDatabase {
    exec(sql: string): void;
}
/**
 * Initialize the shared `sessions` and `fingerprints` tables.
 *
 * Safe to call multiple times (uses `CREATE TABLE IF NOT EXISTS`).
 * Also runs idempotent column migrations for the `sessions` table
 * (`max_age`, `fingerprint_id`) — the `ALTER TABLE` errors are swallowed
 * when the column already exists.
 */
export declare function initSessionTables(db: SchemaDatabase): void;
//# sourceMappingURL=db-schema.d.ts.map