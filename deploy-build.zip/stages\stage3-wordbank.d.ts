import type { StageHandler } from '../types.js';
export declare const wordbankStage: StageHandler;
//# sourceMappingURL=stage3-wordbank.d.ts.map