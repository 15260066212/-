import { HarvesterBrowserValidator } from './harvester-browser.js';
export declare class CsdnValidator extends HarvesterBrowserValidator {
    readonly platform: "csdn";
}
//# sourceMappingURL=csdn.d.ts.map