export { generateManual, generateManualHtml } from './renderer.js';
export type { ManualOutput } from './renderer.js';
//# sourceMappingURL=index.d.ts.map