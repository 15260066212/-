import { Hono } from 'hono';
import type { DatabaseAccess } from '../db.js';
export declare function createArticleRoutes(db: DatabaseAccess): Hono;
//# sourceMappingURL=article.d.ts.map