interface Brand {
    name?: string;
    aliases?: string[];
    primary_keywords?: string[];
}
interface Competitor {
    name?: string;
    aliases?: string[];
}
interface SentimentResult {
    sentiment: 'positive' | 'neutral' | 'negative';
    reason: string;
    risk_terms: string[];
}
export declare class SentimentAnalysisService {
    buildAnalysisQuestion({ responseText, brand, competitors }: {
        responseText: string;
        brand: Brand;
        competitors: Competitor[];
    }): string;
    parseAnalysis(text: string): SentimentResult;
    normalizeSentiment(value: unknown): 'positive' | 'neutral' | 'negative';
    normalizeRiskTerms(value: unknown): string[];
    neutral(reason: string): SentimentResult;
    /** Strip provider/API names and collapse whitespace from a text value. */
    private stripSensitiveTerms;
    sanitizeReason(value: unknown): string;
    sanitizeRiskTerm(value: unknown): string;
    analyzeWithDeepSeek({ responseText, brand, competitors }: {
        responseText: string;
        brand: Brand;
        competitors: Competitor[];
    }): Promise<SentimentResult>;
}
export declare const sentimentAnalysisService: SentimentAnalysisService;
export {};
//# sourceMappingURL=sentiment-analysis-service.d.ts.map