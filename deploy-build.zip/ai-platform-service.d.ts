interface PlatformConfig {
    name: string;
    apiUrl: string;
    apiKey: string;
    headers: Record<string, string>;
}
/** Doubao Responses API web search filter configuration. */
interface DoubaoSearchFilter {
    time_range?: string;
    auth_info_level?: number;
    industry?: string;
}
/** Doubao Responses API web search tool configuration. */
interface DoubaoWebSearch {
    sources: string[];
    search_filter?: DoubaoSearchFilter;
    query_rewrite?: boolean;
}
/** Doubao Responses API request body. */
interface DoubaoRequestBody {
    model: string;
    input: {
        role: string;
        content: {
            type: string;
            text: string;
        }[];
    }[];
    temperature: number;
    max_output_tokens: number;
    service_tier?: string;
    tools?: {
        type: string;
        web_search: DoubaoWebSearch;
    }[];
}
/** Standard chat completion request body (DeepSeek/Qianwen/Kimi/Hunyuan/Default). */
interface ChatCompletionRequestBody {
    model: string;
    messages: {
        role: string;
        content: string;
    }[];
    temperature: number;
    max_tokens: number;
    search?: {
        enabled: boolean;
        depth: string;
    };
    enable_search?: boolean;
    use_search?: boolean;
    enable_enhancement?: boolean;
}
/** Union of all platform request body types. */
type RequestBody = DoubaoRequestBody | ChatCompletionRequestBody;
/** Raw JSON response from an AI platform API. */
type PlatformResponse = Record<string, unknown>;
interface QueryResult {
    success: boolean;
    data?: PlatformResponse;
    error?: string;
    platform: string;
    responseTime?: number;
}
export declare class AIPlatformService {
    platforms: Record<string, PlatformConfig>;
    constructor();
    getApiUrl(platform: string): string;
    getDoubaoResponsesModel(): string;
    /**
     * Whether to enable Doubao Web Search tool in Responses API.
     * Uses the "doubao" search source (Custom Edition) for higher quality results.
     * Default: true — Doubao Custom Edition search provides the best Chinese-language
     * source coverage for GEO monitoring (60-85% ByteDance ecosystem citations).
     * See: https://docs.volcengine.com/docs/82379/1756990
     */
    isDoubaoWebSearchEnabled(): boolean;
    /**
     * Time range for Doubao web search results (freshness control).
     * Doubao weights content from the last 1-2 weeks most heavily; citation rates
     * drop sharply after 1 month. Default: "1m" (1 month). Options: "1d","1w","1m","6m","1y".
     * See: https://www.volcengine.com/docs/87772/2272953
     */
    getDoubaoSearchTimeRange(): string;
    /**
     * Authority level filter for Doubao web search (source credibility grading).
     * L1=非常权威 (gov/央媒/985大学/500强/字节高质量)
     * L2=正常权威 (行业垂直站点/综合平台)
     * L3=一般权威 (普通网站)
     * L4=一般不权威 (内容农场/SEO灌水站)
     * Default: "2" (L1-L2 only) to filter out low-quality content farms.
     * See: https://www.volcengine.com/docs/87772/2518319
     */
    getDoubaoSearchAuthLevel(): number;
    /**
     * Whether to enable Query Rewrite for Doubao web search.
     * Rewrites user queries to improve retrieval relevance.
     * See: https://www.volcengine.com/docs/87772/2272950 (2025-12 feature)
     */
    isDoubaoQueryRewriteEnabled(): boolean;
    /**
     * Industry filter for Doubao web search (vertical search scope).
     * Supports: finance, gaming, government (gov type added 2026-06).
     * Empty string = no industry filter (search all).
     * See: https://www.volcengine.com/docs/87772/2272950
     */
    getDoubaoSearchIndustry(): string;
    /**
     * Whether to enable Doubao Flex (low-priority) inference tier.
     * Flex uses low-priority resources with independent TPM quota and discounted pricing,
     * ideal for latency-insensitive batch tasks like periodic monitoring.
     * See: https://ark.volcengine.com/region:cn-beijing/docs/online-inference-flex
     * Default: "auto" — enables Flex for monitoring batch queries, disabled for real-time.
     * Options: "always", "auto", "never"
     */
    getDoubaoFlexMode(): 'always' | 'auto' | 'never';
    /**
     * Max server-side wait timeout for Doubao Flex inference in milliseconds.
     * Flex requests queue on the server side; this sets the upper bound for waiting.
     * Default: 300000 (5 minutes). Max allowed: 1200000 (20 minutes).
     * See: https://ark.volcengine.com/region:cn-beijing/docs/online-inference-flex
     */
    getDoubaoFlexMaxWaitMs(): number;
    /**
     * Determine whether to use Flex tier for a given Doubao request.
     * @param isBatch Whether this is a batch/background query (latency-tolerant).
     */
    useDoubaoFlex(isBatch?: boolean): boolean;
    /**
     * Whether to enable Kimi Web Search via the dedicated tools/search API.
     * Kimi launched Web Search API in Sep 2026 with /v1/tools/search endpoint.
     * When enabled, Kimi queries use structured search results for better source attribution.
     * See: https://platform.kimi.ai/docs/platform-changelog
     * Default: false (uses built-in use_search param for backward compatibility)
     */
    isKimiWebSearchApiEnabled(): boolean;
    getModelName(platform: string): string;
    getMaxTokens(platform: string): number;
    buildRequestData(platform: string, question: string, opts?: {
        isBatch?: boolean;
    }): RequestBody;
    private buildDoubaoRequest;
    private buildDeepSeekRequest;
    private buildQianwenRequest;
    private buildKimiRequest;
    private buildHunyuanRequest;
    private buildDefaultRequest;
    getAvailablePlatforms(): string[];
    queryPlatform(platform: string, question: string, opts?: {
        isBatch?: boolean;
    }): Promise<QueryResult>;
    queryMultiplePlatforms(platforms: string[], question: string, opts?: {
        isBatch?: boolean;
    }): Promise<QueryResult[]>;
}
export declare const aiPlatformService: AIPlatformService;
export {};
//# sourceMappingURL=ai-platform-service.d.ts.map