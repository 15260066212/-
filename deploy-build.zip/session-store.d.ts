import type { SessionData } from '@zemingengine/shared';
import { DialogueEngine } from '@zemingengine/dialogue-engine';
import type { DatabaseAccess } from './db.js';
interface SessionEntry {
    data: SessionData;
    engine: DialogueEngine;
    createdAt: Date;
    updatedAt: Date;
    userId?: string;
}
export declare function createSession(db?: DatabaseAccess, userId?: string): SessionEntry;
export declare function getSession(id: string, db?: DatabaseAccess): SessionEntry | undefined;
export declare function updateSession(id: string, data: SessionData, db?: DatabaseAccess): SessionEntry | undefined;
export declare function deleteSession(id: string, db?: DatabaseAccess): boolean;
export declare function listSessions(userId?: string): SessionEntry[];
export {};
//# sourceMappingURL=session-store.d.ts.map