import type { Article, SessionData, ReviewResult, ReviewWeights } from '@zemingengine/shared';
/** Compute SHA-256 hash of review result for tamper detection. */
export declare function computeReviewHash(data: {
    articleId: string;
    overallScore: number;
    passed: boolean;
    issuesCount: number;
    reviewedAt: string;
}): string;
/** Verify that a review result's content hash matches. */
export declare function verifyReviewHash(review: {
    articleId: string;
    overallScore: number;
    passed: boolean;
    issues?: unknown[];
    reviewedAt: string;
    contentHash?: string;
}): boolean;
export interface ReviewerOptions {
    passThreshold?: number;
    weights?: ReviewWeights;
}
export declare class ContentReviewer {
    private passThreshold;
    private weights;
    constructor(options?: ReviewerOptions);
    review(article: Article, session: SessionData): ReviewResult;
}
//# sourceMappingURL=reviewer.d.ts.map