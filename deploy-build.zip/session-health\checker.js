import { WechatValidator } from './validators/wechat.js';
import { createHarvesterValidators } from './validators/harvester-registry.js';
import { HealthAlerter } from './alerter.js';
import { CHECK_BATCH_SIZE, MAX_CONSECUTIVE_FAILURES, } from './types.js';
export class SessionHealthChecker {
    db;
    validators = new Map();
    alerter;
    reloginManager;
    running = false;
    constructor(db, reloginManager) {
        this.db = db;
        this.alerter = new HealthAlerter(db);
        this.reloginManager = reloginManager;
        this.registerValidator(new WechatValidator());
        if (process.env.RPA_REMOTE_URL) {
            const harvesterValidators = createHarvesterValidators();
            for (const v of harvesterValidators) {
                this.registerValidator(v);
            }
            console.log(`[HealthChecker] Registered ${harvesterValidators.length} RPA platform validators (harvester mode)`);
        }
    }
    /** Set or update the relogin manager (for late injection). */
    setReloginManager(mgr) {
        this.reloginManager = mgr;
    }
    registerValidator(validator) {
        if ('setDatabase' in validator && typeof validator.setDatabase === 'function') {
            validator.setDatabase(this.db);
        }
        this.validators.set(validator.platform, validator);
    }
    hasValidator(platform) {
        return this.validators.has(platform);
    }
    /**
     * Run a batch of health checks on credentials that are due.
     * Called periodically by the scheduler.
     */
    async runCheckBatch(batchSize = CHECK_BATCH_SIZE) {
        if (this.running) {
            console.log('[HealthChecker] Skipping batch: previous batch still running');
            return 0;
        }
        this.running = true;
        let checkedCount = 0;
        try {
            const dueCredentials = this.db.credentials.getCredentialsDueForCheck(batchSize);
            const toCheck = dueCredentials.filter((c) => this.hasValidator(c.platform));
            if (toCheck.length === 0) {
                return 0;
            }
            console.log(`[HealthChecker] Checking ${toCheck.length} credential(s)`);
            const promises = toCheck.map(async (cred) => {
                try {
                    await this.checkCredential(cred);
                }
                catch (err) {
                    console.error(`[HealthChecker] Unexpected error checking ${cred.platform}:`, err instanceof Error ? err.message : err);
                }
            });
            await Promise.all(promises);
            checkedCount = toCheck.length;
            await this.alerter.sendPendingAlerts().catch((err) => {
                console.error('[HealthChecker] Failed to send alerts:', err instanceof Error ? err.message : err);
            });
        }
        finally {
            this.running = false;
        }
        return checkedCount;
    }
    /** Run the validator and capture the outcome, catching any thrown errors. */
    async executeValidation(credentials, userId) {
        this.db.credentials.recordHealthCheck(credentials.platform, 'checking', 0, undefined, userId);
        try {
            const validator = this.validators.get(credentials.platform);
            const result = await validator.validate(credentials);
            if (result.valid) {
                return { status: 'valid' };
            }
            return { status: 'error', errorMessage: result.error || 'Validation failed' };
        }
        catch (err) {
            return { status: 'error', errorMessage: err instanceof Error ? err.message : String(err) };
        }
    }
    /** Record a valid result and create a recovery alert if the credential was previously expired. */
    handleValidResult(credentials, userId, wasExpired) {
        this.db.credentials.recordHealthCheck(credentials.platform, 'valid', 0, undefined, userId);
        if (wasExpired) {
            this.alerter.createAlert({
                platform: credentials.platform,
                alertType: 'session_recovered',
                message: `登录态已恢复正常`,
                userId,
            });
            console.log(`[HealthChecker] ${credentials.platform}: recovered from expired`);
        }
    }
    /** Fire-and-forget auto-relogin for supported platforms. */
    maybeTriggerRelogin(platform, userId) {
        if (!this.reloginManager?.isPlatformSupported(platform))
            return;
        if (!this.reloginManager.canAttempt(platform)) {
            console.log(`[HealthChecker] Relogin for ${platform} is in cooldown or rate-limited`);
            return;
        }
        console.log(`[HealthChecker] Triggering auto-relogin for ${platform}`);
        void this.reloginManager.attemptRelogin(platform, userId)
            .then((result) => {
            if (result.success) {
                console.log(`[HealthChecker] Auto-relogin succeeded for ${platform}`);
            }
            else {
                console.warn(`[HealthChecker] Auto-relogin failed for ${platform}: ${result.errorType} - ${result.errorMessage}`);
            }
        })
            .catch((err) => {
            console.error(`[HealthChecker] Relogin error for ${platform}:`, err instanceof Error ? err.message : err);
        });
    }
    /** Record an error result, auto-upgrade to expired if threshold reached, and create appropriate alerts. */
    handleErrorResult(credentials, userId, wasExpired, outcome) {
        const errorMessage = outcome.errorMessage;
        this.db.credentials.recordHealthCheck(credentials.platform, 'error', 0, errorMessage, userId);
        const failures = this.db.credentials.getConsecutiveFailures(credentials.platform, userId);
        if (failures >= MAX_CONSECUTIVE_FAILURES) {
            const reason = `连续 ${failures} 次检查失败: ${errorMessage}`;
            this.db.credentials.markCredentialExpired(credentials.platform, reason, userId);
            if (!wasExpired) {
                this.alerter.createAlert({
                    platform: credentials.platform,
                    alertType: 'session_expired',
                    message: reason,
                    userId,
                });
                this.maybeTriggerRelogin(credentials.platform, userId);
            }
            return 'expired';
        }
        if (failures === 1 && !wasExpired) {
            this.alerter.createAlert({
                platform: credentials.platform,
                alertType: 'consecutive_failures',
                message: `健康检查失败: ${errorMessage}`,
                userId,
            });
        }
        return 'error';
    }
    /**
     * Check a single credential's health status.
     * Auto-upgrades to 'expired' after MAX_CONSECUTIVE_FAILURES.
     * Creates alerts on status transitions.
     */
    async checkCredential(credentials) {
        const validator = this.validators.get(credentials.platform);
        if (!validator) {
            return 'valid';
        }
        const userId = 'user_default';
        const previousHealth = this.db.credentials.getCredentialHealthDetail(credentials.platform, userId);
        const wasExpired = previousHealth?.status === 'expired';
        const outcome = await this.executeValidation(credentials, userId);
        const status = outcome.status === 'valid'
            ? (this.handleValidResult(credentials, userId, wasExpired), 'valid')
            : this.handleErrorResult(credentials, userId, wasExpired, outcome);
        console.log(`[HealthChecker] ${credentials.platform}: ${status}` +
            (outcome.errorMessage ? ` (${outcome.errorMessage})` : '') +
            (previousHealth ? ` [failures: ${previousHealth.consecutiveFailures}→${this.db.credentials.getConsecutiveFailures(credentials.platform, userId)}]` : ''));
        return status;
    }
}
//# sourceMappingURL=checker.js.map