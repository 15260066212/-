import type { DB } from '../db.js';
/** Default score for review dimensions (originality, readability, etc.) */
export declare const DEFAULT_REVIEW_DIMENSION_SCORE = 100;
export declare function initReviewTables(db: DB, currentVersion: number): void;
//# sourceMappingURL=reviews.schema.d.ts.map