export class ReviewRepository {
    db;
    constructor(db) {
        this.db = db;
    }
    insertReview(review) {
        const id = `rev_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
        const stmt = this.db.prepare(`
      INSERT INTO reviews (
        id, article_id, round, passed, overall_score,
        compliance_score, quality_score, seo_score, brand_score,
        originality_score, platform_adaptation_score, readability_score,
        safety_score, content_hash,
        issues, suggestions, reviewed_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
        stmt.run(id, review.articleId, review.round, review.passed ? 1 : 0, review.overallScore, review.dimensions.compliance.score, review.dimensions.quality.score, review.dimensions.seo.score, review.dimensions.brand.score, review.dimensions.originality?.score ?? 100, review.dimensions.platform_adaptation?.score ?? 100, review.dimensions.readability?.score ?? 100, review.dimensions.safety?.score ?? 100, review.contentHash ?? null, JSON.stringify(review.issues), JSON.stringify(review.suggestions), review.reviewedAt);
        // Record audit entry
        this.recordReviewAudit(id, review.articleId, review.passed ? 'passed' : 'failed', 'system', `Score: ${review.overallScore}, Round: ${review.round}`);
        return id;
    }
    getReviewsByArticle(articleId) {
        const rows = this.db.prepare('SELECT * FROM reviews WHERE article_id = ? ORDER BY round ASC').all(articleId);
        return rows.map((r) => this.mapReview(r));
    }
    getLatestReview(articleId) {
        const row = this.db.prepare('SELECT * FROM reviews WHERE article_id = ? ORDER BY round DESC LIMIT 1').get(articleId);
        return row ? this.mapReview(row) : undefined;
    }
    mapReview(row) {
        const issues = JSON.parse(String(row.issues));
        // Reconstruct dimension-level issues by filtering the full issues array
        const filterByDim = (dim) => issues.filter((i) => i.dimension === dim);
        return {
            articleId: String(row.article_id),
            round: Number(row.round),
            passed: Boolean(row.passed),
            overallScore: Number(row.overall_score),
            dimensions: {
                compliance: { score: Number(row.compliance_score), issues: filterByDim('compliance') },
                quality: { score: Number(row.quality_score), issues: filterByDim('quality') },
                seo: { score: Number(row.seo_score), issues: filterByDim('seo') },
                brand: { score: Number(row.brand_score), issues: filterByDim('brand') },
                originality: { score: Number(row.originality_score ?? 100), issues: filterByDim('originality') },
                platform_adaptation: { score: Number(row.platform_adaptation_score ?? 100), issues: filterByDim('platform_adaptation') },
                readability: { score: Number(row.readability_score ?? 100), issues: filterByDim('readability') },
                safety: { score: Number(row.safety_score ?? 100), issues: filterByDim('safety') },
            },
            issues,
            suggestions: JSON.parse(String(row.suggestions)),
            reviewedAt: String(row.reviewed_at),
            contentHash: row.content_hash ? String(row.content_hash) : undefined,
        };
    }
    /** Get dimension scores from recent reviews for health monitoring. */
    getReviewDimensionStats(limit = 100) {
        const safeLimit = Math.max(1, Math.floor(limit));
        return this.db.prepare(`SELECT overall_score, compliance_score, quality_score, seo_score, brand_score,
              originality_score, platform_adaptation_score, readability_score, safety_score,
              passed, content_hash
       FROM reviews ORDER BY reviewed_at DESC LIMIT ?`).all(safeLimit);
    }
    /** Get review safety statistics (hash coverage, publish protection). */
    getReviewSafetyStats() {
        const total = this.db.prepare('SELECT COUNT(*) as count FROM reviews').get();
        const withHash = this.db.prepare('SELECT COUNT(*) as count FROM reviews WHERE content_hash IS NOT NULL').get();
        const published = this.db.prepare("SELECT COUNT(*) as count FROM articles WHERE status = 'published'").get();
        const publishedReviewed = this.db.prepare(`SELECT COUNT(DISTINCT a.id) as count FROM articles a
       INNER JOIN reviews r ON a.id = r.article_id
       WHERE a.status = 'published' AND r.passed = 1`).get();
        return {
            totalReviews: total.count,
            reviewsWithHash: withHash.count,
            hashCoverage: total.count > 0 ? Math.round((withHash.count / total.count) * 1000) / 10 : 0,
            publishedArticles: published.count,
            publishedWithReview: publishedReviewed.count,
        };
    }
    /** Record a review audit event. */
    recordReviewAudit(reviewId, articleId, action, actor = 'system', details) {
        this.db.prepare(`INSERT INTO review_audit_log (review_id, article_id, action, actor, details, created_at)
       VALUES (?, ?, ?, ?, ?, ?)`).run(reviewId, articleId, action, actor, details ?? null, Date.now());
    }
    /** Get audit trail for an article. */
    getReviewAuditTrail(articleId, limit = 50) {
        const safeLimit = Math.max(1, Math.floor(limit));
        const rows = this.db.prepare(`SELECT id, review_id, article_id, action, actor, details, created_at
       FROM review_audit_log WHERE article_id = ?
       ORDER BY created_at DESC LIMIT ?`).all(articleId, safeLimit);
        return rows.map((r) => ({
            id: Number(r.id),
            reviewId: String(r.review_id),
            articleId: String(r.article_id),
            action: String(r.action),
            actor: String(r.actor),
            details: r.details ? String(r.details) : null,
            createdAt: Number(r.created_at),
        }));
    }
    /** Check if an article has a passing review (rollback protection). */
    hasPassingReview(articleId) {
        const row = this.db.prepare('SELECT 1 FROM reviews WHERE article_id = ? AND passed = 1 ORDER BY round DESC, reviewed_at DESC LIMIT 1').get(articleId);
        return !!row;
    }
    /** Get latest review status for an article (for publish guard). */
    getLatestReviewStatus(articleId) {
        const row = this.db.prepare('SELECT passed, overall_score, round FROM reviews WHERE article_id = ? ORDER BY round DESC, reviewed_at DESC LIMIT 1').get(articleId);
        if (!row)
            return null;
        return { passed: Boolean(row.passed), overallScore: Number(row.overall_score), round: Number(row.round) };
    }
}
//# sourceMappingURL=review-repository.js.map