/**
 * Article content utilities: append contact info footer, etc.
 */
import type { Article, EnterpriseProfile } from '@zemingengine/shared';
/**
 * Append enterprise contact information to the end of an article.
 * Only appends if the enterprise has at least one contact field (phone/email/address)
 * and the article doesn't already seem to have contact info at the end.
 *
 * The footer is appended as a Markdown section with a horizontal rule separator,
 * so it renders consistently across platforms (Markdown → HTML adapters handle it).
 */
export declare function appendContactFooter(article: Article, enterprise: EnterpriseProfile | undefined): Article;
//# sourceMappingURL=article-footer.d.ts.map