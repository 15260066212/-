import { startScheduler, stopScheduler, recoverStaleTasks, filterDueTasks, checkDispatchGuard } from './publish-scheduler.js';
import { startCookieWarmer, stopCookieWarmer } from './cookie-warmer.js';
import { startHealthChecker, stopHealthChecker } from './health-checker.js';
import { startPlanTaskScheduler, stopPlanScheduler } from './plan-scheduler.js';
import { startCacheCleanup, stopCacheCleanup } from './cache-cleanup.js';
export { startScheduler, stopScheduler, recoverStaleTasks, filterDueTasks, checkDispatchGuard, startCookieWarmer, stopCookieWarmer, startHealthChecker, stopHealthChecker, startPlanTaskScheduler, stopPlanScheduler, startCacheCleanup, stopCacheCleanup, };
/**
 * Start all schedulers at once.
 * Convenience function for server startup.
 */
export declare function startAllSchedulers(deps: {
    db: any;
    publisher: any;
    healthChecker: any;
    executePlanTask: (task: any) => Promise<void>;
}): void;
/**
 * Stop all schedulers at once.
 * Convenience function for server shutdown / graceful termination.
 */
export declare function stopAllSchedulers(): void;
//# sourceMappingURL=index.d.ts.map