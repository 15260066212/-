import { Hono } from 'hono';
import type { DatabaseAccess } from '../db.js';
import type { ReloginManager } from '../session-health/relogin-manager.js';
import type { SelectorMonitor } from '../session-health/selector-monitor.js';
import type { CaptchaManager } from '../session-health/captcha-manager.js';
type Db = DatabaseAccess | import('../cached-db.js').CachedDatabaseAccess;
export declare function createMonitorRoutes(db: Db, _reloginManager: ReloginManager, selectorMonitor: SelectorMonitor, _captchaManager: CaptchaManager): Hono<import("hono/types").BlankEnv, import("hono/types").BlankSchema, "/">;
export {};
//# sourceMappingURL=monitor.d.ts.map