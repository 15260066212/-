import { SimpleRpaHandler } from './base.js';
/**
 * Baijiahao (百家号) RPA handler - publishes articles via browser automation.
 * Requires cookie-based authentication (BDUSS, STOKEN, etc.)
 *
 * Publishing flow:
 * 1. Navigate to https://baijiahao.baidu.com/builder/rc/edit?type=news
 * 2. Fill in title
 * 3. Fill in content (rich text editor / UEditor)
 * 4. Add tags if available
 * 5. Click publish button
 * 6. Handle confirmation dialog
 * 7. Extract the published article URL
 */
export declare class BaijiaRpaHandler extends SimpleRpaHandler {
    protected readonly cookieDomain = ".baijiahao.baidu.com";
    protected readonly loginUrlKeywords: string[];
    protected readonly platformDisplayName = "Baijiahao";
    protected readonly titleSelectors: string[];
    protected readonly contentEditorSelectors: string[];
    protected readonly enableTags = true;
    protected readonly maxTags = 5;
    protected readonly publishButtonSelectors: string[];
    protected readonly hasConfirmDialog = true;
    protected readonly confirmButtonSelectors: string[];
    protected readonly postIdPatterns: RegExp[];
    constructor();
    /**
     * Hook: Enter the editor. For Baijiahao, we may need to close
     * welcome popups or switch to the correct tab.
     */
    protected enterEditor(page: import('playwright').Page): Promise<boolean>;
}
//# sourceMappingURL=baijia.d.ts.map