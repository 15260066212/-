import { HarvesterBrowserValidator } from './harvester-browser.js';
/**
 * Registry of all RPA/harvester platform configurations.
 * Replaces the 10 previously empty Validator subclasses.
 */
export const HARVESTER_PLATFORMS = [
    { platform: 'zhihu' },
    { platform: 'csdn' },
    { platform: 'baijia', harvesterPlatform: 'baijiahao' },
    { platform: 'toutiao', harvesterPlatform: 'toutiaohao' },
    { platform: 'juejin' },
    { platform: 'bilibili' },
    { platform: 'sohu', harvesterPlatform: 'sohuhao' },
    { platform: 'netease', harvesterPlatform: 'wangyihao' },
    { platform: 'zhidao' },
];
/**
 * Factory function that creates HarvesterBrowserValidator instances
 * for all registered harvester platforms.
 */
export function createHarvesterValidators() {
    return HARVESTER_PLATFORMS.map((cfg) => new HarvesterBrowserValidator(cfg.platform, cfg.harvesterPlatform));
}
//# sourceMappingURL=harvester-registry.js.map