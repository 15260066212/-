import type { PlatformId } from '@zemingengine/shared';
import type { PublishParams, PublishResult } from '../types.js';
export interface VerificationResult {
    verificationStatus: 'verified' | 'unverified' | 'failed';
    verificationMessage: string;
}
export declare abstract class PlatformAdapter {
    readonly platform: PlatformId;
    constructor(platform: PlatformId);
    abstract publish(params: PublishParams): Promise<PublishResult>;
    getMethod(): 'api' | 'rpa';
}
//# sourceMappingURL=base.d.ts.map