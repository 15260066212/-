export interface PlatformResult {
    platform: string;
    platformName: string;
    responseText: string;
    responseTime: number;
    visibility: any;
    sentiment: any;
    citations: any;
    error?: string;
}
export interface CompetitorData {
    name: string;
    website: string;
    aiMentionScore: number;
    searchVisibility: number;
    contentCoverage: number;
    brandConsistency: number;
    trustSignals: number;
    platformPresence: Record<string, number>;
    geoKeywords: string[];
    strengths: string[];
    weaknesses: string[];
    summary: string;
}
export interface CompetitorReportResult {
    html: string;
    result: any;
    mode: 'real' | 'mock';
}
/**
 * 生成竞品监测报告（核心用例编排）。
 *
 * 流程：
 * 1. 多平台查询品牌对比问题
 * 2. 解析响应，执行可见度分析和引用分析
 * 3. 补充情感分析
 * 4. 跨平台聚合结果
 * 5. 生成 HTML 报告
 * 6. 若无可用平台数据，则回退到 mock 数据
 */
export declare function generateCompetitorReport(target: string, competitors: string[]): Promise<CompetitorReportResult>;
//# sourceMappingURL=competitor-monitor.service.d.ts.map