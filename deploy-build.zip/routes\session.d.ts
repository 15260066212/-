import { Hono } from 'hono';
import type { AppEnv, DatabaseAccess } from '../db.js';
export declare function createSessionRoutes(db: DatabaseAccess): Hono<AppEnv>;
//# sourceMappingURL=session.d.ts.map