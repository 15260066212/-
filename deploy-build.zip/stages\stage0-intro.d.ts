import type { StageHandler } from '../types.js';
export declare const introStage: StageHandler;
//# sourceMappingURL=stage0-intro.d.ts.map