import type { DB } from '../db.js';
export declare function initUserTables(db: DB, currentVersion: number): void;
//# sourceMappingURL=auth.schema.d.ts.map