import { HarvesterBrowserValidator } from './harvester-browser.js';
export declare class ZhidaoValidator extends HarvesterBrowserValidator {
    readonly platform: "zhidao";
}
//# sourceMappingURL=zhidao.d.ts.map