import type { PublishTask, Article, PlatformCredentials } from '@zemingengine/shared';
import type { DatabaseAccess } from './db.js';
import type { Publisher } from '@zemingengine/publisher';
/**
 * Execute publishWithRetry and handle result/error by updating task and article status.
 * Shared between scheduler and pipeline to eliminate duplicate error handling.
 */
export declare function executePublishWithHandling(db: DatabaseAccess, publisher: Publisher, task: PublishTask, article: Article, credentials: PlatformCredentials, logPrefix?: string): Promise<void>;
//# sourceMappingURL=publish-utils.d.ts.map