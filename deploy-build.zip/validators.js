export function required(input) {
    if (!input.trim()) {
        return { valid: false, error: '此项不能为空，请填写后重试' };
    }
    return { valid: true };
}
export function minLength(min) {
    return (input) => {
        if (input.trim().length < min) {
            return { valid: false, error: `至少需要 ${min} 个字符` };
        }
        return { valid: true };
    };
}
export function maxLength(max) {
    return (input) => {
        if (input.trim().length > max) {
            return { valid: false, error: `不能超过 ${max} 个字符` };
        }
        return { valid: true };
    };
}
export function isUrl(input) {
    try {
        new URL(input);
        return { valid: true };
    }
    catch {
        return { valid: false, error: '请输入有效的 URL（如 https://example.com）' };
    }
}
export function combine(...validators) {
    return (input) => {
        for (const validator of validators) {
            const result = validator(input);
            if (!result.valid)
                return result;
        }
        return { valid: true };
    };
}
//# sourceMappingURL=validators.js.map