import { HarvesterBrowserValidator } from './harvester-browser.js';
export class NeteaseValidator extends HarvesterBrowserValidator {
    platform = 'netease';
    get harvesterPlatform() {
        return 'wangyihao';
    }
}
//# sourceMappingURL=netease.js.map