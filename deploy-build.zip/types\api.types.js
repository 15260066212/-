/**
 * API request/response type definitions.
 */
export {};
//# sourceMappingURL=api.types.js.map