/**
 * Account Vault Types
 * 支持多平台多账号的加密凭据管理
 */
export {};
//# sourceMappingURL=types.js.map