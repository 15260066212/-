import { type Article, type PlatformCredentials, type PlatformId } from '@zemingengine/shared';
import type { Page } from 'playwright';
import type { PublishResult } from '../types.js';
/**
 * Parse cookie string from credentials into Playwright cookie format.
 * Expects credentials.data.cookie or credentials.data.cookies to contain
 * a cookie string in "name=value; name2=value2" format.
 */
export declare function parseCookies(credentials: PlatformCredentials, domain: string): Array<{
    name: string;
    value: string;
    domain: string;
    path: string;
}>;
/**
 * Standard timeout constants used across RPA handlers.
 */
export declare const RpaTimeout: {
    readonly SHORT: 500;
    readonly MEDIUM: 1000;
    readonly LONG: 2000;
    readonly EXTRA_LONG: 3000;
    readonly DEFAULT: 5000;
    readonly EXTENDED: 10000;
    readonly PAGE_NAVIGATION: 30000;
};
/**
 * Abstract RPA handler for platform-specific publishing via browser automation.
 * Each platform implements its own navigation, content filling, and submission logic.
 */
export declare abstract class RpaHandler {
    readonly platform: PlatformId;
    /** Standard timeout values — subclasses may override for platform-specific tuning. */
    protected readonly timeouts: {
        readonly SHORT: 500;
        readonly MEDIUM: 1000;
        readonly LONG: 2000;
        readonly EXTRA_LONG: 3000;
        readonly DEFAULT: 5000;
        readonly EXTENDED: 10000;
        readonly PAGE_NAVIGATION: 30000;
    };
    constructor(platform: PlatformId);
    /**
     * Execute the publishing flow for this platform.
     * @param page - Playwright Page with cookies already injected
     * @param article - Article to publish
     * @param credentials - Platform credentials (cookies, tokens, etc.)
     */
    abstract publish(page: Page, article: Article, credentials: PlatformCredentials): Promise<PublishResult>;
    /**
     * Parse cookie string from credentials into Playwright cookie format.
     * @deprecated Use the standalone `parseCookies` function instead.
     */
    protected parseCookies(credentials: PlatformCredentials, domain: string): Array<{
        name: string;
        value: string;
        domain: string;
        path: string;
    }>;
    /**
     * Take a screenshot for debugging purposes.
     */
    protected captureScreenshot(page: Page, label: string): Promise<string>;
    /**
     * Wait for a selector and click it, with error handling.
     */
    protected clickElement(page: Page, selector: string, timeout?: number): Promise<boolean>;
    /**
     * Fill an input field with text.
     */
    protected fillInput(page: Page, selector: string, text: string, timeout?: number): Promise<boolean>;
    /**
     * Fill a rich text editor with content.
     *
     * Tries common editor types in order:
     * 1. Platform-specific primary selectors (via extraSelectors param)
     * 2. ProseMirror
     * 3. Quill (.ql-editor)
     * 4. Contenteditable div
     * 5. Textarea fallback
     *
     * Subclasses may override this method for platform-specific behavior,
     * or call `super.fillRichTextEditor(page, content, extraSelectors)`
     * to add platform-specific primary selectors before the generic chain.
     *
     * @param page - Playwright Page
     * @param content - Text content to fill
     * @param extraSelectors - Optional additional selectors to try first (platform-specific primary editor)
     * @returns true if content was filled successfully
     */
    protected fillRichTextEditor(page: Page, content: string, extraSelectors?: string[]): Promise<boolean>;
    /**
     * Add tags to a platform's tag input field.
     *
     * Iterates through tags and fills them one by one via the tag input,
     * pressing Enter after each tag. Tags are optional — failures are silent.
     *
     * Subclasses may override this method for platform-specific behavior,
     * or call `super.addTags(page, tags, extraInputSelectors, maxTags)`
     * to add platform-specific input selectors.
     *
     * @param page - Playwright Page
     * @param tags - Array of tag strings
     * @param extraInputSelectors - Optional additional tag input selectors to try first
     * @param maxTags - Maximum number of tags to add (default: 5)
     */
    protected addTags(page: Page, tags: string[], extraInputSelectors?: string[], maxTags?: number): Promise<void>;
}
/**
 * A simplified RPA handler base class using the Template Method pattern.
 *
 * Platforms with a straightforward "navigate → fill title → fill content →
 * add tags → select category → publish" flow can extend this class and
 * customize behavior via protected properties and optional hook overrides,
 * instead of rewriting the entire publish() method.
 *
 * Complex platforms (CSDN, Zhihu, Juejin, etc.) should continue extending
 * the base `RpaHandler` class directly.
 *
 * The publish() method defines the fixed skeleton of the publishing flow;
 * subclasses customize individual steps by overriding protected properties
 * and hook methods.
 */
export declare abstract class SimpleRpaHandler extends RpaHandler {
    /** Cookie domain for this platform (e.g. ".example.com"). */
    protected abstract readonly cookieDomain: string;
    /** URL path segments that indicate a login redirect (auth failure). */
    protected readonly loginUrlKeywords: string[];
    /** Title input selectors, tried in order until one succeeds. */
    protected abstract readonly titleSelectors: string[];
    /**
     * Primary rich-text editor selectors, tried before generic fallbacks.
     * Passed as `extraSelectors` to `fillRichTextEditor`.
     */
    protected readonly contentEditorSelectors: string[];
    /** Whether the platform supports adding tags. */
    protected readonly enableTags: boolean;
    /** Maximum number of tags (only relevant when enableTags is true). */
    protected readonly maxTags: number;
    /** Publish button selectors, tried in order. */
    protected readonly publishButtonSelectors: string[];
    /** Whether a confirmation dialog appears after clicking publish. */
    protected readonly hasConfirmDialog: boolean;
    /** Confirm button selectors in the confirmation dialog, tried in order. */
    protected readonly confirmButtonSelectors: string[];
    /** Regex patterns to extract a post ID from the published URL, tried in order. */
    protected readonly postIdPatterns: RegExp[];
    /** Human-readable platform name used in error messages. */
    protected abstract readonly platformDisplayName: string;
    constructor(platform: PlatformId);
    /**
     * Template method — defines the skeleton of the publishing flow.
     * Subclasses customize individual steps via properties and hook methods.
     */
    publish(page: Page, article: Article, credentials: PlatformCredentials): Promise<PublishResult>;
    /**
     * Hook: navigate into the editor after landing on the platform page.
     * Returns true if the editor is ready, false to abort the publish flow.
     * Default: no-op, returns true immediately.
     *
     * Override this for platforms where you first land on a dashboard and
     * need to click through to reach the editor.
     */
    protected enterEditor(page: Page): Promise<boolean>;
    /**
     * Hook: select a category/channel for the article.
     * Default: no-op. Override for platforms that require category selection.
     */
    protected selectCategory(page: Page): Promise<void>;
}
//# sourceMappingURL=base.d.ts.map