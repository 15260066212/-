import { HarvesterBrowserValidator } from './harvester-browser.js';
export declare class BilibiliValidator extends HarvesterBrowserValidator {
    readonly platform: "bilibili";
}
//# sourceMappingURL=bilibili.d.ts.map