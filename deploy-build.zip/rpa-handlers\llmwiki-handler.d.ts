import { type Article, type PlatformCredentials, type PlatformId } from '@zemingengine/shared';
import type { Page } from 'playwright';
import type { PublishResult } from '../types.js';
import { RpaHandler } from './base.js';
/**
 * LLMWiki-powered RPA fallback handler.
 *
 * When the platform-specific RPA handler fails, this handler steps in
 * using the LLMWiki knowledge base to execute the publishing flow.
 * This provides automatic self-healing and platform-change resilience.
 *
 * Usage: This is NOT registered as a primary handler. RPAEngine uses it
 * internally as a fallback when the primary handler fails.
 *
 * This class also manages the fallback enabled/disabled state and provides
 * convenience methods (canUseLLMWikiFallback, tryFallback) used by RPAEngine
 * to coordinate the fallback flow.
 */
export declare class LLMWikiHandler extends RpaHandler {
    private llmwikiPublisher;
    private initPromise;
    private fallbackEnabled;
    constructor(fallbackEnabled?: boolean);
    /**
     * Check if LLMWiki has knowledge for a given platform.
     */
    supportsPlatform(platform: PlatformId): boolean;
    /**
     * Enable or disable LLMWiki fallback at runtime.
     */
    setFallbackEnabled(enabled: boolean): void;
    /**
     * Check if LLMWiki fallback should be attempted for a given platform.
     * Combines the enabled flag with platform support check.
     */
    canUseLLMWikiFallback(platform: PlatformId): boolean;
    /**
     * Try publishing via LLMWiki fallback.
     * Called when the primary RPA handler fails.
     *
     * @param page - Playwright Page with cookies already injected
     * @param article - Article to publish
     * @param credentials - Platform credentials
     * @param originalError - Optional error string from the primary handler failure (for logging)
     * @returns PublishResult on success, null if fallback not available or failed
     */
    tryFallback(page: Page, article: Article, credentials: PlatformCredentials, originalError?: string): Promise<PublishResult | null>;
    /**
     * Lazily initialize the LLMWiki publisher.
     * Only loads when actually needed (first fallback).
     */
    private getPublisher;
    private doInit;
    /**
     * Publish using LLMWiki knowledge base.
     *
     * @param page - Playwright Page with cookies already injected
     * @param article - Article to publish (main system format)
     * @param credentials - Platform credentials (used for platform name mapping)
     */
    publish(page: Page, article: Article, _credentials: PlatformCredentials): Promise<PublishResult>;
    /**
     * Convert LLMWiki publish result to standard PublishResult format.
     */
    private convertResult;
}
//# sourceMappingURL=llmwiki-handler.d.ts.map