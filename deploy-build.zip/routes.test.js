import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import Database from 'better-sqlite3';
import { DatabaseAccess } from './db.js';
import { createEmptySession } from '@zemingengine/shared';
import { createArticleRoutes } from './routes/article.js';
import { createReviewRoutes } from './routes/review.js';
import { createCredentialRoutes } from './routes/credentials.js';
import { createSessionRoutes } from './routes/session.js';
import { createPipelineRoutes } from './routes/pipeline.js';
let db;
let dbAccess;
beforeEach(() => {
    // Create a fresh in-memory database for each test (same pattern as db.test.ts)
    db = new Database(':memory:');
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
    // Run the same init logic as createDatabase
    db.exec(`
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      data TEXT NOT NULL,
      current_stage TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      user_id TEXT
    );
    CREATE TABLE IF NOT EXISTS articles (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      platform TEXT NOT NULL,
      content_type TEXT NOT NULL,
      title TEXT NOT NULL,
      content_markdown TEXT NOT NULL,
      content_html TEXT,
      content_plain TEXT,
      tags TEXT NOT NULL DEFAULT '[]',
      summary TEXT,
      cover_image_desc TEXT,
      word_count INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'draft',
      generation_round INTEGER NOT NULL DEFAULT 1,
      generation_meta TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS reviews (
      id TEXT PRIMARY KEY,
      article_id TEXT NOT NULL,
      round INTEGER NOT NULL,
      passed INTEGER NOT NULL,
      overall_score REAL NOT NULL,
      compliance_score REAL NOT NULL,
      quality_score REAL NOT NULL,
      seo_score REAL NOT NULL,
      brand_score REAL NOT NULL,
      originality_score REAL NOT NULL DEFAULT 100,
      platform_adaptation_score REAL NOT NULL DEFAULT 100,
      readability_score REAL NOT NULL DEFAULT 100,
      issues TEXT NOT NULL DEFAULT '[]',
      suggestions TEXT NOT NULL DEFAULT '[]',
      reviewed_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS publish_tasks (
      id TEXT PRIMARY KEY,
      article_id TEXT NOT NULL,
      platform TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      method TEXT NOT NULL,
      platform_post_id TEXT,
      platform_post_url TEXT,
      error_message TEXT,
      retry_count INTEGER NOT NULL DEFAULT 0,
      max_retries INTEGER NOT NULL DEFAULT 2,
      scheduled_at TEXT,
      published_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS publish_logs (
      id TEXT PRIMARY KEY,
      task_id TEXT NOT NULL,
      level TEXT NOT NULL,
      message TEXT NOT NULL,
      metadata TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS platform_credentials (
      user_id TEXT NOT NULL DEFAULT 'user_default',
      platform TEXT NOT NULL,
      credential_type TEXT NOT NULL,
      credential_data TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      last_validated_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      PRIMARY KEY (user_id, platform)
    );
    CREATE TABLE IF NOT EXISTS schema_version (
      version INTEGER PRIMARY KEY,
      applied_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS pipeline_runs (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'running',
      total_articles INTEGER NOT NULL DEFAULT 0,
      completed_articles INTEGER NOT NULL DEFAULT 0,
      current_platform TEXT,
      current_round INTEGER,
      error_message TEXT,
      started_at TEXT NOT NULL,
      completed_at TEXT
    );
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      api_key TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL,
      last_active_at TEXT
    );
  `);
    dbAccess = new DatabaseAccess(db);
});
afterEach(() => {
    db.close();
});
// === Helpers ===
function createMockArticle(overrides = {}) {
    return {
        id: `art_test_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        sessionId: 'test-session',
        platform: 'weixin',
        contentType: 'tutorial',
        title: '测试文章标题',
        contentMarkdown: '# 测试\n\n这是测试内容。',
        contentHtml: '<h1>测试</h1>',
        contentPlain: '测试内容',
        tags: ['测试', '教程'],
        summary: '测试摘要',
        wordCount: 500,
        status: 'draft',
        generationRound: 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ...overrides,
    };
}
function createMockReview(articleId, round = 1) {
    return {
        articleId,
        round,
        passed: true,
        overallScore: 85,
        dimensions: {
            compliance: { score: 100, issues: [] },
            quality: { score: 90, issues: [{ dimension: 'quality', severity: 'low', description: '字数偏少' }] },
            seo: { score: 80, issues: [] },
            brand: { score: 85, issues: [] },
            originality: { score: 90, issues: [] },
            platform_adaptation: { score: 80, issues: [] },
            readability: { score: 95, issues: [] },
        },
        issues: [
            { dimension: 'quality', severity: 'low', description: '字数偏少', suggestion: '增加内容' },
        ],
        suggestions: ['增加内容深度', '优化段落结构'],
        reviewedAt: new Date().toISOString(),
    };
}
/** Build a RequestInit with a JSON body for Hono's app.request(). */
function jsonReq(method, body) {
    return {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    };
}
// === Session Routes ===
describe('Session Routes', () => {
    it('POST / - should create a new session and return sessionId, sessionData, introMessage', async () => {
        const app = createSessionRoutes(dbAccess);
        const res = await app.request('/', { method: 'POST' });
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(json.data.sessionId).toEqual(expect.any(String));
        expect(json.data.sessionData).toBeDefined();
        expect(json.data.sessionData.id).toBe(json.data.sessionId);
        expect(json.data.introMessage).toBeDefined();
        expect(json.data.introMessage.role).toEqual(expect.any(String));
        expect(json.data.introMessage.content).toEqual(expect.any(String));
    });
    it('GET /:id - should return 200 for an existing session', async () => {
        const app = createSessionRoutes(dbAccess);
        // Insert a session directly into the DB (tests the db-restore path of getSession)
        const id = `test-session-get-${Date.now()}`;
        dbAccess.upsertSession(id, createEmptySession(id));
        const res = await app.request('/' + id);
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(json.data.sessionData).toBeDefined();
        expect(json.data.sessionData.id).toBe(id);
        expect(json.data.progress).toBeDefined();
    });
    it('GET /:id - should return 404 for a non-existent session', async () => {
        const app = createSessionRoutes(dbAccess);
        const res = await app.request('/definitely-nonexistent-session-' + Date.now());
        const json = await res.json();
        expect(res.status).toBe(404);
        expect(json.success).toBe(false);
        expect(json.error).toBeDefined();
    });
    it('GET / - should list all sessions', async () => {
        const app = createSessionRoutes(dbAccess);
        // Create a session via the endpoint so it lands in the in-memory store
        const createRes = await app.request('/', { method: 'POST' });
        const createJson = await createRes.json();
        const sessionId = createJson.data.sessionId;
        const res = await app.request('/');
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(Array.isArray(json.data)).toBe(true);
        const found = json.data.find((s) => s.id === sessionId);
        expect(found).toBeDefined();
        expect(found.id).toBe(sessionId);
        expect(found.stage).toBeDefined();
        expect(found.createdAt).toBeDefined();
        expect(found.updatedAt).toBeDefined();
    });
    it('DELETE /:id - should return 200 for an existing session', async () => {
        const app = createSessionRoutes(dbAccess);
        const createRes = await app.request('/', { method: 'POST' });
        const createJson = await createRes.json();
        const sessionId = createJson.data.sessionId;
        const res = await app.request('/' + sessionId, { method: 'DELETE' });
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        // Session should no longer be retrievable
        const getRes = await app.request('/' + sessionId);
        expect(getRes.status).toBe(404);
    });
    it('DELETE /:id - should return 404 for a non-existent session', async () => {
        const app = createSessionRoutes(dbAccess);
        const res = await app.request('/definitely-nonexistent-session-' + Date.now(), { method: 'DELETE' });
        const json = await res.json();
        expect(res.status).toBe(404);
        expect(json.success).toBe(false);
    });
});
// === Article Routes ===
describe('Article Routes', () => {
    it('GET / - should return an empty list when no articles exist', async () => {
        const app = createArticleRoutes(dbAccess);
        const res = await app.request('/');
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(Array.isArray(json.data)).toBe(true);
        expect(json.data).toHaveLength(0);
    });
    it('GET /?sessionId= - should return articles filtered by sessionId', async () => {
        const app = createArticleRoutes(dbAccess);
        dbAccess.insertArticle(createMockArticle({ id: 'art_s1_a', sessionId: 'session-filter' }));
        dbAccess.insertArticle(createMockArticle({ id: 'art_s1_b', sessionId: 'session-filter' }));
        dbAccess.insertArticle(createMockArticle({ id: 'art_s2_a', sessionId: 'session-other' }));
        const res = await app.request('/?sessionId=session-filter');
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.data).toHaveLength(2);
        expect(json.data.every((a) => a.sessionId === 'session-filter')).toBe(true);
    });
    it('GET /?status= - should return articles filtered by status', async () => {
        const app = createArticleRoutes(dbAccess);
        dbAccess.insertArticle(createMockArticle({ id: 'art_st_1', status: 'draft' }));
        dbAccess.insertArticle(createMockArticle({ id: 'art_st_2', status: 'approved' }));
        dbAccess.insertArticle(createMockArticle({ id: 'art_st_3', status: 'approved' }));
        const res = await app.request('/?status=approved');
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.data).toHaveLength(2);
        expect(json.data.every((a) => a.status === 'approved')).toBe(true);
    });
    it('GET / - should return all articles when no filter is provided', async () => {
        const app = createArticleRoutes(dbAccess);
        dbAccess.insertArticle(createMockArticle({ id: 'art_all_1', status: 'draft' }));
        dbAccess.insertArticle(createMockArticle({ id: 'art_all_2', status: 'approved' }));
        dbAccess.insertArticle(createMockArticle({ id: 'art_all_3', status: 'published' }));
        const res = await app.request('/');
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.data).toHaveLength(3);
    });
    it('GET /:id - should return 200 for an existing article', async () => {
        const app = createArticleRoutes(dbAccess);
        const article = createMockArticle({ id: 'art_get_one' });
        dbAccess.insertArticle(article);
        const res = await app.request('/' + article.id);
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(json.data.id).toBe(article.id);
        expect(json.data.title).toBe(article.title);
        expect(json.data.platform).toBe('weixin');
        expect(json.data.tags).toEqual(['测试', '教程']);
    });
    it('GET /:id - should return 404 for a non-existent article', async () => {
        const app = createArticleRoutes(dbAccess);
        const res = await app.request('/non-existent-article-' + Date.now());
        const json = await res.json();
        expect(res.status).toBe(404);
        expect(json.success).toBe(false);
        expect(json.error).toBeDefined();
    });
    it('PUT /:id - should update an existing article and return 200', async () => {
        const app = createArticleRoutes(dbAccess);
        const article = createMockArticle({ id: 'art_put_one' });
        dbAccess.insertArticle(article);
        const res = await app.request('/' + article.id, jsonReq('PUT', { title: '更新后的标题', status: 'approved' }));
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(json.data.id).toBe(article.id);
        expect(json.data.title).toBe('更新后的标题');
        expect(json.data.status).toBe('approved');
    });
    it('PUT /:id - should return 404 for a non-existent article', async () => {
        const app = createArticleRoutes(dbAccess);
        const res = await app.request('/non-existent-article-' + Date.now(), jsonReq('PUT', { title: 'x' }));
        const json = await res.json();
        expect(res.status).toBe(404);
        expect(json.success).toBe(false);
    });
    it('DELETE /:id - should soft-delete (status -> failed) an existing article and return 200', async () => {
        const app = createArticleRoutes(dbAccess);
        const article = createMockArticle({ id: 'art_del_one', status: 'draft' });
        dbAccess.insertArticle(article);
        const res = await app.request('/' + article.id, { method: 'DELETE' });
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        // Verify the article status was changed to 'failed' (soft delete)
        const updated = dbAccess.getArticle(article.id);
        expect(updated).toBeDefined();
        expect(updated.status).toBe('failed');
    });
    it('DELETE /:id - should return 404 for a non-existent article', async () => {
        const app = createArticleRoutes(dbAccess);
        const res = await app.request('/non-existent-article-' + Date.now(), { method: 'DELETE' });
        const json = await res.json();
        expect(res.status).toBe(404);
        expect(json.success).toBe(false);
    });
});
// === Review Routes ===
describe('Review Routes', () => {
    it('GET /:articleId/latest - should return 200 for an article with a review', async () => {
        const app = createReviewRoutes(dbAccess);
        const article = createMockArticle({ id: 'art_review_latest' });
        dbAccess.insertArticle(article);
        dbAccess.insertReview(createMockReview(article.id, 1));
        const res = await app.request('/' + article.id + '/latest');
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(json.data.articleId).toBe(article.id);
        expect(json.data.overallScore).toBe(85);
        expect(json.data.passed).toBe(true);
        expect(json.data.dimensions).toBeDefined();
        expect(json.data.dimensions.compliance.score).toBe(100);
        expect(json.data.dimensions.quality.score).toBe(90);
    });
    it('GET /:articleId/latest - should return 404 when no review exists', async () => {
        const app = createReviewRoutes(dbAccess);
        const article = createMockArticle({ id: 'art_no_review' });
        dbAccess.insertArticle(article);
        const res = await app.request('/' + article.id + '/latest');
        const json = await res.json();
        expect(res.status).toBe(404);
        expect(json.success).toBe(false);
        expect(json.error).toBeDefined();
    });
    it('GET /:articleId - should return all reviews for an article', async () => {
        const app = createReviewRoutes(dbAccess);
        const article = createMockArticle({ id: 'art_multi_review' });
        dbAccess.insertArticle(article);
        dbAccess.insertReview(createMockReview(article.id, 1));
        dbAccess.insertReview({ ...createMockReview(article.id, 2), overallScore: 92 });
        const res = await app.request('/' + article.id);
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(Array.isArray(json.data)).toBe(true);
        expect(json.data).toHaveLength(2);
        expect(json.data[0].articleId).toBe(article.id);
        expect(json.data[1].articleId).toBe(article.id);
    });
    it('GET /:articleId - should return an empty list for an article without reviews', async () => {
        const app = createReviewRoutes(dbAccess);
        const article = createMockArticle({ id: 'art_empty_review' });
        dbAccess.insertArticle(article);
        const res = await app.request('/' + article.id);
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(Array.isArray(json.data)).toBe(true);
        expect(json.data).toHaveLength(0);
    });
});
// === Credential Routes ===
describe('Credential Routes', () => {
    it('PUT /:platform - should save credentials and return masked data', async () => {
        const app = createCredentialRoutes(dbAccess);
        const cred = {
            platform: 'weixin',
            type: 'api_key',
            data: { apiKey: 'test-key-12345', appId: 'wx1234567890' },
            status: 'active',
        };
        const res = await app.request('/weixin', jsonReq('PUT', cred));
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(json.data.platform).toBe('weixin');
        expect(json.data.type).toBe('api_key');
        expect(json.data.status).toBe('active');
        // Masking: 'test-key-12345' (len 14) -> 'te' + 10 asterisks + '45'
        expect(json.data.data.apiKey).toBe('te**********45');
        // Masking: 'wx1234567890' (len 12) -> 'wx' + 8 asterisks + '90'
        expect(json.data.data.appId).toBe('wx********90');
    });
    it('PUT /:platform - should mask short values (<=4 chars) as ****', async () => {
        const app = createCredentialRoutes(dbAccess);
        const cred = {
            platform: 'zhihu',
            type: 'cookie',
            data: { code: 'ab', session: 'very-long-session-value-123' },
            status: 'active',
        };
        const res = await app.request('/zhihu', jsonReq('PUT', cred));
        const json = await res.json();
        expect(res.status).toBe(200);
        // Short value -> fully masked
        expect(json.data.data.code).toBe('****');
        // Long value (len 27) -> masked with first 2 + 20 asterisks + last 2 ('23')
        expect(json.data.data.session).toMatch(/^ve\*{20}23$/);
        expect(json.data.data.session.endsWith('23')).toBe(true);
    });
    it('GET / - should return all credentials with masked data', async () => {
        const app = createCredentialRoutes(dbAccess);
        dbAccess.upsertCredential('weixin', {
            platform: 'weixin', type: 'api_key', data: { apiKey: 'test-key-12345' }, status: 'active',
        });
        dbAccess.upsertCredential('zhihu', {
            platform: 'zhihu', type: 'cookie', data: { session: 'abcdef123456' }, status: 'active',
        });
        const res = await app.request('/');
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(json.data).toHaveLength(2);
        // Every credential value should be masked (never equal to the raw secret)
        for (const cred of json.data) {
            for (const value of Object.values(cred.data)) {
                expect(value).not.toBe('test-key-12345');
                expect(value).not.toBe('abcdef123456');
            }
        }
    });
    it('GET /:platform - should return 200 for an existing credential with masked data', async () => {
        const app = createCredentialRoutes(dbAccess);
        dbAccess.upsertCredential('csdn', {
            platform: 'csdn', type: 'cookie', data: { session: 'csdn-secret-token-999' }, status: 'active',
        });
        const res = await app.request('/csdn');
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(json.data.platform).toBe('csdn');
        expect(json.data.data.session).not.toBe('csdn-secret-token-999');
        // 'csdn-secret-token-999' (len 21) -> 'cs' + 17 asterisks + '99'
        expect(json.data.data.session).toBe('cs' + '*'.repeat(17) + '99');
    });
    it('GET /:platform - should return 404 for a non-existent credential', async () => {
        const app = createCredentialRoutes(dbAccess);
        const res = await app.request('/nonexistent-platform');
        const json = await res.json();
        expect(res.status).toBe(404);
        expect(json.success).toBe(false);
        expect(json.error).toBeDefined();
    });
    it('POST /:platform/validate - should validate existing credentials', async () => {
        const app = createCredentialRoutes(dbAccess);
        dbAccess.upsertCredential('juejin', {
            platform: 'juejin', type: 'token', data: { token: 'some-token-value' }, status: 'active',
        });
        const res = await app.request('/juejin/validate', { method: 'POST' });
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(json.data.valid).toBe(true);
        expect(json.data.status).toBe('active');
        expect(json.data.lastValidatedAt).toBeDefined();
    });
    it('POST /:platform/validate - should return 404 for a non-existent credential', async () => {
        const app = createCredentialRoutes(dbAccess);
        const res = await app.request('/nonexistent-platform/validate', { method: 'POST' });
        const json = await res.json();
        expect(res.status).toBe(404);
        expect(json.success).toBe(false);
    });
    it('DELETE /:platform - should delete credentials', async () => {
        const app = createCredentialRoutes(dbAccess);
        dbAccess.upsertCredential('bilibili', {
            platform: 'bilibili', type: 'cookie', data: { session: 'bili-session' }, status: 'active',
        });
        const res = await app.request('/bilibili', { method: 'DELETE' });
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(json.data.deleted).toBe(true);
        // Credential should no longer be retrievable
        const getRes = await app.request('/bilibili');
        expect(getRes.status).toBe(404);
    });
});
// === Pipeline Routes ===
describe('Pipeline Routes', () => {
    it('GET /status/:sessionId - should return article counts and summaries', async () => {
        const app = createPipelineRoutes(dbAccess);
        const sessionId = 'pipe-session-status';
        // Insert mock articles with different statuses
        dbAccess.insertArticle(createMockArticle({
            id: 'art_pipe_draft', sessionId, status: 'draft', platform: 'weixin',
        }));
        dbAccess.insertArticle(createMockArticle({
            id: 'art_pipe_approved', sessionId, status: 'approved', platform: 'zhihu',
        }));
        // Insert a review and a published publish task for the approved article
        dbAccess.insertReview({ ...createMockReview('art_pipe_approved', 1), overallScore: 88 });
        const task = {
            id: 'task_pipe_1',
            articleId: 'art_pipe_approved',
            platform: 'zhihu',
            status: 'published',
            method: 'rpa',
            platformPostId: 'post-123',
            platformPostUrl: 'https://zhihu.com/post/123',
            retryCount: 0,
            maxRetries: 2,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
        };
        dbAccess.insertPublishTask(task);
        const res = await app.request('/status/' + sessionId);
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(json.data.sessionId).toBe(sessionId);
        expect(json.data.totalArticles).toBe(2);
        expect(json.data.draft).toBe(1);
        expect(json.data.approved).toBe(1);
        expect(json.data.reviewing).toBe(0);
        expect(json.data.publishing).toBe(0);
        expect(json.data.published).toBe(0);
        expect(json.data.failed).toBe(0);
        expect(json.data.articles).toHaveLength(2);
        // Verify summaries include review score and publish url where applicable
        const approvedSummary = json.data.articles.find((a) => a.id === 'art_pipe_approved');
        expect(approvedSummary).toBeDefined();
        expect(approvedSummary.reviewScore).toBe(88);
        expect(approvedSummary.publishUrl).toBe('https://zhihu.com/post/123');
        const draftSummary = json.data.articles.find((a) => a.id === 'art_pipe_draft');
        expect(draftSummary).toBeDefined();
        expect(draftSummary.reviewScore).toBeUndefined();
        expect(draftSummary.publishUrl).toBeUndefined();
    });
    it('GET /status/:sessionId - should include the latest pipeline run when one exists', async () => {
        const app = createPipelineRoutes(dbAccess);
        const sessionId = 'pipe-session-run';
        const run = {
            id: 'run_status_1',
            sessionId,
            status: 'completed',
            totalArticles: 2,
            completedArticles: 2,
            startedAt: '2026-08-01T00:00:00Z',
            completedAt: '2026-08-01T01:00:00Z',
        };
        dbAccess.insertPipelineRun(run);
        const res = await app.request('/status/' + sessionId);
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.data.run).toBeDefined();
        expect(json.data.run.id).toBe('run_status_1');
        expect(json.data.run.status).toBe('completed');
    });
    it('GET /status/:sessionId - should return zero counts for a session with no articles', async () => {
        const app = createPipelineRoutes(dbAccess);
        const res = await app.request('/status/empty-session-' + Date.now());
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.data.totalArticles).toBe(0);
        expect(json.data.draft).toBe(0);
        expect(json.data.articles).toHaveLength(0);
        expect(json.data.run).toBeUndefined();
    });
    it('GET /run/:runId - should return 200 for an existing pipeline run', async () => {
        const app = createPipelineRoutes(dbAccess);
        const run = {
            id: 'run_get_1',
            sessionId: 'session-run-get',
            status: 'running',
            totalArticles: 3,
            completedArticles: 1,
            currentPlatform: 'zhihu',
            currentRound: 1,
            startedAt: new Date().toISOString(),
        };
        dbAccess.insertPipelineRun(run);
        const res = await app.request('/run/' + run.id);
        const json = await res.json();
        expect(res.status).toBe(200);
        expect(json.success).toBe(true);
        expect(json.data.id).toBe('run_get_1');
        expect(json.data.sessionId).toBe('session-run-get');
        expect(json.data.status).toBe('running');
        expect(json.data.totalArticles).toBe(3);
        expect(json.data.completedArticles).toBe(1);
        expect(json.data.currentPlatform).toBe('zhihu');
    });
    it('GET /run/:runId - should return 404 for a non-existent pipeline run', async () => {
        const app = createPipelineRoutes(dbAccess);
        const res = await app.request('/run/non-existent-run-' + Date.now());
        const json = await res.json();
        expect(res.status).toBe(404);
        expect(json.success).toBe(false);
        expect(json.error).toBeDefined();
    });
});
//# sourceMappingURL=routes.test.js.map