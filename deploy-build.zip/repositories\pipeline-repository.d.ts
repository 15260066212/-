import type { DB } from '../db.js';
import type { PipelineRun } from '@zemingengine/shared';
export declare class PipelineRepository {
    private db;
    constructor(db: DB);
    insertPipelineRun(run: PipelineRun): void;
    updatePipelineRun(id: string, updates: Partial<PipelineRun>): void;
    getPipelineRun(id: string): PipelineRun | undefined;
    getLatestPipelineRunBySession(sessionId: string): PipelineRun | undefined;
    private mapPipelineRun;
}
//# sourceMappingURL=pipeline-repository.d.ts.map