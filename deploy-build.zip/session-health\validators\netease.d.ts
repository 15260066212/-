import { HarvesterBrowserValidator } from './harvester-browser.js';
export declare class NeteaseValidator extends HarvesterBrowserValidator {
    readonly platform: "netease";
    protected get harvesterPlatform(): string;
}
//# sourceMappingURL=netease.d.ts.map