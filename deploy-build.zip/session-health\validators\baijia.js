import { HarvesterBrowserValidator } from './harvester-browser.js';
export class BaijiaValidator extends HarvesterBrowserValidator {
    platform = 'baijia';
    get harvesterPlatform() {
        return 'baijiahao';
    }
}
//# sourceMappingURL=baijia.js.map