import { HarvesterBrowserValidator } from './harvester-browser.js';
export class ZhidaoValidator extends HarvesterBrowserValidator {
    platform = 'zhidao';
}
//# sourceMappingURL=zhidao.js.map