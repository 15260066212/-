import type { DB } from '../db.js';
import type { PublishTask, PublishTaskStatus, PublishLog } from '@zemingengine/shared';
export declare class PublishRepository {
    private db;
    constructor(db: DB);
    insertPublishTask(task: PublishTask): void;
    updatePublishTask(id: string, updates: Partial<PublishTask>): void;
    getPublishTask(id: string): PublishTask | undefined;
    getPendingPublishTasks(): PublishTask[];
    getPublishTasksByArticle(articleId: string): PublishTask[];
    /**
     * Query publish tasks matching any of the given statuses.
     * Returns an empty array when no statuses are provided.
     */
    getPublishTasksByStatuses(statuses: PublishTaskStatus[]): PublishTask[];
    /** Get all tasks that have a scheduledAt and are in 'pending' status, ordered by scheduled time. */
    getScheduledPublishTasks(): PublishTask[];
    /** Get all tasks that have a scheduledAt (any status), ordered by scheduled time. */
    getAllScheduledTasks(): PublishTask[];
    /** Get tasks in 'publishing' status whose updated_at is older than the given threshold (ms). */
    getStalePublishingTasks(staleMs: number): PublishTask[];
    /** Get queue status statistics grouped by task status. */
    getQueueStatus(): {
        pending: number;
        publishing: number;
        published: number;
        failed: number;
        retrying: number;
        total: number;
    };
    private mapPublishTask;
    /** Get recent publish stats for a specific platform (last N tasks). */
    getPlatformPublishHealth(platform: string, limit?: number): {
        platform: string;
        total: number;
        published: number;
        failed: number;
        successRate: number;
        recentFailures: number;
        avgRetryCount: number;
        lastPublishedAt: string | null;
        lastError: string | null;
    };
    /** Get publish health for all platforms. */
    getAllPlatformPublishHealth(): Array<ReturnType<PublishRepository['getPlatformPublishHealth']>>;
    /** Get publish queue details with task info. */
    getPublishQueueDetail(): {
        pending: PublishTask[];
        publishing: PublishTask[];
        retrying: PublishTask[];
        counts: {
            pending: number;
            publishing: number;
            published: number;
            failed: number;
            retrying: number;
            total: number;
        };
    };
    insertPublishLog(log: PublishLog): void;
    getLogsByTask(taskId: string): PublishLog[];
    /**
     * Get the most recent publish logs across all tasks, newest first.
     * @param limit maximum number of logs to return (must be >= 0)
     */
    getRecentPublishLogs(limit: number): PublishLog[];
}
//# sourceMappingURL=publish-repository.d.ts.map