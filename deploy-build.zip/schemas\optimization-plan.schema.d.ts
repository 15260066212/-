import type { DB } from '../db.js';
export declare function initPlanTables(db: DB): void;
//# sourceMappingURL=optimization-plan.schema.d.ts.map