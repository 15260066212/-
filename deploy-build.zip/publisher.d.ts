import type { Article, PlatformCredentials, PlatformId, PublishTask } from '@zemingengine/shared';
import type { PublishResult } from './types.js';
import { PlatformAdapter } from './adapters/base.js';
import { RPAEngine } from './rpa-engine.js';
import { RpaHandler } from './rpa-handlers/base.js';
/** Callback for writing publish log entries to DB or elsewhere. */
export type LogCallback = (entry: {
    taskId: string;
    level: 'info' | 'warn' | 'error';
    message: string;
    metadata?: Record<string, unknown>;
}) => void;
export declare class Publisher {
    private adapters;
    private rpaEngine;
    /** Optional resolver to look up an Article by ID for queue processing. */
    articleResolver?: (articleId: string) => Promise<Article | undefined>;
    /** Optional resolver to look up credentials for a platform. */
    credentialsResolver?: (platform: PlatformId) => Promise<PlatformCredentials | undefined>;
    /** Optional log callback for persisting publish logs. */
    logCallback?: LogCallback;
    constructor(rpaEngine?: RPAEngine);
    /**
     * Create a Publisher with all built-in platform adapters and RPA handlers
     * auto-registered. This is the recommended way to construct a Publisher.
     *
     * All platform registration happens here — single source of truth for
     * which platforms are supported and how they publish (API vs RPA).
     */
    static createDefault(rpaEngine?: RPAEngine): Publisher;
    registerAdapter(adapter: PlatformAdapter): void;
    /** Register an RPA handler for a platform. Delegates to the RPAEngine. */
    registerRpaHandler(handler: RpaHandler): void;
    /**
     * Check if a platform is supported (either via API adapter or RPA handler).
     * Unified single entry point — replaces separate hasAdapter / hasHandler calls.
     */
    supportsPlatform(platform: PlatformId): boolean;
    /**
     * List all supported platform IDs (both API adapters and RPA handlers).
     * Single source of truth for which platforms this Publisher can handle.
     */
    listSupportedPlatforms(): PlatformId[];
    /** Close the RPA engine's browser if it's running. */
    close(): Promise<void>;
    /** Check if an adapter is registered for a platform. */
    hasAdapter(platform: PlatformId): boolean;
    /** Get the adapter registered for a platform (or undefined). */
    getAdapter(platform: PlatformId): PlatformAdapter | undefined;
    /** Get the publish method (api or rpa) for a given platform. */
    getMethodForPlatform(platform: PlatformId): 'api' | 'rpa';
    /**
     * Create a PublishTask with the correct method determined by the platform adapter.
     */
    createTask(params: {
        articleId: string;
        platform: PlatformId;
        maxRetries?: number;
        scheduledAt?: string;
        userId?: string;
        accountId?: string;
    }): PublishTask;
    /**
     * Publish an article using the appropriate method:
     * - API platforms (weixin): use the registered adapter directly
     * - RPA platforms (all others): delegate to the RPAEngine with Playwright
     */
    publishArticle(article: Article, credentials: PlatformCredentials, platform?: PlatformId): Promise<PublishResult>;
    /**
     * Publish with intelligent retry based on failure classification.
     *
     * Failure-aware retry strategy:
     * - network errors: retry with 5s base delay
     * - rate_limit: retry with 30s delay
     * - platform errors (captcha, element not found): retry with 10s delay
     * - auth/credential errors: do NOT retry (won't fix itself)
     * - content violations: do NOT retry (won't fix itself)
     * - unknown: retry with 3s delay
     */
    publishWithRetry(task: PublishTask, article: Article, credentials: PlatformCredentials, onTaskUpdate?: (updates: Partial<PublishTask>) => void): Promise<PublishResult>;
    private log;
}
//# sourceMappingURL=publisher.d.ts.map