import { Hono } from 'hono';
import { Publisher } from '@zemingengine/publisher';
import type { AppEnv, DatabaseAccess } from '../db.js';
export declare function createPublishRoutes(db: DatabaseAccess, publisher: Publisher): Hono<AppEnv>;
//# sourceMappingURL=publish.d.ts.map