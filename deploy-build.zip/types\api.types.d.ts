/**
 * API request/response type definitions.
 */
import type { SessionData, DialogueMessage, ScrapeResult } from './session.types.js';
export interface ApiResponse<T = unknown> {
    success: boolean;
    data?: T;
    error?: string;
}
export interface ProgressInfo {
    current: number;
    total: number;
}
export interface CreateSessionResponse {
    sessionId: string;
    sessionData: SessionData;
    introMessage: DialogueMessage;
}
export interface SendMessageRequest {
    text: string;
}
export interface SendMessageResponse {
    messages: DialogueMessage[];
    sessionData: SessionData;
    isComplete: boolean;
    progress: ProgressInfo;
}
export interface GetSessionResponse {
    sessionData: SessionData;
    progress: ProgressInfo;
}
export interface ScrapeSessionResponse {
    scrapeResult: ScrapeResult;
    analysisMessage: DialogueMessage;
    sessionData: SessionData;
}
export interface ImportPptResponse {
    analysisMessage: DialogueMessage;
    sessionData: SessionData;
}
export interface ProfileReviewRequest {
    fullName: string;
    shortName: string;
    description: string;
    scale: string;
    location: string;
    website: string;
    foundedYear?: string;
    phone?: string;
    email?: string;
    address?: string;
    productsText: string;
    brandStory: string;
    trustAnchorsText: string;
    brandToneText?: string;
    userPainPointsText?: string;
}
export interface ProfileReviewResponse {
    messages: DialogueMessage[];
    sessionData: SessionData;
    isComplete: boolean;
    progress: ProgressInfo;
}
export interface BackResponse {
    message: DialogueMessage;
    sessionData: SessionData;
}
export interface ManualResponse {
    markdown: string;
    filename: string;
}
//# sourceMappingURL=api.types.d.ts.map