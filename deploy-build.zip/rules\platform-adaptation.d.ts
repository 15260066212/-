import type { Article, ReviewIssue } from '@zemingengine/shared';
export declare function checkPlatformAdaptation(article: Article): ReviewIssue[];
//# sourceMappingURL=platform-adaptation.d.ts.map