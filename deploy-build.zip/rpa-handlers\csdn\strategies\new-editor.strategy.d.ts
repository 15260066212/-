import type { Page } from 'playwright';
import type { Article } from '@zemingengine/shared';
import type { PublishResult } from '../../../types.js';
import { BaseCsdnStrategy } from './base.js';
/**
 * Strategy 1: New Markdown Editor (editor.csdn.net/md/)
 *
 * Navigate to the new Markdown editor, fill title / Markdown content / tags,
 * click "发布文章" button, handle publish dialog, and capture the saveArticle
 * API response to confirm publication.
 */
export declare class NewEditorStrategy extends BaseCsdnStrategy {
    readonly name = "New Markdown Editor";
    execute(page: Page, article: Article): Promise<PublishResult>;
    private fillTitleNewEditor;
    private fillContentNewEditor;
    private addTagsNewEditor;
}
//# sourceMappingURL=new-editor.strategy.d.ts.map