export interface TemplateParams {
    brandName: string;
    fullName: string;
    description: string;
    location: string;
    scale: string;
    brandStory: string;
    keywords: string[];
    allKeywords: string[];
    trustList: string;
    productList: string;
}
export declare function buildFaqContent(p: TemplateParams): string;
export declare function buildCaseContent(p: TemplateParams): string;
export declare function buildComparisonContent(p: TemplateParams): string;
export declare function buildPopularizationContent(p: TemplateParams): string;
export declare function buildWhitepaperContent(p: TemplateParams): string;
export declare function buildTutorialContent(p: TemplateParams): string;
export declare function buildContentByType(contentType: string, params: TemplateParams): string;
export declare function buildTitleByType(contentType: string, brandName: string, primaryKeyword: string, secondaryKeyword: string, products: {
    name: string;
    description: string;
    isPrimary?: boolean;
}[]): string;
export declare function buildSummaryText(contentType: string, brandName: string, keyword: string, description: string): string;
//# sourceMappingURL=fallback-templates.d.ts.map