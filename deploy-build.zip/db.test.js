import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import Database from 'better-sqlite3';
import { join } from 'node:path';
import { rmSync } from 'node:fs';
import { DatabaseAccess } from './db.js';
import { createEmptySession } from '@zemingengine/shared';
const TEST_DB_PATH = join(process.cwd(), 'data', 'test-geo-assistant.db');
let db;
let dbAccess;
beforeEach(() => {
    rmSync(TEST_DB_PATH, { force: true });
    rmSync(`${TEST_DB_PATH}-wal`, { force: true });
    rmSync(`${TEST_DB_PATH}-shm`, { force: true });
    // Create a fresh in-memory database for testing
    db = new Database(':memory:');
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
    // Run the same init logic as createDatabase
    db.exec(`
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      data TEXT NOT NULL,
      current_stage TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      user_id TEXT
    );
    CREATE TABLE IF NOT EXISTS articles (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      platform TEXT NOT NULL,
      content_type TEXT NOT NULL,
      title TEXT NOT NULL,
      content_markdown TEXT NOT NULL,
      content_html TEXT,
      content_plain TEXT,
      tags TEXT NOT NULL DEFAULT '[]',
      summary TEXT,
      cover_image_desc TEXT,
      word_count INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'draft',
      generation_round INTEGER NOT NULL DEFAULT 1,
      generation_meta TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS reviews (
      id TEXT PRIMARY KEY,
      article_id TEXT NOT NULL,
      round INTEGER NOT NULL,
      passed INTEGER NOT NULL,
      overall_score REAL NOT NULL,
      compliance_score REAL NOT NULL,
      quality_score REAL NOT NULL,
      seo_score REAL NOT NULL,
      brand_score REAL NOT NULL,
      originality_score REAL NOT NULL DEFAULT 100,
      platform_adaptation_score REAL NOT NULL DEFAULT 100,
      readability_score REAL NOT NULL DEFAULT 100,
      issues TEXT NOT NULL DEFAULT '[]',
      suggestions TEXT NOT NULL DEFAULT '[]',
      reviewed_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS publish_tasks (
      id TEXT PRIMARY KEY,
      article_id TEXT NOT NULL,
      platform TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      method TEXT NOT NULL,
      platform_post_id TEXT,
      platform_post_url TEXT,
      error_message TEXT,
      retry_count INTEGER NOT NULL DEFAULT 0,
      max_retries INTEGER NOT NULL DEFAULT 2,
      scheduled_at TEXT,
      published_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS publish_logs (
      id TEXT PRIMARY KEY,
      task_id TEXT NOT NULL,
      level TEXT NOT NULL,
      message TEXT NOT NULL,
      metadata TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS platform_credentials (
      user_id TEXT NOT NULL DEFAULT 'user_default',
      platform TEXT NOT NULL,
      credential_type TEXT NOT NULL,
      credential_data TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      last_validated_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      PRIMARY KEY (user_id, platform)
    );
    CREATE TABLE IF NOT EXISTS schema_version (
      version INTEGER PRIMARY KEY,
      applied_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS pipeline_runs (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'running',
      total_articles INTEGER NOT NULL DEFAULT 0,
      completed_articles INTEGER NOT NULL DEFAULT 0,
      current_platform TEXT,
      current_round INTEGER,
      error_message TEXT,
      started_at TEXT NOT NULL,
      completed_at TEXT
    );
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      api_key TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL,
      last_active_at TEXT
    );
  `);
    dbAccess = new DatabaseAccess(db);
});
afterEach(() => {
    db.close();
});
function createMockArticle(overrides = {}) {
    return {
        id: `art_test_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        sessionId: 'test-session',
        platform: 'weixin',
        contentType: 'tutorial',
        title: '测试文章标题',
        contentMarkdown: '# 测试\n\n这是测试内容。',
        contentHtml: '<h1>测试</h1><p>这是测试内容。</p>',
        tags: ['测试', '教程'],
        summary: '测试摘要',
        wordCount: 500,
        status: 'draft',
        generationRound: 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ...overrides,
    };
}
function createMockReview(articleId, round = 1) {
    return {
        articleId,
        round,
        passed: true,
        overallScore: 85,
        dimensions: {
            compliance: { score: 100, issues: [] },
            quality: { score: 90, issues: [{ dimension: 'quality', severity: 'low', description: '字数偏少' }] },
            seo: { score: 80, issues: [] },
            brand: { score: 85, issues: [] },
            originality: { score: 90, issues: [] },
            platform_adaptation: { score: 80, issues: [] },
            readability: { score: 95, issues: [] },
        },
        issues: [
            { dimension: 'quality', severity: 'low', description: '字数偏少', suggestion: '增加内容' },
        ],
        suggestions: ['增加内容深度', '优化段落结构'],
        reviewedAt: new Date().toISOString(),
    };
}
describe('DatabaseAccess - Sessions', () => {
    it('should upsert and get session', () => {
        const session = createEmptySession('test-session-1');
        session.enterprise.fullName = '测试公司';
        dbAccess.upsertSession('test-session-1', session);
        const retrieved = dbAccess.getSession('test-session-1');
        expect(retrieved).toBeDefined();
        expect(retrieved.id).toBe('test-session-1');
        expect(retrieved.enterprise.fullName).toBe('测试公司');
    });
    it('should update existing session on upsert', () => {
        const session = createEmptySession('test-session-2');
        dbAccess.upsertSession('test-session-2', session);
        session.enterprise.fullName = '更新后的公司';
        dbAccess.upsertSession('test-session-2', session);
        const retrieved = dbAccess.getSession('test-session-2');
        expect(retrieved.enterprise.fullName).toBe('更新后的公司');
    });
    it('should return undefined for non-existent session', () => {
        const result = dbAccess.getSession('non-existent');
        expect(result).toBeUndefined();
    });
    it('should delete session', () => {
        const session = createEmptySession('test-session-3');
        dbAccess.upsertSession('test-session-3', session);
        dbAccess.deleteSession('test-session-3');
        expect(dbAccess.getSession('test-session-3')).toBeUndefined();
    });
});
describe('DatabaseAccess - Articles', () => {
    it('should insert and get article', () => {
        const article = createMockArticle();
        dbAccess.insertArticle(article);
        const retrieved = dbAccess.getArticle(article.id);
        expect(retrieved).toBeDefined();
        expect(retrieved.title).toBe(article.title);
        expect(retrieved.platform).toBe('weixin');
        expect(retrieved.tags).toEqual(['测试', '教程']);
    });
    it('should get articles by session', () => {
        const art1 = createMockArticle({ id: 'art1', sessionId: 'session-x' });
        const art2 = createMockArticle({ id: 'art2', sessionId: 'session-x' });
        const art3 = createMockArticle({ id: 'art3', sessionId: 'session-y' });
        dbAccess.insertArticle(art1);
        dbAccess.insertArticle(art2);
        dbAccess.insertArticle(art3);
        const articles = dbAccess.getArticlesBySession('session-x');
        expect(articles.length).toBe(2);
    });
    it('should update article status', () => {
        const article = createMockArticle();
        dbAccess.insertArticle(article);
        dbAccess.updateArticle(article.id, { status: 'approved' });
        const updated = dbAccess.getArticle(article.id);
        expect(updated.status).toBe('approved');
    });
    it('should get articles by status', () => {
        dbAccess.insertArticle(createMockArticle({ id: 'a1', status: 'draft' }));
        dbAccess.insertArticle(createMockArticle({ id: 'a2', status: 'approved' }));
        dbAccess.insertArticle(createMockArticle({ id: 'a3', status: 'approved' }));
        const approved = dbAccess.getArticlesByStatus('approved');
        expect(approved.length).toBe(2);
    });
});
describe('DatabaseAccess - Reviews', () => {
    it('should insert and get review by article', () => {
        const article = createMockArticle();
        dbAccess.insertArticle(article);
        const review = createMockReview(article.id);
        dbAccess.insertReview(review);
        const reviews = dbAccess.getReviewsByArticle(article.id);
        expect(reviews.length).toBe(1);
        expect(reviews[0].overallScore).toBe(85);
        expect(reviews[0].passed).toBe(true);
    });
    it('should get latest review', () => {
        const article = createMockArticle();
        dbAccess.insertArticle(article);
        dbAccess.insertReview(createMockReview(article.id, 1));
        dbAccess.insertReview({ ...createMockReview(article.id, 2), overallScore: 92 });
        const latest = dbAccess.getLatestReview(article.id);
        expect(latest).toBeDefined();
        expect(latest.round).toBe(2);
        expect(latest.overallScore).toBe(92);
    });
    it('should properly reconstruct dimension issues', () => {
        const article = createMockArticle();
        dbAccess.insertArticle(article);
        const review = createMockReview(article.id);
        dbAccess.insertReview(review);
        const retrieved = dbAccess.getLatestReview(article.id);
        expect(retrieved.dimensions.quality.issues.length).toBe(1);
        expect(retrieved.dimensions.quality.issues[0].description).toBe('字数偏少');
        expect(retrieved.dimensions.compliance.issues.length).toBe(0);
    });
});
describe('DatabaseAccess - Publish Tasks', () => {
    it('should insert and get publish task', () => {
        const task = {
            id: 'task-1',
            articleId: 'art-1',
            platform: 'weixin',
            status: 'pending',
            method: 'api',
            retryCount: 0,
            maxRetries: 2,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
        };
        dbAccess.insertPublishTask(task);
        const retrieved = dbAccess.getPublishTask('task-1');
        expect(retrieved).toBeDefined();
        expect(retrieved.method).toBe('api');
        expect(retrieved.maxRetries).toBe(2);
    });
    it('should update task status', () => {
        const task = {
            id: 'task-2',
            articleId: 'art-2',
            platform: 'zhihu',
            status: 'pending',
            method: 'rpa',
            retryCount: 0,
            maxRetries: 2,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
        };
        dbAccess.insertPublishTask(task);
        dbAccess.updatePublishTask('task-2', { status: 'published', platformPostId: 'post123' });
        const updated = dbAccess.getPublishTask('task-2');
        expect(updated.status).toBe('published');
        expect(updated.platformPostId).toBe('post123');
    });
    it('should get pending tasks', () => {
        dbAccess.insertPublishTask({ id: 't1', articleId: 'a1', platform: 'weixin', status: 'pending', method: 'api', retryCount: 0, maxRetries: 2, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
        dbAccess.insertPublishTask({ id: 't2', articleId: 'a2', platform: 'zhihu', status: 'retrying', method: 'rpa', retryCount: 1, maxRetries: 2, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
        dbAccess.insertPublishTask({ id: 't3', articleId: 'a3', platform: 'csdn', status: 'published', method: 'rpa', retryCount: 0, maxRetries: 2, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
        const pending = dbAccess.getPendingPublishTasks();
        expect(pending.length).toBe(2);
    });
});
describe('DatabaseAccess - Publish Logs', () => {
    it('should insert and get logs by task', () => {
        const log1 = {
            id: 'log1', taskId: 'task1', level: 'info', message: 'Starting publish',
            createdAt: new Date().toISOString(),
        };
        const log2 = {
            id: 'log2', taskId: 'task1', level: 'warn', message: 'Retrying',
            createdAt: new Date().toISOString(),
        };
        dbAccess.insertPublishLog(log1);
        dbAccess.insertPublishLog(log2);
        const logs = dbAccess.getLogsByTask('task1');
        expect(logs.length).toBe(2);
    });
});
describe('DatabaseAccess - Credentials', () => {
    it('should upsert and get credential', () => {
        const cred = {
            platform: 'weixin',
            type: 'api_key',
            data: { apiKey: 'test-key-123', appId: 'wx123' },
            status: 'active',
        };
        dbAccess.upsertCredential('weixin', cred);
        const retrieved = dbAccess.getCredential('weixin');
        expect(retrieved).toBeDefined();
        expect(retrieved.type).toBe('api_key');
        expect(retrieved.data.apiKey).toBe('test-key-123');
    });
    it('should update credential on upsert', () => {
        dbAccess.upsertCredential('zhihu', {
            platform: 'zhihu', type: 'cookie', data: { session: 'old' }, status: 'active',
        });
        dbAccess.upsertCredential('zhihu', {
            platform: 'zhihu', type: 'cookie', data: { session: 'new' }, status: 'active',
        });
        const retrieved = dbAccess.getCredential('zhihu');
        expect(retrieved.data.session).toBe('new');
    });
    it('should update credential status', () => {
        dbAccess.upsertCredential('csdn', {
            platform: 'csdn', type: 'cookie', data: { session: 'x' }, status: 'active',
        });
        dbAccess.updateCredentialStatus('csdn', 'expired');
        const retrieved = dbAccess.getCredential('csdn');
        expect(retrieved.status).toBe('expired');
    });
    it('should delete credential', () => {
        dbAccess.upsertCredential('juejin', {
            platform: 'juejin', type: 'token', data: { token: 't' }, status: 'active',
        });
        dbAccess.deleteCredential('juejin');
        expect(dbAccess.getCredential('juejin')).toBeUndefined();
    });
    it('should get all credentials', () => {
        dbAccess.upsertCredential('weixin', { platform: 'weixin', type: 'api_key', data: { k: 'v' }, status: 'active' });
        dbAccess.upsertCredential('zhihu', { platform: 'zhihu', type: 'cookie', data: { s: 'v' }, status: 'active' });
        const all = dbAccess.getAllCredentials();
        expect(all.length).toBe(2);
    });
});
describe('DatabaseAccess - Pipeline Runs', () => {
    it('should insert and get pipeline run', () => {
        const run = {
            id: 'run-1',
            sessionId: 'session-1',
            status: 'running',
            totalArticles: 5,
            completedArticles: 0,
            startedAt: new Date().toISOString(),
        };
        dbAccess.insertPipelineRun(run);
        const retrieved = dbAccess.getPipelineRun('run-1');
        expect(retrieved).toBeDefined();
        expect(retrieved.status).toBe('running');
        expect(retrieved.totalArticles).toBe(5);
    });
    it('should update pipeline run progress', () => {
        const run = {
            id: 'run-2',
            sessionId: 'session-2',
            status: 'running',
            totalArticles: 3,
            completedArticles: 0,
            startedAt: new Date().toISOString(),
        };
        dbAccess.insertPipelineRun(run);
        dbAccess.updatePipelineRun('run-2', {
            completedArticles: 2,
            currentPlatform: 'zhihu',
            currentRound: 1,
        });
        const updated = dbAccess.getPipelineRun('run-2');
        expect(updated.completedArticles).toBe(2);
        expect(updated.currentPlatform).toBe('zhihu');
    });
    it('should mark pipeline as completed', () => {
        const run = {
            id: 'run-3',
            sessionId: 'session-3',
            status: 'running',
            totalArticles: 2,
            completedArticles: 0,
            startedAt: new Date().toISOString(),
        };
        dbAccess.insertPipelineRun(run);
        dbAccess.updatePipelineRun('run-3', {
            status: 'completed',
            completedArticles: 2,
            completedAt: new Date().toISOString(),
        });
        const updated = dbAccess.getPipelineRun('run-3');
        expect(updated.status).toBe('completed');
        expect(updated.completedAt).toBeDefined();
    });
    it('should get latest pipeline run by session', () => {
        dbAccess.insertPipelineRun({
            id: 'run-old', sessionId: 'session-4', status: 'completed', totalArticles: 1, completedArticles: 1,
            startedAt: '2026-01-01T00:00:00Z', completedAt: '2026-01-01T01:00:00Z',
        });
        dbAccess.insertPipelineRun({
            id: 'run-new', sessionId: 'session-4', status: 'running', totalArticles: 3, completedArticles: 0,
            startedAt: '2026-08-03T00:00:00Z',
        });
        const latest = dbAccess.getLatestPipelineRunBySession('session-4');
        expect(latest).toBeDefined();
        expect(latest.id).toBe('run-new');
    });
});
//# sourceMappingURL=db.test.js.map