interface Brand {
    name?: string;
    website?: string;
}
interface Competitor {
    name?: string;
    website?: string;
}
interface Source {
    url: string;
    domain: string;
    source_origin?: string;
    title?: string;
    owned?: boolean;
    competitor_owned?: boolean;
    ecosystem?: string;
    ecosystem_label?: string;
    publish_time?: string;
}
/** Intermediate source object produced by collectMetadataSources. */
interface RawSource {
    url?: string;
    domain?: string;
    source_origin?: string;
    title?: string;
}
/** Context metadata passed between source collection methods. */
interface SourceContext {
    source_origin?: string;
    title?: string;
}
interface CitationResult {
    sources: Source[];
    citation_count: number;
    owned_citation_count: number;
    competitor_citation_count: number;
    ecosystem_distribution: Record<string, number>;
}
export declare class CitationAnalysisService {
    NON_DOMAIN_TLDS: Set<string>;
    /**
     * Classify a domain into its ecosystem bucket.
     * Delegates to the shared classifier in source-utils.ts (single source of truth).
     */
    classifyEcosystem(domain: string): {
        ecosystem: string;
        label: string;
    };
    normalizeDomain(value: string): string;
    isValidDomain(domain: string): boolean;
    sameOrSubdomain(domain: string, rootDomain: string): boolean;
    canonicalDomain(domain: string): string;
    normalizeCandidateUrl(value: string): string;
    isLikelyBareUrl(value: string): boolean;
    extractUrlsFromText(text: string): {
        index: number;
        url: string;
    }[];
    stripTrailingPunctuation(url: string): string;
    normalizeUrl(url: string): string;
    metadataForSource(value: Record<string, unknown> | null, context?: SourceContext): Record<string, string>;
    collectMetadataSources(value: unknown, sources?: RawSource[], context?: SourceContext): RawSource[];
    extractSources({ responseText, aiResponse, brand, competitors }: {
        responseText: string;
        aiResponse?: unknown;
        brand: Brand;
        competitors: Competitor[];
    }): CitationResult;
}
export declare const citationAnalysisService: CitationAnalysisService;
export {};
//# sourceMappingURL=citation-analysis-service.d.ts.map