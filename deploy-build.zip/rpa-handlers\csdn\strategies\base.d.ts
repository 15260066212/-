import type { Page } from 'playwright';
import type { Article } from '@zemingengine/shared';
import type { PublishResult } from '../../../types.js';
import type { CsdnPublishStrategy } from './types.js';
import type { CsdnRpaHandler } from '../../csdn.js';
/**
 * Base class for CSDN publish strategies.
 *
 * Contains shared utility methods used across all three strategies:
 * - Response parsing (saveArticle API)
 * - URL / article ID extraction
 * - Publish button clicking and dialog handling
 * - Visibility enforcement
 * - Screenshot capture (delegates to handler)
 * - Old-editor content filling (shared by S2 and S3)
 * - Draft management helpers (used by S3)
 */
export declare abstract class BaseCsdnStrategy implements CsdnPublishStrategy {
    protected readonly handler: CsdnRpaHandler;
    abstract readonly name: string;
    abstract execute(page: Page, article: Article): Promise<PublishResult>;
    /** Standard timeout values, mirrored from RpaHandler. */
    protected readonly timeouts: {
        readonly SHORT: 500;
        readonly MEDIUM: 1000;
        readonly LONG: 2000;
        readonly EXTRA_LONG: 3000;
        readonly DEFAULT: 5000;
        readonly EXTENDED: 10000;
        readonly PAGE_NAVIGATION: 30000;
    };
    constructor(handler: CsdnRpaHandler);
    protected parseSaveArticleResponse(captured: {
        status: number;
        body: string;
    }, currentUrl: string): PublishResult;
    protected extractArticleIdFromUrl(url: string): string;
    protected responseHasArticleUrl(body: string): boolean;
    protected clickPublishButton(page: Page): Promise<boolean>;
    protected handlePublishDialog(page: Page): Promise<void>;
    protected ensurePublicVisibility(page: Page): Promise<void>;
    protected captureScreenshot(page: Page, label: string): Promise<string>;
    protected fillTitleOldEditor(page: Page, title: string): Promise<boolean>;
    protected fillContentOldEditor(page: Page, markdownContent: string): Promise<boolean>;
    protected addTagsOldEditor(page: Page, tags: string[]): Promise<void>;
    protected clickSaveDraftButton(page: Page): Promise<boolean>;
    protected findAndPublishDraft(page: Page, articleId: string, articleTitle: string): Promise<{
        success: boolean;
        url?: string;
        error?: string;
    }>;
    private findAndClickPublishInList;
    private findAndClickPublishByTitle;
    private findAndClickFirstDraft;
}
//# sourceMappingURL=base.d.ts.map