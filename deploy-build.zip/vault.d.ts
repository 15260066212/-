/**
 * Account Vault — 200+账号多平台凭据管理
 *
 * 使用SQLite存储账号元信息，密码使用AES-256-GCM加密。
 * 支持按平台、状态、代理IP筛选账号。
 */
import type { AccountCredentials, AccountStatus, PlatformName, ProxyConfig, AccountVaultConfig, BrowserFingerprint } from './types.js';
export declare class AccountVault {
    private db;
    private dbPath;
    constructor(config?: AccountVaultConfig);
    private init;
    addAccount(params: {
        platform: PlatformName;
        username: string;
        password: string;
        phone?: string;
        proxyId?: string;
        dailyLimit?: number;
        note?: string;
        group?: string;
        tags?: string;
    }): AccountCredentials;
    getAccount(accountId: string): AccountCredentials | null;
    getAccountByPlatform(platform: PlatformName, username: string): AccountCredentials | null;
    listAccounts(filter?: {
        platform?: PlatformName;
        status?: AccountStatus;
        proxyId?: string;
        group?: string;
        tag?: string;
        limit?: number;
        offset?: number;
    }): AccountCredentials[];
    /** 获取可用于发布的账号（active状态，未达日限） */
    getAvailableAccount(platform: PlatformName): AccountCredentials | null;
    /** 获取所有可用于发布的账号（用于批量发布） */
    getAvailableAccounts(platform: PlatformName, limit?: number): AccountCredentials[];
    /** 解密密码 */
    getPassword(accountId: string): string;
    /** 更新账号状态 */
    updateStatus(accountId: string, status: AccountStatus, note?: string): void;
    /** 记录发布成功 */
    recordPublish(accountId: string): void;
    /** 记录登录成功 */
    recordLogin(accountId: string, sessionExpiresAt?: number): void;
    addProxy(proxy: Omit<ProxyConfig, 'id'> & {
        id?: string;
    }): string;
    bindProxy(accountId: string, proxyId: string): void;
    /** 代理健康检查 — 测试代理连通性 */
    checkProxyHealth(proxyId: string, testUrl?: string): boolean;
    /** 批量检查所有代理健康状态 */
    checkAllProxies(): {
        proxyId: string;
        healthy: boolean;
        latency: number;
    }[];
    /** 获取健康代理 */
    getHealthyProxies(): ProxyConfig[];
    getProxy(proxyId: string): ProxyConfig | null;
    /** 获取代理关联的指纹配置 */
    getFingerprint(fingerprintId: string): BrowserFingerprint | null;
    /** 获取账号的指纹配置 */
    getAccountFingerprint(accountId: string): BrowserFingerprint | null;
    /** 生成一个唯一的浏览器指纹 */
    private generateFingerprint;
    /** 保存指纹到数据库 */
    private saveFingerprint;
    /** 检查 session 是否仍然有效（未过期） */
    isSessionValid(accountId: string, platform: PlatformName, maxAgeMs?: number): boolean;
    /** 列出所有分组 */
    listGroups(): string[];
    /** 设置账号分组 */
    setAccountGroup(accountId: string, group: string): void;
    /** 设置账号标签 */
    setAccountTags(accountId: string, tags: string): void;
    private rowToAccount;
    close(): void;
}
//# sourceMappingURL=vault.d.ts.map