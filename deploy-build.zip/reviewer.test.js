import { describe, it, expect } from 'vitest';
import { createEmptySession } from '@zemingengine/shared';
import { calculateScore } from './scorer.js';
import { ContentReviewer } from './reviewer.js';
function createMockArticle(overrides = {}) {
    return {
        id: 'test-article-1',
        sessionId: 'test-session',
        platform: 'weixin',
        contentType: 'tutorial',
        title: '如何使用 ZemingEngine 提升效率',
        contentMarkdown: '',
        contentPlain: 'ZemingEngine 是一款强大的智能引擎产品，能够帮助企业提升运营效率。\n\n' +
            '通过使用 ZemingEngine，企业可以实现自动化流程管理。智能引擎的核心优势在于其高效的处理能力。\n\n' +
            '本文将详细介绍 ZemingEngine 的各项功能。关键词智能引擎在正文中有足够的出现次数。' +
            'ZemingEngine 智能引擎可以帮助企业解决各种痛点。更多内容填充字数达到要求。' +
            '智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎。' +
            '这是一段用于增加字数的重复文本，确保文章总字数超过八百字。' +
            'ZemingEngine 持续创新，为用户提供更好的服务体验。' +
            '智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎。' +
            '企业数字化转型离不开像 ZemingEngine 这样的智能引擎工具。' +
            '智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎。' +
            'ZemingEngine 智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎智能引擎。',
        tags: ['test'],
        summary: '本文介绍 ZemingEngine 智能引擎如何帮助企业提升效率。',
        wordCount: 1000,
        status: 'draft',
        generationRound: 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ...overrides,
    };
}
function createMockSession(overrides = {}) {
    const session = createEmptySession('test-session');
    session.enterprise.fullName = 'ZemingEngine科技有限公司';
    session.enterprise.shortName = 'ZemingEngine';
    session.keywords = [
        { question: 'ZemingEngine', type: 'core', priority: 1, geoContext: '' },
        { question: '智能引擎', type: 'core', priority: 1, geoContext: '' },
    ];
    session.wordBank.productTerms = ['智能引擎'];
    session.enterprise.products = [{ name: '智能引擎', description: '核心产品', category: '软件', isPrimary: true }];
    session.enterprise.brandTone = ['专业', '高效'];
    return { ...session, ...overrides };
}
describe('calculateScore', () => {
    it('无 issues 时应返回 100 分', () => {
        const result = calculateScore([], 'compliance');
        expect(result.score).toBe(100);
        expect(result.issues).toEqual([]);
    });
    it('1 个 high severity issue 应扣 20 分', () => {
        const issues = [
            { dimension: 'compliance', severity: 'high', description: '敏感词' },
        ];
        const result = calculateScore(issues, 'compliance');
        expect(result.score).toBe(80);
        expect(result.issues.length).toBe(1);
    });
    it('1 个 medium + 1 个 low 应扣 15 分，得 85 分', () => {
        const issues = [
            { dimension: 'quality', severity: 'medium', description: '字数偏少' },
            { dimension: 'quality', severity: 'low', description: '格式问题' },
        ];
        const result = calculateScore(issues, 'quality');
        expect(result.score).toBe(85);
        expect(result.issues.length).toBe(2);
    });
    it('多个 issues 扣分不应低于 0 分', () => {
        const issues = [
            { dimension: 'compliance', severity: 'high', description: 'h1' },
            { dimension: 'compliance', severity: 'high', description: 'h2' },
            { dimension: 'compliance', severity: 'high', description: 'h3' },
            { dimension: 'compliance', severity: 'high', description: 'h4' },
            { dimension: 'compliance', severity: 'high', description: 'h5' },
            { dimension: 'compliance', severity: 'high', description: 'h6' },
        ];
        const result = calculateScore(issues, 'compliance');
        expect(result.score).toBe(0);
    });
    it('只计算指定 dimension 的 issues', () => {
        const issues = [
            { dimension: 'compliance', severity: 'high', description: '合规问题' },
            { dimension: 'quality', severity: 'medium', description: '质量问题' },
        ];
        const qualityResult = calculateScore(issues, 'quality');
        expect(qualityResult.score).toBe(90);
        expect(qualityResult.issues.length).toBe(1);
    });
});
describe('ContentReviewer.review', () => {
    it('正常文章应通过审核且 overallScore >= 70', () => {
        const reviewer = new ContentReviewer();
        const article = createMockArticle();
        const session = createMockSession();
        const result = reviewer.review(article, session);
        expect(result.passed).toBe(true);
        expect(result.overallScore).toBeGreaterThanOrEqual(70);
        expect(result.articleId).toBe(article.id);
        expect(result.round).toBe(article.generationRound);
    });
    it('问题文章（字数少、无品牌名）应不通过且有 issues', () => {
        const reviewer = new ContentReviewer();
        const article = createMockArticle({
            title: '测试标题',
            contentPlain: '很短。',
            wordCount: 100,
        });
        const session = createMockSession();
        const result = reviewer.review(article, session);
        expect(result.passed).toBe(false);
        expect(result.issues.length).toBeGreaterThan(0);
        const hasQualityIssue = result.issues.some((i) => i.dimension === 'quality');
        const hasBrandIssue = result.issues.some((i) => i.dimension === 'brand');
        expect(hasQualityIssue).toBeTruthy();
        expect(hasBrandIssue).toBeTruthy();
    });
    it('检测敏感词时 compliance 维度应有 high severity issue', () => {
        const reviewer = new ContentReviewer();
        const article = createMockArticle({
            contentPlain: '本文包含色情内容。' + 'ZemingEngine 智能引擎 '.repeat(50),
        });
        const session = createMockSession();
        const result = reviewer.review(article, session);
        const complianceIssues = result.issues.filter((i) => i.dimension === 'compliance');
        expect(complianceIssues.length).toBeGreaterThan(0);
        const hasHighSeverity = complianceIssues.some((i) => i.severity === 'high');
        expect(hasHighSeverity).toBeTruthy();
    });
});
//# sourceMappingURL=reviewer.test.js.map