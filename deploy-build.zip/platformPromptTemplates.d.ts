import type { PromptConfig, SessionData } from '@zemingengine/shared';
export declare function buildPlatformPrompts(session: SessionData): PromptConfig[];
//# sourceMappingURL=platformPromptTemplates.d.ts.map