import { HarvesterBrowserValidator } from './harvester-browser.js';
export declare class BaijiaValidator extends HarvesterBrowserValidator {
    readonly platform: "baijia";
    protected get harvesterPlatform(): string;
}
//# sourceMappingURL=baijia.d.ts.map