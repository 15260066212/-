import { Hono } from 'hono';
import type { AppEnv, DatabaseAccess } from '../db.js';
export declare function createUserRoutes(db: DatabaseAccess): Hono<AppEnv>;
//# sourceMappingURL=user.d.ts.map