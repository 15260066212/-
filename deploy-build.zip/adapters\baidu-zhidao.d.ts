import { PlatformAdapter } from './base.js';
import type { PublishParams, PublishResult } from '../types.js';
export declare class BaiduZhidaoAdapter extends PlatformAdapter {
    constructor();
    getMethod(): 'api' | 'rpa';
    publish(_params: PublishParams): Promise<PublishResult>;
}
//# sourceMappingURL=baidu-zhidao.d.ts.map