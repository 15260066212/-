import { Hono } from 'hono';
import { getHarvesterPlatformName } from '@zemingengine/shared';
import type { AppEnv, DatabaseAccess } from '../db.js';
import { HarvesterClient } from '../session-health/harvester-client.js';

function getHarvesterUrl(): string {
  return process.env.HARVESTER_URL || process.env.RPA_REMOTE_URL || 'http://harvester:3003';
}

function formatError(error: unknown): string {
  return error instanceof Error ? error.message : 'Unknown error';
}

/**
 * Profile management routes — proxies to harvester's profile API.
 *
 * Mounted at: /api/profiles
 *
 * Endpoints:
 *   GET    /                          - List all profiles
 *   GET    /:platform                 - List profiles for a platform
 *   GET    /:platform/:account/health - Check login health
 *   DELETE /:platform/:account        - Delete a profile
 *   POST   /:platform/:account/renew  - Renew a single profile
 *   POST   /renew-all                 - Renew all profiles
 */
export function createProfileRoutes(_db: DatabaseAccess): Hono<AppEnv> {
  const app = new Hono<AppEnv>();
  const harvesterUrl = getHarvesterUrl();
  const client = new HarvesterClient(harvesterUrl);

  // GET / - List all profiles
  app.get('/', async (c) => {
    try {
      const profiles = await client.listProfiles();
      if (profiles === null) {
        return c.json(
          { success: false, error: 'Harvester service unavailable' },
          502,
        );
      }
      return c.json({
        success: true,
        total: profiles.length,
        profiles,
      });
    } catch (error) {
      return c.json(
        { success: false, error: formatError(error) },
        500,
      );
    }
  });

  // GET /:platform - List profiles for a specific platform
  app.get('/:platform', async (c) => {
    try {
      const platform = c.req.param('platform');
      const harvesterPlatform = getHarvesterPlatformName(platform);
      const profiles = await client.listProfiles();
      if (profiles === null) {
        return c.json(
          { success: false, error: 'Harvester service unavailable' },
          502,
        );
      }
      const platformProfiles = profiles.filter(p => p.platform === harvesterPlatform);
      return c.json({
        success: true,
        platform,
        total: platformProfiles.length,
        accounts: platformProfiles,
      });
    } catch (error) {
      return c.json(
        { success: false, error: formatError(error) },
        500,
      );
    }
  });

  // GET /:platform/:account/health - Health check for a profile
  app.get('/:platform/:account/health', async (c) => {
    try {
      const platform = c.req.param('platform');
      const account = decodeURIComponent(c.req.param('account'));
      const harvesterPlatform = getHarvesterPlatformName(platform);
      const result = await client.checkProfileHealth(harvesterPlatform, account);
      if (result === null) {
        return c.json(
          { success: false, error: 'Harvester service unavailable' },
          502,
        );
      }
      return c.json(result);
    } catch (error) {
      return c.json(
        { success: false, error: formatError(error) },
        500,
      );
    }
  });

  // DELETE /:platform/:account - Delete a profile
  app.delete('/:platform/:account', async (c) => {
    try {
      const platform = c.req.param('platform');
      const account = decodeURIComponent(c.req.param('account'));
      const harvesterPlatform = getHarvesterPlatformName(platform);
      const deleted = await client.deleteProfile(harvesterPlatform, account);
      return c.json({
        success: deleted,
        platform,
        account,
        deleted,
      });
    } catch (error) {
      return c.json(
        { success: false, error: formatError(error) },
        500,
      );
    }
  });

  // POST /:platform/:account/renew - Renew a single profile
  app.post('/:platform/:account/renew', async (c) => {
    try {
      const platform = c.req.param('platform');
      const account = decodeURIComponent(c.req.param('account'));
      const harvesterPlatform = getHarvesterPlatformName(platform);
      const result = await client.renewProfile(harvesterPlatform, account);
      if (result === null) {
        return c.json(
          { success: false, error: 'Harvester service unavailable' },
          502,
        );
      }
      return c.json(result);
    } catch (error) {
      return c.json(
        { success: false, error: formatError(error) },
        500,
      );
    }
  });

  // POST /renew-all - Renew all profiles
  app.post('/renew-all', async (c) => {
    try {
      const result = await client.renewAllProfiles();
      if (result === null) {
        return c.json(
          { success: false, error: 'Harvester service unavailable' },
          502,
        );
      }
      return c.json(result);
    } catch (error) {
      return c.json(
        { success: false, error: formatError(error) },
        500,
      );
    }
  });

  return app;
}
