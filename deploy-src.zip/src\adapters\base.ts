import type { PlatformId } from '@zemingengine/shared';
import type { PublishParams, PublishResult } from '../types.js';

export interface VerificationResult {
  verificationStatus: 'verified' | 'unverified' | 'failed';
  verificationMessage: string;
}

export abstract class PlatformAdapter {
  readonly platform: PlatformId;

  constructor(platform: PlatformId) {
    this.platform = platform;
  }

  abstract publish(params: PublishParams): Promise<PublishResult>;

  getMethod(): 'api' | 'rpa' {
    return 'api';
  }
}
