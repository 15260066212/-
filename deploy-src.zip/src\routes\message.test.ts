﻿import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import type { DB } from '../db.js';
import { DatabaseAccess } from '../db.js';
import { createTestDatabase } from '../test-helpers.js';
import { createMessageRoutes } from './message.js';
import { createSession } from '../session-store.js';

const HTTP_STATUS_OK = 200;
const HTTP_STATUS_NOT_FOUND = 404;

function jsonReq(method: string, body: unknown): RequestInit {
  return {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  };
}

const validProfileRequest = {
  fullName: '测试企业有限公司',
  shortName: '测试企业',
  description: '专注于测试领域的企业',
  scale: '50-100人',
  location: '北京',
  website: 'https://example.com',
  foundedYear: '2020',
  phone: '010-12345678',
  email: 'test@example.com',
  address: '北京市朝阳区测试路1号',
  productsText: '测试产品A\n测试产品B',
  brandStory: '从2020年创立至今，致力于提供优质服务',
  trustAnchorsText: 'ISO认证\n专利证书',
  brandToneText: '专业、可靠',
  userPainPointsText: '效率低\n成本高',
};

describe('Message Routes', () => {
  let db: DB;
  let dbAccess: DatabaseAccess;
  let app: ReturnType<typeof createMessageRoutes>;
  let sessionId: string;

  beforeEach(() => {
    ({ db, dbAccess } = createTestDatabase());
    const entry = createSession(dbAccess, 'test-user');
    sessionId = entry.data.id;
    app = createMessageRoutes(dbAccess);
  });

  afterEach(() => {
    db.close();
  });

  describe('POST /:id/profile-review', () => {
    it('session不存在应返回404', async () => {
      const res = await app.request('/nonexistent/profile-review', jsonReq('POST', validProfileRequest));
      expect(res.status).toBe(HTTP_STATUS_NOT_FOUND);
      const data = await res.json();
      expect(data.success).toBe(false);
    });

    it('应返回成功响应结构', async () => {
      const res = await app.request(`/${sessionId}/profile-review`, jsonReq('POST', validProfileRequest));
      expect(res.status).toBe(HTTP_STATUS_OK);
      const data = await res.json();
      expect(data.success).toBe(true);
      expect(data.data.sessionData).toBeDefined();
      expect(data.data.messages).toBeDefined();
      expect(Array.isArray(data.data.messages)).toBe(true);
    });

    it('应保存企业基本信息（名称、成立年份）', async () => {
      const res = await app.request(`/${sessionId}/profile-review`, jsonReq('POST', validProfileRequest));
      const data = await res.json();
      const enterprise = data.data.sessionData.enterprise;

      expect(enterprise.fullName).toBe('测试企业有限公司');
      expect(enterprise.shortName).toBe('测试企业');
      expect(enterprise.foundedYear).toBe('2020');
    });

    it('应保存企业联系信息（电话、邮箱、地址）', async () => {
      const res = await app.request(`/${sessionId}/profile-review`, jsonReq('POST', validProfileRequest));
      const data = await res.json();
      const enterprise = data.data.sessionData.enterprise;

      expect(enterprise.phone).toBe('010-12345678');
      expect(enterprise.email).toBe('test@example.com');
      expect(enterprise.address).toBe('北京市朝阳区测试路1号');
    });

    it('应保存品牌调性和用户痛点', async () => {
      const res = await app.request(`/${sessionId}/profile-review`, jsonReq('POST', validProfileRequest));
      const data = await res.json();
      const enterprise = data.data.sessionData.enterprise;

      expect(enterprise.brandTone).toContain('专业');
      expect(enterprise.userPainPoints).toContain('效率低');
    });

    it('应保存产品列表并设置主产品', async () => {
      const res = await app.request(`/${sessionId}/profile-review`, jsonReq('POST', validProfileRequest));
      const data = await res.json();
      const enterprise = data.data.sessionData.enterprise;

      expect(enterprise.products).toHaveLength(2);
      expect(enterprise.products[0].isPrimary).toBe(true);
    });

    it('不含可选字段时应保留旧值', async () => {
      await app.request(`/${sessionId}/profile-review`, jsonReq('POST', validProfileRequest));

      const partialRequest = { ...validProfileRequest };
      delete (partialRequest as any).foundedYear;
      delete (partialRequest as any).brandToneText;
      delete (partialRequest as any).userPainPointsText;

      const res = await app.request(`/${sessionId}/profile-review`, jsonReq('POST', partialRequest));
      expect(res.status).toBe(HTTP_STATUS_OK);

      const data = await res.json();
      const enterprise = data.data.sessionData.enterprise;
      expect(enterprise.foundedYear).toBe('2020');
      expect(enterprise.brandTone).toContain('专业');
      expect(enterprise.userPainPoints).toContain('效率低');
    });
  });
});
